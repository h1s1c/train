"""Civil-clock timetable predictions, never live positioning or movement authority.

All dates are explicit local service dates/times (Asia/Tehran in the UI).
Timetables and the microscopic simulation deliberately have separate state.
"""
from __future__ import annotations
from bisect import bisect_right
from datetime import datetime, timedelta
import heapq
import math
from terminal_rules import POLICY, ehsan_time, minimum_shunts, platform_exit_s


def number(value, low, high, label, integer=False):
    if isinstance(value, bool):
        raise ValueError(label + ': لطفاً یک مقدار عددی وارد کنید.')
    try:
        v = float(value)
    except (ValueError, TypeError):
        raise ValueError(label + ': لطفاً یک مقدار عددی وارد کنید.') from None
    if not math.isfinite(v) or not low <= v <= high or (integer and not v.is_integer()):
        raise ValueError(f'{label}: عدد {low:g} تا {high:g} وارد کنید.' + (' تعداد باید عدد صحیح باشد.' if integer else ''))
    return int(v) if integer else v


def civil(value):
    if not isinstance(value, str) or len(value) not in (16, 19):
        raise ValueError('تاریخ و ساعت را کامل وارد کنید؛ برای نمونه: 2026-10-13T06:15:00.')
    result = datetime.fromisoformat(value)
    if result.tzinfo or not 2000 <= result.year <= 2100:
        raise ValueError('تاریخ و ساعت را بر اساس ساعت محلی سرویس و بدون پسوند منطقهٔ زمانی وارد کنید.')
    return result


def stamp(value):
    return value.isoformat(timespec='milliseconds' if value.microsecond else 'seconds')


class ServiceClock:
    def __init__(self, model, plan):
        if not isinstance(plan, dict):
            raise ValueError('اطلاعات برنامهٔ زمانی معتبر نیست. فیلدهای واردشده را بررسی کنید.')
        self.model, self.plan = model, plan
        self.names = {s['id']: s['name'] for s in model.data['stations']}
        self.run = {d: number(plan.get('run_' + d.lower() + '_s', 2580), 60, 21600, 'زمان سفر هر جهت (ثانیه)') for d in 'AB'}
        self.turn = dict(A=ehsan_time(plan.get('turn_a_s',model.config['ehsan_turn_s'])),
                         B=number(plan.get('turn_b_s',model.config['turn_s']),30,3600,'زمان گردش و انتظار در دستغیب (ثانیه)'))
        self.dwell = number(plan.get('dwell_s', 20), 0, 180, 'زمان توقف در ایستگاه میانی (ثانیه)')
        self.warnings = []
        self.edges, self.profiles = {}, {}
        self.mode = plan.get('profile_mode', 'estimated')
        if self.mode not in ('estimated', 'custom'):
            raise ValueError('نوع جدول ایستگاه‌ها معتبر نیست.')
        profiles = plan.get('profiles', {})
        if self.mode == 'custom' and not isinstance(profiles, dict):
            raise ValueError('برای ادامه، جدول زمان‌بندی ایستگاه‌ها را وارد کنید.')
        for d in 'AB':
            leg = next(l for l in model.legs(1, 21) if l['kind'] == 'run' and l['line'] == d)
            nodes = leg['nodes']
            indexes = [i for i, n in enumerate(nodes) if model.tracks[n]['platform']]
            ids = [model.tracks[nodes[i]]['station'] for i in indexes]
            self.edges[d] = [self.edge(leg, left, right) for left, right in zip(indexes, indexes[1:])]
            if self.mode == 'custom':
                rows = profiles.get(d)
                if not isinstance(rows, list) or len(rows) != len(ids):
                    raise ValueError('جدول هر جهت باید شامل همهٔ ایستگاه‌های همان مسیر باشد.')
                profile = []
                for row, station, i in zip(rows, ids, indexes):
                    if not isinstance(row, dict) or row.get('station') != station:
                        raise ValueError('ترتیب یا شناسهٔ یکی از ایستگاه‌ها در جدول صحیح نیست.')
                    arr = number(row.get('arrival_s'), 0, self.run[d], 'زمان سپری‌شده تا ورود به ایستگاه (ثانیه)')
                    dep = number(row.get('departure_s'), arr, self.run[d], 'زمان سپری‌شده تا خروج از ایستگاه (ثانیه)')
                    if profile and arr <= profile[-1]['departure_s']:
                        raise ValueError('زمان ورود به هر ایستگاه باید بعد از زمان خروج از ایستگاه قبلی باشد.')
                    profile.append(self.row(station, nodes[i], arr, dep))
                if profile[0]['arrival_s'] != 0 or profile[0]['departure_s'] != 0 or abs(profile[-1]['arrival_s'] - self.run[d]) > .001 or abs(profile[-1]['departure_s'] - self.run[d]) > .001:
                    raise ValueError('زمان ابتدای جدول باید صفر و زمان انتهایی آن باید برابر با کل زمان مسیر باشد.')
            else:
                moving = self.run[d] - max(0, len(ids)-2)*self.dwell
                if moving <= len(ids)-1:
                    raise ValueError('زمان تعیین‌شده برای این مسیر، برای حرکت و توقف در ایستگاه‌های میانی کافی نیست.')
                raw = sum(e['seconds'] for e in self.edges[d])
                t = 0.0
                profile = [self.row(ids[0], nodes[indexes[0]], 0, 0)]
                for j, edge in enumerate(self.edges[d]):
                    t += moving*edge['seconds']/raw
                    arr = t
                    if j < len(self.edges[d])-1:
                        t += self.dwell
                    profile.append(self.row(ids[j+1], nodes[indexes[j+1]], arr, t))
                profile[-1]['arrival_s'] = profile[-1]['departure_s'] = self.run[d]
            self.profiles[d] = profile
            if any(profile[i+1]['arrival_s']-profile[i]['departure_s'] < e['seconds']*.98 for i,e in enumerate(self.edges[d])):
                self.warnings.append('زمان بعضی بازه‌های جهت ' + d + ' از تخمین حرکتی محافظه‌کارانه کوتاه‌تر است؛ این جدول تأیید امکان حرکت نیست.')

    def row(self, station, track, arr, dep):
        return dict(station=station, name=self.names[station], track=track,
                    arrival_s=round(arr, 6), departure_s=round(dep, 6))

    def berth(self, node):
        return min(self.model.length(node)-1, self.model.config['train_length_m']+20)

    def edge(self, leg, left, right):
        m = self.model
        a,b = m.config['acceleration'], m.config['service_brake']
        cells = []
        for i in range(left, right+1):
            n = leg['nodes'][i]
            start = self.berth(n) if i == left else 0
            end = self.berth(n) if i == right else m.length(n)
            distance = end-start
            if distance > 0:
                cells.append(dict(track=n, start_m=start, length_m=distance, cap=m.route_speed(leg,i)/3.6))
        limits = [c['cap'] for c in cells]
        bounds = [0.0] + [min(limits[i-1],limits[i]) for i in range(1,len(cells))]+[0.0]
        for i,c in enumerate(cells):
            bounds[i+1] = min(bounds[i+1], math.sqrt(bounds[i]**2+2*a*c['length_m']))
        for i in range(len(cells)-1,-1,-1):
            bounds[i] = min(bounds[i], math.sqrt(bounds[i+1]**2+2*b*cells[i]['length_m']))
        total = 0.0
        for i,c in enumerate(cells):
            u,w = bounds[i],bounds[i+1]
            peak = min(c['cap'], math.sqrt((2*c['length_m']+u*u/a+w*w/b)/(1/a+1/b)))
            da,db = max(0,(peak*peak-u*u)/(2*a)),max(0,(peak*peak-w*w)/(2*b))
            ta,tb = max(0,(peak-u)/a),max(0,(peak-w)/b)
            cruise = max(0,c['length_m']-da-db)/peak
            c.update(u=u, peak=peak, a=a, b=b, ta=ta, tc=cruise, tb=tb, da=da, seconds=ta+cruise+tb)
            total += c['seconds']
        return dict(cells=cells, seconds=total, length_m=sum(c['length_m'] for c in cells))

    @staticmethod
    def interpolate(edge, q):
        remaining = min(1,max(0,q))*edge['seconds']
        distance = 0
        for i,c in enumerate(edge['cells']):
            if remaining <= c['seconds'] or i == len(edge['cells'])-1:
                t = min(c['seconds'], max(0,remaining))
                if t <= c['ta']:
                    x = c['u']*t + .5*c['a']*t*t
                elif t <= c['ta']+c['tc']:
                    x = c['da']+c['peak']*(t-c['ta'])
                else:
                    s = t-c['ta']-c['tc']
                    x = c['da']+c['peak']*c['tc']+c['peak']*s-.5*c['b']*s*s
                x = min(c['length_m'],max(0,x))
                return dict(track=c['track'], head_m=round(c['start_m']+x,1),
                            progress=(distance+x)/edge['length_m'])
            remaining -= c['seconds']
            distance += c['length_m']

    def template(self):
        return dict(profiles=self.profiles, warnings=self.warnings, profile_mode=self.mode,
                    data_revision=self.model.data['data_revision'], live=False)

    def trip_position(self, trip, now):
        d = trip['direction']
        elapsed = (now-trip['_departure']).total_seconds()
        rows = self.profiles[d]
        for i,row in enumerate(rows):
            if row['arrival_s'] <= elapsed < row['departure_s']:
                return dict(status='station', station=row['station'], station_name=row['name'],
                            track=row['track'], head_m=self.berth(row['track']),
                            station_departure=stamp(trip['_departure']+timedelta(seconds=row['departure_s'])),
                            map_index=i, progress=0, from_station=row['station'], to_station=row['station'])
            if i < len(rows)-1 and row['departure_s'] <= elapsed < rows[i+1]['arrival_s']:
                following = rows[i+1]
                q = (elapsed-row['departure_s'])/(following['arrival_s']-row['departure_s'])
                pos = self.interpolate(self.edges[d][i],q)
                return dict(status='moving', station=None, station_name=None, from_station=row['station'],
                            to_station=following['station'], from_name=row['name'], to_name=following['name'],
                            next_arrival=stamp(trip['_departure']+timedelta(seconds=following['arrival_s'])),
                            map_index=i, **pos)
        raise ValueError('زمان انتخاب‌شده خارج از بازهٔ این سفر است.')

    def calculate(self, now_value):
        plan = self.plan
        now = civil(now_value)
        fleet = number(plan.get('fleet_count',7),1,150,'تعداد قطار',True)
        h = number(plan.get('headway_min',15),.5,60,'هدوی')*60
        labels = plan.get('labels',[])
        if not isinstance(labels,list) or len(labels)>fleet:
            raise ValueError('تعداد نام‌های واردشده نباید از تعداد قطارها بیشتر باشد.')
        if any(not isinstance(x,str) or len(x.strip())>50 for x in labels):
            raise ValueError('نام یا شمارهٔ هر قطار باید حداکثر ۵۰ نویسه باشد.')
        # Empty or omitted slots retain the original internal default label.
        labels = [(labels[i].strip() if i < len(labels) else '') or 'TR-%03d'%(i+1) for i in range(fleet)]
        if len(set(labels))!=len(labels):
            raise ValueError('نام یا شمارهٔ قطارها، از جمله نام‌های پیش‌فرض، باید با یکدیگر متفاوت باشد.')
        pending = []
        windows = {}
        for d in 'AB':
            first,last = civil(plan['first_'+d.lower()]),civil(plan['last_'+d.lower()])
            span = (last-first).total_seconds()
            if not 0 <= span <= 172800:
                raise ValueError('زمان پایان اعزام باید بعد از زمان شروع و حداکثر ۴۸ ساعت پس از آن باشد. برای سرویس پس از نیمه‌شب، تاریخ روز بعد را انتخاب کنید.')
            count = math.floor((span+1e-6)/h)+1
            actual = first+timedelta(seconds=(count-1)*h)
            if abs((last-actual).total_seconds())>.001:
                self.warnings.append('در جهت '+d+'، آخرین اعزام منظم پیش از ساعت پایان انتخاب‌شده است؛ برای حفظ فاصله اعزام‌ها، سفر اضافه در ساعت پایان ساخته نشد.')
            windows[d] = dict(first_departure=stamp(first),last_departure=stamp(actual),last_arrival=stamp(actual+timedelta(seconds=self.run[d])),departures=count)
            for i in range(count):
                dep = first+timedelta(seconds=i*h)
                pending.append((dep,d))
        if len(pending) > 6000:
            raise ValueError('در هر محاسبه حداکثر ۶۰۰۰ اعزام قابل بررسی است. بازهٔ زمانی سرویس را کوتاه‌تر کنید.')
        all_dates = [datetime.fromisoformat(w['first_departure']) for w in windows.values()]+[datetime.fromisoformat(w['last_departure']) for w in windows.values()]
        if (max(all_dates)-min(all_dates)).total_seconds()>172800:
            raise ValueError('بازه‌های اعزام دو جهت باید در محدوده‌ای حداکثر ۴۸ ساعته قرار داشته باشند.')
        # Minimal feasible initial allocation without deadheading/teleportation.
        # The earliest ready vehicle at the origin is reused, preserving identity.
        ready = {'A':[],'B':[]}
        duties = []
        trips = []
        for dep,d in sorted(pending):
            if ready[d] and ready[d][0][0] <= dep:
                _,vid = heapq.heappop(ready[d])
            else:
                vid = len(duties)+1
                duties.append([])
            arr = dep+timedelta(seconds=self.run[d])
            dest = 'B' if d=='A' else 'A'
            # turn_a_s = turnaround at Ehsan (origin A); turn_b_s at Dastgheib.
            available = arr+timedelta(seconds=self.turn[dest])
            trip = dict(vehicle=vid,direction=d,origin=21 if d=='A' else 1,destination=1 if d=='A' else 21,
                        departure=stamp(dep),arrival=stamp(arr),ready=stamp(available),
                        _departure=dep,_arrival=arr,_ready=available)
            duties[vid-1].append(trip)
            trips.append(trip)
            heapq.heappush(ready[dest],(available,vid))
        required = len(duties)
        errors=[]
        cap=self.model.capacity(1,21)
        minimum=minimum_shunts(self.model,1,21)
        bound=max(cap['network_bound_s'],self.turn['A']+self.model.config['release_s'],self.turn['B']+self.model.config['release_s'])
        if h+1e-6<bound:
            errors.append(f'فاصله اعزام (هدوی) {h/60:.3f} دقیقه کافی نیست؛ حداقل فاصله طبق تنظیمات فعلی {bound/60:.3f} دقیقه است. فاصله اعزام را افزایش دهید و دوباره محاسبه کنید.')
        if self.turn['A']+.01<minimum['ehsan_s']:
            errors.append(f'زمان گردش احسان کافی نیست؛ حداقل زمان محاسبه‌شده در این مدل {minimum["ehsan_s"]:.1f} ثانیه است. زمان گردش احسان را افزایش دهید.')
        if self.turn['B']+.01<minimum['other_s']:
            errors.append(f'زمان گردش دستغیب کافی نیست؛ حداقل زمان محاسبه‌شده در این مدل {minimum["other_s"]:.1f} ثانیه است. زمان گردش دستغیب را افزایش دهید.')
        for d in 'AB':
            rows=self.profiles[d]
            bad=sum(rows[i+1]['arrival_s']-rows[i]['departure_s']+.5<edge['seconds'] for i,edge in enumerate(self.edges[d]))
            if bad:errors.append(f'در {bad} فاصله بین ایستگاه‌های جهت {d}، زمان سفر از حداقل محاسبه‌شده مدل کوتاه‌تر است. زمان‌های جدول ایستگاه‌ها یا کل زمان سفر را افزایش دهید.')
        terminal_intervals=[]
        for trip in trips:
            if trip['direction']=='B':
                terminal_intervals.append(dict(vehicle=trip['vehicle'],start=trip['arrival'],
                    ready=trip['ready'],end=stamp(trip['_ready']+timedelta(seconds=self.model.config['release_s']))))
        # Whole serial shunt cycle, plus release. Timer never grants occupancy.
        for left,right in zip(terminal_intervals,terminal_intervals[1:]):
            if datetime.fromisoformat(right['start']) < datetime.fromisoformat(left['end']):
                if len(errors)<20:errors.append('زمان مانور شانت دو قطار احسان با هم تداخل دارد: '+left['start']+' / '+right['start'])
        # Reserve platform A from the start of the outbound shunt until this
        # same vehicle departs and its complete body + margin clears platform A.
        # Initial trains are inferred staged outside the platform until boarding.
        dispatch=next(l for l in self.model.legs(1,21) if l['kind']=='dispatch')
        outbound=self.model.leg_seconds(dispatch)+self.model.config['point_throw_s']+self.model.config['dwell_s']
        exit_s=platform_exit_s(self.model,'T21.1','A')
        slots=[]
        for duty in duties:
            for index,trip in enumerate(duty):
                if trip['direction']!='A':continue
                previous=duty[index-1] if index else None
                start=previous['_ready']-timedelta(seconds=outbound) if previous and previous['direction']=='B' else trip['_departure']-timedelta(seconds=self.dwell)
                end=trip['_departure']+timedelta(seconds=exit_s)
                slots.append((start,end,trip['vehicle']))
        slots.sort()
        furthest=None
        for slot in slots:
            if furthest and slot[0] < furthest[1] and slot[2]!=furthest[2]:
                if len(errors)<20:errors.append('رزرو سکوی A احسان برای این دو قطار با هم تداخل دارد: '+str(furthest[2])+' و '+str(slot[2])+' در '+stamp(slot[0]))
            if furthest is None or slot[1]>furthest[1]:furthest=slot
        if required>fleet:errors.insert(0,f'برای اجرای این برنامه حداقل {required} قطار لازم است؛ تعداد فعلی {fleet} قطار کافی نیست.')
        valid = not errors
        terminal_now=next((dict(x,remaining_s=round((datetime.fromisoformat(x['end'])-now).total_seconds(),1)) for x in terminal_intervals if datetime.fromisoformat(x['start'])<=now<datetime.fromisoformat(x['end'])),None)
        self.warnings.append('محل استقرار اولیهٔ قطارها و محل پارک پس از آخرین سفر تأیید نشده است. در صورت اشغال مسیر، مدل منتظر می‌ماند و اگر گردش در موعد کامل نشود، اعزام خودکار را متوقف می‌کند.')
        vehicles = []
        for i,label in enumerate(labels):
            base = dict(id=i+1,label=label,station=None,station_name=None,track=None,head_m=None,
                        direction=None,map_index=None,progress=None,live=False)
            if not valid:
                base.update(status='conflict',message='تعداد قطارها، مسیر یا زمان گردش با برنامه سازگار نیست؛ ابتدا خطاهای برنامه را اصلاح کنید')
            elif i >= required:
                base.update(status='reserve',message='ذخیره؛ محل پارک مشخص نشده')
            else:
                duty = duties[i]
                index = bisect_right([t['_departure'] for t in duty],now)-1
                if index < 0:
                    first = duty[0]
                    st = first['origin']
                    base.update(status='not_started',station=st,station_name=self.names[st],
                                next_departure=first['departure'],next_direction=first['direction'])
                else:
                    trip = duty[index]
                    base.update(direction=trip['direction'],departure=trip['departure'],arrival=trip['arrival'])
                    if now < trip['_arrival']:
                        base.update(self.trip_position(trip,now))
                    else:
                        st = trip['destination']
                        status = 'turnaround' if now<trip['_ready'] else ('waiting' if index<len(duty)-1 else 'finished')
                        base.update(status=status,station=st,station_name=self.names[st])
                        if index<len(duty)-1:
                            base.update(next_departure=duty[index+1]['departure'],next_direction=duty[index+1]['direction'])
                        if status=='turnaround':
                            base['ready']=trip['ready']
                base['trips_total'] = len(duty)
            vehicles.append(base)
        if not valid:
            self.warnings = errors + self.warnings
        counts = {status:sum(v['status']==status for v in vehicles) for status in ('moving','station','turnaround','waiting','finished','not_started','reserve','conflict')}
        safe_trips = [{k:v for k,v in t.items() if not k.startswith('_')} for t in trips]
        return dict(**self.template(),valid=valid,now=stamp(now),time_basis='Asia/Tehran civil time',fleet_count=fleet,
                    required_fleet=required,reserve=max(0,fleet-required),headway_min=h/60,
                    cycle_s=sum(self.run.values())+sum(self.turn.values()),windows=windows,
                    errors=errors,minimum_headway_s=bound,turn_a_s=self.turn['A'],turn_b_s=self.turn['B'],
                    run_a_s=self.run['A'],run_b_s=self.run['B'],terminal_policy=POLICY,
                    terminal_intervals=terminal_intervals,terminal_current=terminal_now,
                    end_stabling_validated=False,
                    platform_a_reservation_model='outbound_route_through_body_clearance',
                    counts=counts,vehicles=vehicles,trips=safe_trips,
                    position_basis='entered_station_timetable' if self.mode=='custom' else 'estimated_station_timetable',
                    initial_allocation='inferred_at_terminals_not_observed',movement_authority=False)
