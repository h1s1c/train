const {chromium}=require('playwright');
const fs=require('fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/local/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:1050}});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8808');
 await page.waitForFunction(()=>typeof state!=='undefined'&&state&&lineData);
 await page.click('[data-tab="operations"]');
 const api=body=>page.evaluate(async body=>{const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return r.json()},body);
 const snap=()=>page.evaluate(async()=>fetch('/api/state').then(r=>r.json()));
 const check=(v,m)=>{if(!v)throw Error(m)};
 const confirmed=()=>{page.once('dialog',d=>d.accept());return page.click('#resetLine')};
 await confirmed();
 const names=await page.locator('#map [data-track]').evaluateAll(ns=>[...new Set(ns.map(n=>n.getAttribute('data-track')))]);
 const free=names.find(n=>n==='T21.1')||names[0];
 const rail=page.locator(`#map [data-track="${free}"]`).first();
 const before=await snap();
 await rail.dispatchEvent('click');
 check(await page.evaluate(()=>selected)===free,'first click selects');
 check(await rail.getAttribute('stroke')==='#2376bb','free selected rail blue');
 check((await page.locator('#trackInfo').innerText()).includes(free),'inspector');
 await rail.dispatchEvent('click');
 check(await page.evaluate(()=>selected)===null,'second click deselects');
 check(await rail.getAttribute('stroke')==='#8e9299','deselected rail gray');
 check(!(await page.locator('#trackInfo').innerText()).includes(free),'inspector cleared');
 let after=await snap();check(JSON.stringify(before.occupied)===JSON.stringify(after.occupied),'click must not change occupancy');
 await rail.dispatchEvent('keydown',{key:'Enter'});check(await page.evaluate(()=>selected)===free,'keyboard enter selects');
 await rail.dispatchEvent('keydown',{key:' '});check(await page.evaluate(()=>selected)===null,'keyboard space deselects');
 let r=await api({op:'add',section:'T21.1',line:'A'});check(r.ok,'add train');await page.evaluate(()=>poll());
 await rail.dispatchEvent('click');await rail.dispatchEvent('click');
 after=await snap();check(after.counts.total===1&&after.occupied['T21.1'],'red occupancy retained');check(await rail.getAttribute('stroke')==='var(--red)','red remains red');
 await api({op:'config',values:{headway_s:1000}}); // intentionally rejected while train exists, no change
 await api({op:'run'});await page.waitForTimeout(1000);
 await api({op:'scale',value:60});
 let reservedState,orange;
 for(let i=0;i<60;i++){
  await page.waitForTimeout(100);reservedState=await snap();
  orange=Object.keys(reservedState.reserved).find(n=>!reservedState.occupied[n]&&names.includes(n));
  if(orange){await api({op:'pause'});break;}
 }

 check(orange,'a real route reservation is available for test');
 await page.evaluate(()=>poll());
 const orangeRail=page.locator(`#map [data-track="${orange}"]`).first();
 await orangeRail.dispatchEvent('click');await orangeRail.dispatchEvent('click');
 check((await snap()).reserved[orange],'click preserves route reservation');
 check(await orangeRail.getAttribute('stroke')==='#c17a26','reservation stays orange');

 await api({op:'run'});page.once('dialog',d=>d.dismiss());await page.click('#resetLine');
 check((await snap()).counts.total===1,'cancel preserves train');
 await confirmed();after=await snap();
 check(after.counts.total===0&&!after.running&&after.clock===0,'reset empties/stops/zeros');
 check(!after.scheduler.enabled&&!after.terminal.owner&&Object.keys(after.reserved).length===0,'reset no dangling locks');
 await api({op:'config',values:{ehsan_turn_s:480,headway_s:1200}});
 await page.evaluate(()=>{renderedData=false;return poll()});
 const config=(await snap()).config;
 await api({op:'add',section:'T21.2',line:'B'});await api({op:'run'});await page.waitForTimeout(500);
 await api({op:'esb',station:21,value:true});await api({op:'close',section:'T1.1',value:true});
 const pName=Object.keys((await snap()).points)[0];await api({op:'point_fault',point:pName,value:true});
 await confirmed();after=await snap();
 check(JSON.stringify(config)===JSON.stringify(after.config),'config retained');
 check(after.closed.length===0&&after.esb.length===0&&Object.values(after.points).every(p=>!p.owner&&!p.fault&&p.position==='N'),'closures/esb/points reset');
 await page.waitForTimeout(1000);check((await snap()).counts.total===0,'no automatic respawn');
 await page.screenshot({path:'/data/desktop_v108.png',fullPage:true});
 await page.click('[data-tab="service"]');await page.locator('.service-settings summary').click();await page.fill('#svcTurnA','100');await page.click('#svcCalculate');await page.waitForTimeout(600);
 check((await page.locator('#svcMessage').innerText()).includes('۴۲۰'),'clear Ehsan bound message');
 await page.fill('#svcTurnA','420');await page.fill('#svcFleet','6');await page.click('#svcCalculate');await page.waitForTimeout(1000);
 check((await page.locator('#svcSummary').innerText()).includes('برنامه قابل اجرا نیست'),'clear insufficient fleet summary');
 await page.fill('#svcFleet','7');await page.click('#svcCalculate');await page.waitForTimeout(1000);
 check((await page.locator('#svcSummary').innerText()).includes('با این مدل سازگار است'),'valid plan');
 await page.setViewportSize({width:390,height:844});await page.click('[data-tab="operations"]');await page.waitForTimeout(500);
 check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'mobile no page overflow');
 await page.screenshot({path:'/data/mobile_v108.png',fullPage:true});
 check(errors.length===0,'browser errors: '+errors.join(','));
 const report={passed:true,checks:['first/repeated track click','keyboard Enter/Space','red occupancy unchanged','orange route reservation unchanged','inspector cleared','cancel reset','reset while running','all runtime locks/closures/ESB/faults cleared','configuration preserved','no respawn','readable Ehsan range error','fleet rejection/valid timetable','mobile no overflow'],errors};
 fs.writeFileSync('/data/browser_v108.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
