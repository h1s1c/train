const {chromium}=require('playwright'),assert=require('assert');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/local/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:950}});page.setDefaultTimeout(180000);const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const api=obj=>page.evaluate(async obj=>await(await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)})).json(),obj);
 await page.goto('http://127.0.0.1:8940');await page.waitForFunction(()=>typeof state!=='undefined'&&state&&window.ServiceClockUI);await page.evaluate(()=>{window.ServiceClockUI.tehran=()=> '2026-11-07T10:00:00';});
 assert.equal(await page.locator('#shortReference').count(),0);
 await api({op:'config',values:{turn_s:240}});let one=await api({op:'map_add',section:'T18.2',label:'قطار ۱'});let two=await api({op:'map_add',section:'T8.2',label:'قطار ۲'});assert(one.ok&&two.ok);await page.evaluate(()=>poll());
 await page.selectOption('#shortLow','15');await page.selectOption('#shortHigh','19');await page.selectOption('#shortOrigin','high');await page.fill('#shortDeparture','2026-11-07T10:20');
 assert((await page.locator('#shortOrigin option').allTextContents()).join(' ').includes('میرزای شیرازی'));
 await page.locator('#short-step').screenshot({path:'/data/smart-desktop.png'});
 await page.click('#shortFind');await page.waitForFunction(()=>!shortBusy);let c=await page.locator('#shortCandidates').innerText();assert(c.includes('قطار ۱'),c);assert.equal(await page.evaluate(()=>state.clock_reference.datetime),'2026-11-07T10:00:00');
 await page.check('#shortModelOnly');await page.selectOption('#shortTrain',String(one.id));await page.click('#shortPreview');await page.waitForFunction(()=>!shortBusy);let text=await page.locator('#shortReport').innerText();assert(text.includes('پذیرفته شد'),text);assert(await page.locator('#shortApply').isEnabled());await page.click('#shortApply');await page.waitForFunction(()=>!shortBusy&&state.trains[0].short_loop);await page.locator('#mapwrap').screenshot({path:'/data/smart-map.png'});
 await page.click('[data-tab="planning"]');await page.selectOption('#shortTrain','reserve');assert(await page.locator('#shortReserveFields').isVisible());await page.setViewportSize({width:390,height:844});assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));await page.locator('#short-step').screenshot({path:'/data/smart-mobile.png'});assert.deepEqual(errors,[]);
 console.log('PASS: simplified form, automatic clock, real station names, candidate search, explicit partial-model warning, existing train apply, reserve controls, desktop/mobile');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
