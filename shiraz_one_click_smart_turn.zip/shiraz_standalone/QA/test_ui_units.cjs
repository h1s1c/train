const assert = require("node:assert/strict");
const units = require("../static/units.js");
assert.equal(units.secondsToMinutes(900), 15);
assert.equal(units.minutesToSeconds("15"), 900);
assert.equal(units.minutesToSeconds("0.5"), 30);
assert.equal(units.minutesToSeconds("7.5"), 450);
assert.equal(units.secondsToMinutes(3600), 60);
assert.equal(units.parameterDisplay("headway_s", 900), "15");
assert.equal(units.parameterDisplay("turn_s", 120), "120");
assert.equal(units.parameterDisplay("dwell_s", 20), "20");
assert.equal(units.isMinuteParameter("headway_s"), true);
for (const key of ["reaction_s", "dwell_s", "turn_s", "point_throw_s", "release_s"]) {
  assert.equal(units.isMinuteParameter(key), false);
}
assert.equal(units.formatClock(120), "00:02:00");
assert.equal(units.formatClock(3661.9), "01:01:01");
const display = units.parameterDisplay("reaction_s", 1);
assert.equal(units.parameterValue("reaction_s", display, display, "1"), 1);
assert.equal(units.parameterValue("headway_s", "20", "15", "900"), 1200);
assert.equal(units.parameterValue("train_length_m", "100", "100", "100"), 100);
assert.match(units.formatMinutes(3600), /۶۰/);
assert(!units.formatMinutes(3600).includes(":"));
for (const value of ["", " ", "NaN", Infinity]) {
  assert.throws(() => units.minutesToSeconds(value));
}
console.log("Headway-only minutes, seconds for physical durations, HH:MM:SS clock: PASS");