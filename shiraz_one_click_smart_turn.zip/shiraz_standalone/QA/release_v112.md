# Release 1.0.12 validation
- UI redesign: app bar with live status pill, KPI cards, grouped toolbar, sticky ARIA tabs (arrow keys, #hash persistence), dark control-room map, unified forms/tables/cards, light/dark theme toggle (localStorage).
- Fix: polling (700 ms) rebuilt trains/events/track-info DOM each tick -> lost clicks/focus. Now diffed via setHTML.
- Fix: overlapping "logic only" map labels (shown at zoom >= 2, smaller font).
- Fix: export revoked object URL synchronously; added error handling. Import input reset so the same file can be re-imported; map rebuilt after import.
- Fix: favicon 404; closed track colour visible on dark map; scale select synced with server state.
- Python unit tests: see tests_v112.txt. JS syntax checks passed. Browser (Chromium 1440x900 light/dark, 390x844 mobile): no page errors, no horizontal overflow.
- Simulation logic, geometry, ATP data and HTTP API unchanged.
- Fix: train marker moved backwards along its head circuit and jumped at circuit end (schematic polylines drawn left-to-right). Snapshot now exposes path_prev/path_next; map orients polylines and chains switch pieces along the travelled path. Verified over full A/B round trips and a 7-19 short loop (7200 samples): no backward motion within a circuit; track-boundary jumps 64 -> 3 (remaining are the schematic row wrap and yard drawing gaps). Browser at 10x: marker x strictly decreasing in direction A.
