# Release 1.0.11 validation
- Python: 118 tests passed, 73.337 seconds; full output tests_v111.txt.
- JavaScript syntax checks app.js/service.js: passed.
- Units: headway-only minutes, physical durations seconds, clock HH:MM:SS: passed.
- Browser: selected T19.1 placement; program clock returned 6 purple markers without adding physical vehicles; short loop applied to original ID 1, count remained 1, main headway remained 900 seconds, execution state preserved, yellow route shown.
- Browser conflict: second held train on shared circuit caused rejection; selected train retained original 1..21 profile; count remained 2.
- Browser mobile 390x844: no horizontal overflow, no page JavaScript errors.
- Runtime tests cover both directions, full short cycle, deferred same-direction return, original dispatch membership, frozen import, tampered turn budget rejection, resource conflicts, point-readiness placement guard.
- Forecast exact 0.1-second tick, matching runtime. Finite horizon, not field certification or an indefinite schedule feasibility proof.
- Geometry and ATP source hashes unchanged from 1.0.10. Local Vazirmatn retained.
