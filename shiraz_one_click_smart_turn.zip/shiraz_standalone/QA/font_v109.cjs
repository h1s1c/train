const {chromium}=require('playwright');const fs=require('fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/local/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:1050}});let errors=[],external=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',r=>{if(new URL(r.request().url()).hostname!=='127.0.0.1'){external.push(r.request().url());return r.abort();}return r.continue();});
 await page.goto('http://127.0.0.1:8810');await page.evaluate(()=>document.fonts.ready);await page.waitForSelector('#svcMap text');
 let font=await page.evaluate(()=>({faces:[...document.fonts].map(f=>({family:f.family,status:f.status,weight:f.weight})),loaded:document.fonts.check('16px Vazirmatn','شبیه‌ساز خط شیراز'),styles:['body','h1','button','input','#svcMap text','#svcProfiles input'].map(s=>({selector:s,font:getComputedStyle(document.querySelector(s)).fontFamily}))}));
 if(!font.loaded||!font.faces.some(f=>f.family==='Vazirmatn'&&f.status==='loaded')||font.styles.some(s=>!s.font.startsWith('Vazirmatn')))throw Error('font not used '+JSON.stringify(font));
 await page.screenshot({path:'/data/font_desktop_v109.png',fullPage:true});
 await page.click('[data-tab="operations"]');
 const mapfont=await page.locator('#map text').first().evaluate(n=>getComputedStyle(n).fontFamily);if(!mapfont.startsWith('Vazirmatn'))throw Error('map font');
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'/data/font_mobile_v109.png',fullPage:true});
 const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);if(overflow||errors.length||external.length)throw Error(JSON.stringify({overflow,errors,external}));
 const report={passed:true,font,operationMapFont:mapfont,externalRequests:external,javascriptErrors:errors,mobileOverflow:overflow};
 fs.writeFileSync('/data/font_v109.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
