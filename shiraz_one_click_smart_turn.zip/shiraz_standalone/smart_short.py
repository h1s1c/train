"""Conservative, offline candidate selection; estimates are not field positions."""
import copy
from short_loop import clone, prepare, install
from timed_short import evaluate
from service_clock import ServiceClock, civil
from datetime import timedelta
import math

def planned(model,obj):
    plan=obj.get('plan')
    if not isinstance(plan,dict):return None
    if not model.clock_reference:return None
    now=civil(model.clock_reference['datetime'])+timedelta(seconds=model.clock-model.clock_reference['clock'])
    try:return ServiceClock(model,plan).calculate(now.isoformat(timespec='seconds'))
    except (ValueError,KeyError,TypeError):return None

def predicted_ready(model, obj):
    """First observed readiness at the origin in a non-mutating shadow run.

    Readiness alone is NOT an admissible dispatch. A separate complete
    round-trip conflict forecast is required for every proposed departure.
    """
    try:
        if not model.clock_reference: raise ValueError('ساعت مدل تنظیم نشده است.')
        origin=int(obj['origin']); low=int(obj['low']); high=int(obj['high'])
        if origin not in (low,high): raise ValueError('مبدأ باید یکی از دو ایستگاه انتخاب‌شده باشد.')
        p=prepare(model,obj,require_headway=False,direct_turn=(origin==high))
        shadow=clone(model); install(shadow,p); tr=shadow.trains[p['id']]
        # Park at the origin rather than releasing at an arbitrary trial time.
        tr['short_loop']['timed']=dict(due=shadow.clock+10801,origin=origin,
            destination=low if origin==high else high,direction='A' if origin==high else 'B',
            status='pending',datetime='2099-01-01T00:00:00',round_trip=True,turn_reached=False)
        start=shadow.clock
        for _ in range(72000):
            shadow.tick(.1)
            if shadow.global_stop or (shadow.scheduler.get('blocked_reason') and not shadow.scheduler['enabled']):
                raise ValueError('مدل پیش‌بینی در حال توقف حفاظتی است.')
            if tr.get('reason')=='منتظر ساعت اعزام تعیین‌شده':
                ref=model.clock_reference
                ready=civil(ref['datetime'])+timedelta(seconds=shadow.clock-ref['clock'])
                return {'ready':dict(valid=True,id=p['id'],label=model.trains[p['id']]['label'],
                                     seconds_from_now=max(0,shadow.clock-start),
                                     datetime=ready.isoformat(timespec='seconds'),certified=False)}
        raise ValueError('این قطار در دو ساعت پیش‌بینی به مبدأ آماده اعزام نرسید.')
    except (ValueError,KeyError,TypeError,IndexError,OverflowError) as exc:
        return {'ready':dict(valid=False,errors=[str(exc)],certified=False)}


def dispatch(model,obj):
    op=obj['op']; plan=planned(model,obj)
    known={t['label'] for t in model.trains.values()}
    unmapped=[v for v in plan['vehicles'] if v['status']!='reserve' and v['label'] not in known] if plan and plan['valid'] else []
    if op not in ('smart_short_candidates',) and (not plan or not plan['valid'] or unmapped) and obj.get('model_only_confirmed') is not True:
        raise ValueError('همه قطارهای برنامه زمانی در مدل ثبت نشده‌اند یا برنامه معتبر نیست. آنها را در مدل تعریف کنید؛ یا صریحاً بررسی محدود به قطارهای مدل را انتخاب کنید.')
    if op=='smart_short_predicted_ready':
        return predicted_ready(model,obj)
    if op in ('smart_short_existing_preview','smart_short_existing_apply'):
        return evaluate(model,obj,apply=op.endswith('_apply'))
    if op=='smart_short_candidates':
        rows=[]
        for t in model.trains.values():
            q=dict(obj,id=t['id']);result=evaluate(model,q)['short_loop']
            rows.append(dict(id=t['id'],label=t['label'],valid=result['valid'],errors=result['errors'],track=t['head']))
        extra=[]
        if plan and plan['valid']:
            labels={t['label'] for t in model.trains.values()}
            extra=[dict(label=v['label'],status=v['status'],track=v['track']) for v in plan['vehicles'] if v['status']!='reserve' and v['label'] not in labels]
        return {'candidates':rows,'unmapped':extra,'plan_valid':bool(plan and plan['valid'])}
    if not plan or not plan['valid']:raise ValueError('ابتدا برنامه ناوگان معتبر را محاسبه کنید تا تعداد ذخیره مشخص شود.')
    if abs(plan['headway_min']*60-model.config['headway_s'])>.01:raise ValueError('هدوی برنامه ناوگان با مدل یکسان نیست؛ ابتدا تنظیمات را در مدل خالی اعمال کنید.')
    labels={t['label'] for t in model.trains.values()}
    assigned={t['reserve_vehicle_id'] for t in model.trains.values() if t.get('reserve_vehicle_id')}
    available=[v for v in plan['vehicles'] if v['status']=='reserve' and v['label'] not in labels and v['id'] not in assigned]
    if len(assigned)>=plan['reserve']:available=[]
    if not available:raise ValueError('قطار ذخیره آزاد در برنامه محاسبه‌شده وجود ندارد یا همه آنها در مدل استفاده شده‌اند.')
    label=available[0]['label']; section=obj.get('section'); direction=obj.get('line')
    if direction not in ('A','B') or not isinstance(section,str):raise ValueError('تراک و جهت استقرار قطار ذخیره را مشخص کنید.')
    trial=clone(model);tid=trial.add_train(section,direction,label=label)
    trial.trains[tid]['reserve_vehicle_id']=available[0]['id']
    q=dict(obj,id=tid);r=evaluate(trial,q)['short_loop'];r['label']=label;r['remaining_reserve']=min(len(available)-1,plan['reserve']-len(assigned)-1)
    if not r['valid']:return {'short_loop':r}
    if op=='smart_short_reserve_apply':
        # The HTTP handler serializes actions under the model lock. No change is
        # made until the exact new train and schedule have passed the shadow run.
        before_next=model.next_id;before_events=copy.deepcopy(model.events);before_reserved=copy.deepcopy(model.reserved);before_release=copy.deepcopy(model.release_until)
        realid=model.add_train(section,direction,label=label)
        model.trains[realid]['reserve_vehicle_id']=available[0]['id']
        real=evaluate(model,dict(q,id=realid),apply=True)['short_loop']
        if not real['valid']:
            model.trains.pop(realid,None);model.next_id=before_next;model.events=before_events;model.reserved=before_reserved;model.release_until=before_release
            return {'short_loop':real}
        real['label']=label;real['remaining_reserve']=min(len(available)-1,plan['reserve']-len(assigned)-1);r=real
    return {'short_loop':r}
