"""Read-only parser of the supplied MainIO encoded configuration. No device I/O."""
import hashlib
from pathlib import Path
FILE_KEY=0x0AAAAAAA00000000

def rotate_low(v,shift,width):
    if width==0:return v
    mask=(1<<width)-1;shift%=width;x=v&mask
    return (v&~mask)|(((x>>shift)|(x<<(width-shift)))&mask)

def decode_bytes(raw):
    chunks=[];end=len(raw)//8*8
    for i in range(0,end,8):
        x=int.from_bytes(raw[i:i+8],'little')^FILE_KEY
        x^=((x&0x1fffffff)>>17)+255
        x=rotate_low(x,12,15);x=rotate_low(x,12,18)
        x=rotate_low(x^rotate_low(0xaaaaaa,12,24),12,24)
        chunks.append(x.to_bytes(8,'little'))
    return b''.join(chunks)+raw[end:]

def read_logic(path):
    raw=Path(path).read_bytes();decoded=decode_bytes(raw);text=decoded.decode('ascii')
    sections={};section=None
    for no,line in enumerate(text.splitlines(),1):
        s=line.strip()
        if s.startswith('['):
            label=s.split(']')[0][1:]
            section=None if label=='End' else label
            if section:sections[section]={'rows':[],'count':None,'headers':[]}
        elif section:
            if s.startswith('#'):sections[section]['headers'].append(s)
            elif s.startswith('(') and s.endswith(')'):
                sections[section]['rows'].append({'values':s[1:-1].split(','),'line':no})
            elif s.isdigit():sections[section]['count']=int(s)
    for name,table in sections.items():
        if table['count']!=len(table['rows']):raise ValueError('Invalid table size: '+name)
    return sections,{'file':'logic.mhr','sha256':hashlib.sha256(raw).hexdigest(),
        'decoded_sha256':hashlib.sha256(decoded).hexdigest(),
        'generated_header':next(l for l in text.splitlines() if l.startswith('#Generated'))}
