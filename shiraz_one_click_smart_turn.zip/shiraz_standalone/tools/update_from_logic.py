"""Build a source-backed model from logic.mhr; schematic is rendering only."""
from pathlib import Path
import sys,json,re,collections,copy,hashlib,csv
from read_logic import read_logic
ROOT=Path(__file__).resolve().parents[1]
def path_between(graph,start,end,allowed):
    q=collections.deque([[start]]);seen={start}
    while q:
        path=q.popleft()
        if path[-1]==end:return path
        for n in sorted(graph.get(path[-1],[])):
            if n in allowed and n not in seen:seen.add(n);q.append(path+[n])
    raise ValueError('No configured path: '+start+' -> '+end)
def build(source,base):
    s,meta=read_logic(source);d=copy.deepcopy(base)
    # User-provided display-name corrections; baseline/source evidence stays unchanged.
    corrected_names={2:'شهید دوران',20:'دکتر شریعتی'}
    for station in d['stations']:
        if station['id'] in corrected_names:station['name']=corrected_names[station['id']]
    for station in d['turnbacks']:
        if station['station'] in corrected_names:station['name']=corrected_names[station['station']]
    byid={int(r['values'][0]):r['values'][1] for r in s['Track']['rows']}
    atp=collections.defaultdict(lambda:collections.defaultdict(set));states=[]
    for r in s['ATPSeq']['rows']:
        f=list(map(int,r['values']));states.append(f)
        if f[0] in byid:atp[byid[f[0]]][str(f[9])].add(f[6])
    links=[];graph={n:set() for n in byid.values()}
    for r in s['TrackLink']['rows']:
        f=list(map(int,r['values']))
        if f[1] in byid and f[2] in byid and f[1]!=f[2]:
            a,b=byid[f[1]],byid[f[2]];graph[a].add(b)
            links.append(dict(track=a,next=b,dir=f[3],point_pos=f[4],point_id=f[5]))
    points={}
    for r in s['Point']['rows']:
        f=r['values'];points[f[1]]=dict(id=f[1],logic_id=int(f[0]),track=byid[int(f[2])])
    platform_ids={int(r['values'][2]) for r in s['Platform']['rows']}
    caps=collections.defaultdict(dict)
    for f in states:
        if f[0] in byid and f[6]>0:
            key=(byid.get(f[4]),f[9],f[5])
            caps[byid[f[0]]][key]=min(caps[byid[f[0]]].get(key,f[6]),f[6])
    rows={}
    for r in s['Track']['rows']:
        f=r['values'];ident,name,typ,length=int(f[0]),f[1],int(f[2]),int(f[3]);st=int(re.search(r'\d+',name)[0])
        t=copy.deepcopy(base['tracks'].get(name,{}))
        speeds=sorted({v for vals in atp[name].values() for v in vals if v>0})
        t.update(id=name,logic_id=ident,station=st,length_m=length,length_source='logic.mhr:[Track].Length',
            length_configured=True,length_verified=False,length_source_line=r['line'],
            speed_kmh=min(speeds) if speeds else None,speed_source='logic.mhr:[ATPSeq].MyCeilingSpeed:positive_route_envelope',
            speed_configured=bool(speeds),speed_verified=False,speed_mode='atp_positive_route_envelope',
            atp_ceiling_values={k:sorted(v) for k,v in atp[name].items()},track_type=typ,
            platform=ident in platform_ids,yard=st==22,has_atp=bool(int(f[4])),
            point=next((p for p,v in points.items() if v['track']==name),None),
            point_names=[p for p,v in points.items() if v['track']==name],
            atp_route_caps=[dict(next=k[0],dir=k[1],point_pos=k[2],ceiling_kmh=v) for k,v in caps[name].items()])
        if not t.get('polylines'):
            # No physical geometry invented: a labeled inset for source-only equipment.
            i=sum(bool(x.get('drawing_source_only')) for x in rows.values())
            y=650+25*i;t['polylines']=[[[160+200*i,y],[280+200*i,y]]];t['drawing_source_only']=True
        t.pop('schematic_length_m',None)
        rows[name]=t
    d['tracks']=rows;d['points']=points;d['graph']={n:sorted(v) for n,v in graph.items()};d['configured_links']=links
    chains={}
    for side,line,start,end in [(1,'A','T21.1','T1.1'),(2,'B','T1.2','T21.2')]:
        allowed={n for n in rows if re.match(r'^(T|TP)\d+\.'+str(side)+r'(\.|$)',n)}
        chains[line]=path_between(graph,start,end,allowed)
    d['chains']=chains
    turns=[]
    for old in d['turnbacks']:
        st=old['station'];allowed={n for n,t in rows.items() if t['station']==st}
        a,b=f'T{st}.1',f'T{st}.2'
        try:
            ab=path_between(graph,a,b,allowed);ba=path_between(graph,b,a,allowed)
        except ValueError:
            d.setdefault('excluded_turnbacks',[]).append(dict(station=st,reason='No station-local A/B connection in supplied logic.mhr TrackLink; old drawing candidate removed'))
            continue
        turns.append(dict(station=st,name=old['name'],path_a_to_b=ab,path_b_to_a=ba,
            points=sorted({p for n in ab+ba for p in rows[n]['point_names']}),
            approval='configured_connectivity_candidate_not_operationally_approved'))
    d['turnbacks']=turns
    allowed={n for n,t in rows.items() if t['station']>=21}
    d['yard_inbound']=path_between(graph,'T21.2','T22.2.2',allowed)
    d['yard_outbound']=path_between(graph,'T22.2.2','T21.1',allowed-{'T21.2'})
    # Add source-only equipment as an explicitly labeled schematic inset.
    d['layout']['tracks']=[seg for seg in d['layout']['tracks'] if seg.get('name') in rows]
    for n,t in rows.items():
        if t.get('drawing_source_only'):
            d['layout']['tracks'].append(dict(name=n,pts=t['polylines'][0],ttype=t['track_type']))
            x,y=t['polylines'][0][0]
            d['layout']['texts'].append(dict(cap=n+' (logic only)',x=x,y=y-20,w=150,h=20))
    d['data_revision']='logic-'+meta['sha256'][:16]+'-v105'
    d['logic_source']=meta
    d['logic_source']['track_count']=len(rows)
    d['source_version']='standalone-1.0.5-logic-config'
    d['esb_timing']=dict(timer_id=20,name='It_Trigger_Emg_Stop',cycleVal=1,unit='logic_cycles',
        end_to_end_seconds=None,model_mode='immediate_scenario_freeze_not_physical_braking')
    d['limitations']=['No fresh field state supplied','Lengths are literal logic.mhr configuration, not an independent field survey',
      'ATP route envelopes use minimum positive compatible MyCeilingSpeed; not a complete online ATP/interlocking calculation',
      'Layout remains a legacy schematic and may not match configured topology geometrically',
      'Turnback connectivity is not operating-rule approval','ESB action is immediate scenario freeze, not measured communication or braking delay',
      'Actual braking, adhesion, gradients and current field revision need validation']
    d['provenance']=[p for p in d['provenance'] if p['file']!='logic.mhr']+[meta]
    return d,dict(header=s['ATPSeq']['headers'],rows=states,source_sha256=meta['sha256']),s
if __name__=='__main__':
    base=json.loads((ROOT/'QA/line_v104_baseline.json').read_text(encoding='utf-8'))
    d,atp,s=build(sys.argv[1],base)
    (ROOT/'data/line.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'data/atp_states.json').write_text(json.dumps(atp,separators=(',',':')),encoding='utf-8')
    print('Tracks',len(d['tracks']),'Points',len(d['points']))
    for k,v in d['chains'].items():print(k,len(v),sum(d['tracks'][n]['length_m'] for n in v),'m')
    for t in d['turnbacks']:print('Turn',t['station'],t['path_a_to_b'])
    print('L4 in',d['yard_inbound'],'out',d['yard_outbound'])
