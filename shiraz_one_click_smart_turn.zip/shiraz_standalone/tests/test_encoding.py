"""Regressions for Windows ANSI defaults and UTF-8 with a BOM."""
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import simulator


class EncodingTests(unittest.TestCase):
    def test_cp1252_default_does_not_affect_json_loading(self):
        raw = (simulator.ROOT / "data/line.json").read_bytes()
        # Prove this is the same type of failing file as the user's traceback.
        with self.assertRaises(UnicodeDecodeError):
            raw.decode("cp1252")
        real_read = Path.read_text
        seen = []

        def ansi_default(path, *args, **kwargs):
            if not args:
                kwargs.setdefault("encoding", "cp1252")
            seen.append(kwargs.get("encoding"))
            return real_read(path, *args, **kwargs)

        with patch.object(Path, "read_text", ansi_default):
            model = simulator.Simulator()
        self.assertEqual(seen, ["utf-8-sig"])
        self.assertEqual(len(model.tracks), 240)
        self.assertTrue(any(any(ord(c) > 127 for c in s["name"])
                            for s in model.data["stations"]))

    def test_windows_editor_utf8_bom_is_accepted(self):
        raw = (simulator.ROOT / "data/line.json").read_bytes()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/"data").mkdir()
            (root/"data/line.json").write_bytes(b"\xef\xbb\xbf" + raw)
            with patch.object(simulator, "ROOT", root):
                model = simulator.Simulator()
            self.assertEqual(len(model.tracks), 240)
            self.assertEqual(model.snapshot()["counts"]["total"], 0)


if __name__ == "__main__":
    unittest.main()