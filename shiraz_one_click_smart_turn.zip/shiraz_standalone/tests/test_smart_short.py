import unittest
from unittest.mock import patch
from simulator import Simulator
from short_loop import prepare,install

class SmartShortTests(unittest.TestCase):
    def setUp(self):
        self.s=Simulator();self.s.action(dict(op='short_clock_set',datetime='2026-10-13T06:15:00'))
        self.plan=dict(first_a='2026-10-13T05:30:00',last_a='2026-10-13T23:00:00',first_b='2026-10-13T05:30:00',last_b='2026-10-13T23:00:00',headway_min=15,fleet_count=8,run_a_s=2580,run_b_s=2580,turn_a_s=420,turn_b_s=120,dwell_s=20,profile_mode='estimated')
        self.req=dict(plan=self.plan,low=15,high=19,origin=19,departure='2026-10-13T06:35:00',line='B',section='T18.2',model_only_confirmed=True)
    def test_departure_from_ehsan_approach_is_visible(self):
        s=self.s;i=s.add_train('T21.1','A');p=prepare(s,dict(id=i,low=19,high=21));install(s,p)
        s.trains[i]['short_loop']['timed']=dict(due=1200,origin=19,destination=21,direction='B',status='pending',datetime='2026-10-13T06:35:00')
        paths=s.snapshot()['trains'][0]['short_route_paths']
        self.assertEqual(paths[0][0],'T21.1');self.assertIn('T19.1',paths[0]);self.assertIn('TP19.2',paths[1]);self.assertEqual(paths[-1][-1],'T21.2')
    def test_suggest_existing_and_show_unmapped_plan(self):
        self.s.add_train('T18.2','B',label='TR-001')
        with patch('smart_short.evaluate',return_value={'short_loop':{'valid':True,'errors':[]}}):
            r=self.s.action(dict(op='smart_short_candidates',**self.req))
        self.assertTrue(r['plan_valid']);self.assertEqual(r['candidates'][0]['label'],'TR-001');self.assertEqual(len(r['unmapped']),6)
    def test_reserve_consumption_survives_export_import(self):
        def fake(m,q,apply=False):
            return {'short_loop':dict(valid=True,applied=apply,errors=[],id=q['id'])}
        with patch('smart_short.evaluate',side_effect=fake):
            r=self.s.action(dict(op='smart_short_reserve_apply',**self.req))['short_loop']
            self.assertEqual(r['label'],'TR-008');self.assertEqual(r['remaining_reserve'],0)
            with self.assertRaisesRegex(ValueError,'ذخیره'):
                self.s.action(dict(op='smart_short_reserve_apply',**self.req))
        restored=Simulator();restored.import_scenario(self.s.export())
        self.assertEqual(restored.trains[r['id']]['reserve_vehicle_id'],8)
        with self.assertRaisesRegex(ValueError,'ذخیره'):
            restored.action(dict(op='smart_short_reserve_preview',**self.req))
    def test_incomplete_fleet_requires_explicit_confirmation(self):
        self.s.add_train('T18.2','B',label='TR-001')
        self.req['model_only_confirmed']=False
        with self.assertRaisesRegex(ValueError,'همه قطارهای'):
            self.s.action(dict(op='smart_short_existing_preview',id=1,**self.req))
        self.assertNotIn('short_loop',self.s.trains[1])
    def test_export_preserves_event_history(self):
        self.s.log('SHORT_FINISH','گردش کوتاه در ST19 پایان یافت',1)
        restored=Simulator();restored.import_scenario(self.s.export())
        self.assertTrue(any(e['kind']=='SHORT_FINISH' for e in restored.events))
    def test_no_reserve_fails_without_creating_train(self):
        self.plan['fleet_count']=7
        with self.assertRaisesRegex(ValueError,'ذخیره'):
            self.s.action(dict(op='smart_short_reserve_apply',**self.req))
        self.assertEqual(len(self.s.trains),0)
