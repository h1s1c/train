import copy
import unittest
from simulator import Simulator, ModelError
from service_clock import number

class ResetLineTests(unittest.TestCase):
    def setUp(self):self.s=Simulator()
    def reset(self):return self.s.action(dict(op='reset_line',confirm=True))
    def test_confirmation_required_and_no_mutation(self):
        self.s.add_train('T21.1','A')
        for value in (None,False,1,'true'):
            with self.assertRaises(ModelError):self.s.action(dict(op='reset_line',confirm=value))
            self.assertEqual(len(self.s.trains),1)
    def test_running_model_stopped_and_all_runtime_states_cleared(self):
        self.s.add_train('T21.2','B');self.s.advance(30)
        self.s.closed.add('T1.1');self.s.esb.add(2);self.s.release_until['T1.2']=100
        self.s.global_stop=True;self.s.running=True;self.s.scale=60
        p=next(iter(self.s.points.values()));p.update(fault=True,target='R',owner=1,ready_at=200)
        self.s.scheduler.update(enabled=True,issued=9,blocked_reason='test')
        self.assertEqual(self.reset()['removed_trains'],1)
        self.assertFalse(self.s.running);self.assertFalse(self.s.global_stop)
        for x in ('trains','reserved','release_until','closed','esb'):self.assertFalse(getattr(self.s,x),x)
        self.assertEqual(self.s.clock,0);self.assertEqual(self.s.scale,1)
        self.assertIsNone(self.s.terminal['owner']);self.assertFalse(self.s.terminal['overrun'])
        self.assertFalse(self.s.scheduler['enabled']);self.assertEqual(self.s.scheduler['issued'],0)
        for p in self.s.points.values():
            self.assertEqual(p,dict(position='N',target='N',ready_at=0,fault=False,owner=None))
        self.assertEqual(len(self.s.events),1);self.assertEqual(self.s.events[0]['kind'],'RESET')
    def test_user_data_and_config_are_preserved(self):
        self.s.set_config(dict(ehsan_turn_s=480,headway_s=1200))
        self.s.tracks['T1.1']['length_m']=333
        self.s.timetable.update(run_a_s=2700,run_b_s=2600)
        before=copy.deepcopy((self.s.tracks,self.s.config,self.s.timetable,self.s.profile))
        self.s.add_train('T21.1','A');self.reset()
        self.assertEqual(before,(self.s.tracks,self.s.config,self.s.timetable,self.s.profile))
    def test_old_shunt_reservations_do_not_block_new_train(self):
        self.s.add_train('T21.2','B');self.s.advance(60);self.reset()
        tid=self.s.add_train('T21.2','B');self.assertEqual(tid,1)
        self.s.advance(421);self.assertEqual(self.s.trains[tid]['head'],'T21.1')
    def test_no_auto_respawn_after_reset(self):
        self.s.action(dict(op='schedule',value=True,limit=7));self.s.advance(.1)
        self.reset();self.s.advance(1800);self.assertFalse(self.s.trains)
    def test_empty_reset_is_idempotent(self):
        self.assertEqual(self.reset()['removed_trains'],0)
        self.assertEqual(self.reset()['removed_trains'],0)
    def test_readable_config_bounds_in_display_units(self):
        with self.assertRaisesRegex(ModelError,'0.5.*60'):self.s.set_config(dict(headway_s=2))
        with self.assertRaisesRegex(ModelError,'گردش احسان.*420.*3600'):self.s.set_config(dict(ehsan_turn_s=5))
        with self.assertRaisesRegex(ModelError,'طول قطار'):self.s.set_config(dict(train_length_m='abc'))
    def test_readable_service_range(self):
        with self.assertRaisesRegex(ValueError,'30.*3600'):number(9,30,3600,'زمان گردش (ثانیه)')
