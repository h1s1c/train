import unittest
from unittest.mock import patch
from simulator import Simulator
from short_loop import direct_turn_legs

class DirectRoundTrip(unittest.TestCase):
    def setUp(self):
        self.s=Simulator(); self.s.config['headway_s']=900
        self.i=self.s.add_train('T21.1','A',label='101')
        self.s.action(dict(op='short_clock_set',datetime='2026-11-08T10:00:00'))
        self.q=dict(id=self.i,low=19,high=21,origin=21,departure='2026-11-08T10:01:00')

    def test_crossover_continues_directly_and_finishes_at_origin(self):
        s,i=self.s,self.i
        r=s.action(dict(op='timed_short_apply',**self.q))['short_loop']
        self.assertTrue(r['valid'],r['errors']); self.assertEqual([x['id'] for x in r['stations']],[21,20,19]); self.assertEqual([x['id'] for x in r['return_stations']],[19,20,21])
        t=s.trains[i]; path=[]; samples=[]; was_turn=False; restored=False
        for _ in range(25000):
            s.tick(.1)
            if not path or path[-1]!=t['head']: path.append(t['head'])
            if t.get('short_loop',{}).get('timed',{}).get('turn_reached'): was_turn=True
            if was_turn and t.get('short_loop') and t['head'] in ('TP19.1','TP19.2','T19.2.2'): samples.append((t['head'],t['pos'],t['speed'],t['legs'][t['leg']]['kind']))
            if not restored and t['head']=='TP19.2' and t['legs'][t['leg']]['kind']=='turn':
                saved=Simulator(); saved.import_scenario(s.export())
                self.assertTrue(saved.trains[i]['short_loop']['direct_turn']); self.assertTrue(saved.trains[i]['hold'])
                saved.action(dict(op='hold',id=i,value=False)); saved.advance(1200)
                self.assertNotIn('short_loop',saved.trains[i]); self.assertFalse(saved.global_stop); restored=True
            if not t.get('short_loop'): break
        self.assertTrue(was_turn); self.assertTrue(restored); self.assertNotIn('short_loop',t); self.assertFalse(s.global_stop)
        n=path.index('T19.1'); self.assertEqual(path[n:n+6],['T19.1','TP19.1','TP19.2','T19.2.2','T20.2.3','T20.2.1'])
        self.assertNotIn('T19.2',path[n:]); self.assertTrue(any(x[0]=='TP19.2' and x[2]>0 for x in samples))
        self.assertTrue(any(e['kind']=='SHORT_FINISH' and 'ST21' in e['message'] for e in s.events))
        self.assertEqual([e['kind'] for e in s.events].count('SHORT_FINISH'),1)

    def test_headway_alone_does_not_reject_but_wait_conflict_does(self):
        s,i=self.s,self.i; calls=[]
        def fake(shadow,seconds,selected,region):
            calls.append(1)
            if len(calls)==2:
                shadow.trains[i].pop('short_loop');shadow.trains[i]['timed_result']=dict(status='completed',datetime=self.q['departure'])
            return dict(error=None,waits={},arrivals={(19,'B'):[(0,2),(455,i)]})
        with patch('timed_short.forecast',side_effect=fake):
            r=s.action(dict(op='timed_short_preview',**self.q))['short_loop']
        self.assertTrue(r['valid'],r['errors'])
        calls=[]
        def conflict(shadow,seconds,selected,region):
            calls.append(1)
            if len(calls)==2:
                shadow.trains[i].pop('short_loop');shadow.trains[i]['timed_result']=dict(status='completed',datetime=self.q['departure'])
                return dict(error=None,waits={(i,2,'تراک T20.2'):{1,2}},arrivals={})
            return dict(error=None,waits={},arrivals={})
        with patch('timed_short.forecast',side_effect=conflict):
            r=s.action(dict(op='timed_short_preview',**self.q))['short_loop']
        self.assertFalse(r['valid']); self.assertTrue(any('تداخل' in e for e in r['errors']))

    def test_blocked_return_track_rejects_with_conflict(self):
        s,i=self.s,self.i
        other=s.add_train('T20.2','B',label='102')
        s.action(dict(op='hold',id=other,value=True))
        result=s.action(dict(op='timed_short_preview',**self.q))['short_loop']
        self.assertFalse(result['valid'])
        self.assertTrue(any('تداخل' in msg and 'T20.2' in msg for msg in result['errors']))
        self.assertNotIn('short_loop',s.trains[i]);self.assertTrue(s.trains[other]['hold'])

    def test_graph_has_direct_crossover_and_missing_path_fails_closed(self):
        legs=direct_turn_legs(self.s,19,21)
        self.assertEqual(legs[1]['nodes'],['T19.1','TP19.1','TP19.2','T19.2.2'])
        self.assertEqual(legs[2]['nodes'][0],'T19.2.2')
        with self.assertRaises(ValueError):direct_turn_legs(self.s,1,21)

if __name__=='__main__':unittest.main()
