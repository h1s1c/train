import copy
import unittest
from simulator import Simulator, ModelError
from service_clock import ServiceClock

class ServiceSeedTests(unittest.TestCase):
    def setUp(self):
        self.s=Simulator();self.now='2026-10-13T06:15:10'
        self.p=dict(first_a='2026-10-13T05:30:00',last_a='2026-10-13T23:00:00',first_b='2026-10-13T05:30:00',last_b='2026-10-13T23:00:00',headway_min=15,fleet_count=8,run_a_s=2580,run_b_s=2580,turn_a_s=420,turn_b_s=120,dwell_s=20,profile_mode='estimated',labels=['101','102','103','104','105','106','107','108'])
    def act(self,op):
        obj=dict(op=op,plan=self.p,now=self.now)
        if op=='service_seed_apply':obj['expected']=self.s.action(dict(op='service_seed_preview',plan=self.p,now=self.now))['seed']
        return self.s.action(obj)
    def test_preview_has_no_mutation_and_clearly_reports_unknown_and_reserve(self):
        before=copy.deepcopy(self.s.export());r=self.act('service_seed_preview')['seed'];after=self.s.export();before.pop('exported_at');after.pop('exported_at');self.assertEqual(before,after)
        self.assertEqual(len(r['placed']),6);self.assertEqual([x['label'] for x in r['unresolved']],['102']);self.assertEqual([x['label'] for x in r['reserves']],['108']);self.assertFalse(r['complete'])
    def test_apply_positions_and_footprints_are_consistent(self):
        original=ServiceClock(self.s,self.p).calculate(self.now);r=self.act('service_seed_apply')['seed'];self.assertTrue(r['applied']);self.assertEqual(len(self.s.trains),6);self.assertFalse(self.s.running);self.assertEqual(self.s.clock_reference['datetime'],self.now)
        planned={v['label']:v for v in original['vehicles']}
        for t in self.s.trains.values():
            v=planned[t['label']];self.assertEqual(t['head'],v['track']);self.assertAlmostEqual(t['pos'],v['head_m']);self.assertEqual(t['line'],v['direction']);self.assertEqual(t['speed'],0)
            self.assertGreaterEqual(t['pos']+sum(self.s.length(n) for n in t['sections'][:-1]),self.s.config['train_length_m']-0.0001)
        self.s.owners();self.assertFalse(self.s.scheduler['enabled']);self.s.advance(100);self.assertFalse(self.s.global_stop)
        fresh=Simulator();fresh.import_scenario(self.s.export());self.assertEqual(len(fresh.trains),6);self.assertTrue(all(x['hold'] for x in fresh.trains.values()))
    def test_closed_track_never_fabricates_a_position(self):
        self.s.closed.add('T17.2.7');r=self.act('service_seed_apply')['seed'];self.assertNotIn('104',[x['label'] for x in r['placed']]);self.assertIn('104',[x['label'] for x in r['unresolved']]);self.assertNotIn('T17.2.7',self.s.owners())
    def test_never_changes_existing_or_running_model(self):
        self.s.add_train('T21.1','A',label='existing');before=copy.deepcopy(self.s.trains)
        with self.assertRaisesRegex(ModelError,'بدون قطار'):self.act('service_seed_apply')
        self.assertEqual(self.s.trains,before)
        other=Simulator();other.running=True
        with self.assertRaises(ModelError):other.action(dict(op='service_seed_apply',plan=self.p,now=self.now))
    def test_no_known_locations_refuses_apply(self):
        self.now='2026-10-13T05:00:00';before=copy.deepcopy(self.s.export())
        with self.assertRaisesRegex(ModelError,'هیچ قطاری'):self.act('service_seed_apply')
        after=self.s.export();before.pop('exported_at');after.pop('exported_at');self.assertEqual(before,after)
    def test_insufficient_fleet_rejected(self):
        self.p['fleet_count']=6;self.p['labels']=[]
        with self.assertRaisesRegex(ModelError,'معتبر نیست'):self.act('service_seed_apply')
        self.assertEqual(len(self.s.trains),0)
    def test_missing_train_blocks_full_smart_short_check(self):
        self.act('service_seed_apply')
        q=dict(op='smart_short_existing_preview',plan=self.p,id=1,low=19,high=21,origin=21,departure='2026-10-13T06:35:00',model_only_confirmed=False)
        with self.assertRaisesRegex(ValueError,'همه قطارهای'):self.s.action(q)
    def test_stale_preview_is_rejected_without_mutation(self):
        preview=self.act('service_seed_preview')['seed'];self.s.closed.add('T17.2.7');before=copy.deepcopy(self.s.export())
        with self.assertRaisesRegex(ModelError,'پیش‌نمایش تغییر'):self.s.action(dict(op='service_seed_apply',plan=self.p,now=self.now,expected=preview))
        after=self.s.export();before.pop('exported_at');after.pop('exported_at');self.assertEqual(before,after)
    def test_approaching_platform_does_not_skip_stop(self):
        self.now='2026-10-13T05:31:28';r=self.act('service_seed_apply')['seed']
        t=next(x for x in self.s.trains.values() if x['label']=='101');self.assertEqual(t['head'],'T20.1');self.assertNotIn(t['index'],t['served'])
        self.s.advance(100)
        self.assertTrue(any(e['kind']=='BERTH' and e['train']==t['id'] and 'T20.1' in e['message'] for e in self.s.events))
    def test_station_dwell_uses_remaining_scheduled_time(self):
        self.now='2026-10-13T06:15:00';rec=ServiceClock(self.s,self.p).calculate(self.now);v=next(x for x in rec['vehicles'] if x['status']=='station');r=self.act('service_seed_apply')['seed'];t=next(x for x in self.s.trains.values() if x['label']==v['label']);self.assertEqual(t['state'],'dwell');self.assertGreater(t['dwell_until'],self.s.clock);self.assertTrue(t['doors'])

if __name__=='__main__':unittest.main()
