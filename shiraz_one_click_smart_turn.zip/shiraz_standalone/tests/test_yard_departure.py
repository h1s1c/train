import unittest
from simulator import Simulator

class YardDepartureTests(unittest.TestCase):
    def make(self):
        s=Simulator();i=s.action(dict(op='map_add',section='T22.2.2',line='A',label='قطار پایانه'))['id']
        s.action(dict(op='short_clock_set',datetime='2026-11-08T10:00:00'))
        return s,i,dict(id=i,low=19,high=21,origin=21,departure='2026-11-08T10:15:00')
    def test_unconnected_yard_never_moves_train_to_station(self):
        s=Simulator()
        with self.assertRaisesRegex(ValueError,'اتصال خروج'):
            s.action(dict(op='map_add',section='T22.2.4'))
        self.assertFalse(s.trains)
    def test_occupied_yard_cannot_be_overwritten(self):
        s,i,_=self.make()
        with self.assertRaises(ValueError):s.action(dict(op='map_add',section='T22.2.2'))
        self.assertEqual(len(s.trains),1);self.assertEqual(s.trains[i]['head'],'T22.2.2')
    def test_closed_route_rejected_without_mutation(self):
        s,i,q=self.make();s.closed.add('TP22.3');r=s.action(dict(op='timed_short_apply',**q))['short_loop']
        self.assertFalse(r['valid']);self.assertNotIn('short_loop',s.trains[i]);self.assertEqual(s.trains[i]['head'],'T22.2.2')
    def test_yard_departure_reaches_ehsan_at_real_model_position_and_short_finishes(self):
        s,i,q=self.make();t=s.trains[i];r=s.action(dict(op='timed_short_apply',**q))['short_loop'];self.assertTrue(r['valid'],r['errors'])
        self.assertEqual(t['head'],'T22.2.2');self.assertEqual(t['legs'][0]['kind'],'dispatch');self.assertEqual(t['short_loop']['entry'],'yard_dispatch')
        self.assertEqual(s.snapshot()['trains'][0]['short_route_paths'][0][0],'T22.2.2')
        fresh=Simulator();fresh.import_scenario(s.export());self.assertEqual(fresh.trains[i]['head'],'T22.2.2');self.assertEqual(fresh.trains[i]['short_loop']['entry'],'yard_dispatch')
        visited=set();first_station=None;mid_import=False
        for _ in range(30000):
            s.tick(.1);visited.add(t['head'])
            if t['head']=='TP22.3' and not mid_import:
                restored=Simulator();restored.import_scenario(s.export());self.assertTrue(restored.trains[i]['hold']);self.assertEqual(restored.terminal['owner'],i)
                restored.action(dict(op='hold',id=i,value=False));restored.advance(2600);self.assertFalse(restored.global_stop);self.assertNotIn('short_loop',restored.trains[i]);mid_import=True
            if t['head']=='T21.1' and first_station is None:first_station=s.clock
            if not t.get('short_loop'):break
        for track in ['T22.2.2','TP22.4','TP22.3','TP22.1','TP21.2','TP21.1','T21.1','T20.1','T19.1']:self.assertIn(track,visited)
        self.assertTrue(mid_import);self.assertIsNotNone(first_station);self.assertGreater(first_station,0);self.assertLess(first_station,900)
        dep=next(e for e in s.events if e['kind']=='SHORT_DEPART');self.assertAlmostEqual(dep['time'],900,places=1)
        self.assertTrue(any(e['kind']=='SHORT_FINISH' and 'ST21' in e['message'] for e in s.events));self.assertNotIn('timed_result',t);self.assertFalse(s.global_stop)
    def test_new_obstruction_causes_report_not_late_departure(self):
        s,i,q=self.make();r=s.action(dict(op='timed_short_apply',**q))['short_loop'];self.assertTrue(r['valid'],r['errors'])
        s.closed.add('TP21.1');s.advance(950)
        self.assertEqual(s.trains[i]['short_loop']['timed']['status'],'missed')
        self.assertTrue(any(e['kind']=='SHORT_MISSED' for e in s.events));self.assertFalse(any(e['kind']=='SHORT_DEPART' for e in s.events))
        s.closed.clear();s.advance(300);self.assertFalse(any(e['kind']=='SHORT_DEPART' for e in s.events))
    def test_too_early_does_not_teleport_or_schedule(self):
        s,i,q=self.make();q['departure']='2026-11-08T10:01:00';r=s.action(dict(op='timed_short_apply',**q))['short_loop']
        self.assertFalse(r['valid']);self.assertEqual(s.trains[i]['head'],'T22.2.2');self.assertNotIn('short_loop',s.trains[i])
if __name__=='__main__':unittest.main()
