import copy
import math
import unittest
from simulator import Simulator, ModelError
from service_clock import ServiceClock


class TerminalTests(unittest.TestCase):
    def setUp(self):
        self.s=Simulator()
        self.plan=dict(first_a='2026-10-13T05:30:00',last_a='2026-10-13T23:00:00',
                       first_b='2026-10-13T05:30:00',last_b='2026-10-13T23:00:00',
                       headway_min=15,fleet_count=7,run_a_s=2580,run_b_s=2580,
                       turn_a_s=420,turn_b_s=120,profile_mode='estimated',dwell_s=20)

    def record(self,**changes):
        return dict(op='service_positions',plan=dict(self.plan,**changes),now='2026-10-13T06:15:00')

    def test_minimum_ehsan_time_not_bypassable(self):
        before=copy.deepcopy(self.s.config)
        for value in [0,120,419,float('nan'),float('inf')]:
            with self.assertRaises(ValueError): self.s.action(self.record(turn_a_s=value))
            with self.assertRaises(ModelError): self.s.set_config(dict(ehsan_turn_s=value))
        self.assertEqual(before,self.s.config)

    def test_seven_minute_cycle_includes_motion_not_extra_wait(self):
        tid=self.s.add_train('T21.2','B');tr=self.s.trains[tid]
        for i in range(5000):
            self.s.tick(.1)
            if tr['leg']==0:break
        self.assertAlmostEqual(self.s.clock,420.1,delta=.3)
        self.assertEqual(tr['served'],[0])
        self.assertEqual(tr['head'],'T21.1')
        self.assertFalse(self.s.global_stop)

    def test_lock_not_released_when_timer_expires_with_blocked_shunt(self):
        tid=self.s.add_train('T21.2','B');self.s.closed.add('T22.2.2')
        self.s.advance(500)
        self.assertEqual(self.s.terminal['owner'],tid)
        self.assertTrue(self.s.terminal['overrun'])
        self.assertEqual(self.s.trains[tid]['head'],'T21.2')
        self.assertFalse(self.s.check_clear('TP22.1',tid+1))
        self.assertFalse(self.s.global_stop)

    def test_following_train_cannot_enter_terminal_cycle(self):
        first=self.s.add_train('T21.2','B');self.s.tick(.1)
        second=self.s.add_train('T21.2.1','B')
        self.s.advance(200)
        self.assertEqual(self.s.terminal['owner'],first)
        self.assertNotEqual(self.s.trains[second]['head'],'T21.2')
        self.assertEqual(len(self.s.owners()),sum(len(t['sections']) for t in self.s.trains.values()))
        self.assertFalse(self.s.global_stop)

    def test_manual_insertion_on_locked_shunt_rejected(self):
        self.s.add_train('T21.2','B');self.s.tick(.1)
        with self.assertRaises(ModelError):self.s.add_train('T22.2.2','A')

    def test_lock_clearance_after_return(self):
        first=self.s.add_train('T21.2','B')
        self.s.advance(419)
        self.assertEqual(self.s.terminal['owner'],first)
        self.s.advance(2)
        self.assertIsNone(self.s.terminal['owner'])
        self.assertGreater(self.s.terminal['clear_after'],self.s.clock)
        self.assertFalse(self.s.check_clear('TP22.1',999))
        self.s.advance(2)
        self.assertTrue(self.s.check_clear('TP22.1',999))

    def test_deadline_miss_stops_automatic_dispatch(self):
        first=self.s.add_train('T21.2','B');self.s.closed.add('T22.2.2')
        self.s.action(dict(op='schedule',value=True,limit=7));self.s.action(dict(op='run'))
        self.s.advance(430)
        self.assertFalse(self.s.scheduler['enabled']);self.assertFalse(self.s.running)
        self.assertIn('گردش',self.s.scheduler['blocked_reason'])
        self.assertEqual(self.s.terminal['owner'],first)

    def test_missed_spawn_not_silently_retried_five_seconds_later(self):
        t=self.s.add_train('T21.1','A');self.s.trains[t]['hold']=True
        self.s.action(dict(op='schedule',value=True,limit=7));self.s.action(dict(op='run'))
        self.s.tick(.1)
        self.assertFalse(self.s.scheduler['enabled']);self.assertFalse(self.s.running)
        self.assertEqual(self.s.scheduler['next'],0)
        self.assertEqual(len(self.s.trains),1)
        self.assertTrue(any(x['kind']=='SCHEDULE_CONFLICT' for x in self.s.events))

    def test_seven_minutes_plus_release_headway_bound_in_both_views(self):
        cap=self.s.capacity()
        self.assertEqual(cap['planning_bound_s'],422)
        r=self.s.action(self.record())['service']
        self.assertEqual(r['minimum_headway_s'],422)
        for h in [5,7]:
            r=self.s.action(self.record(headway_min=h,fleet_count=50))['service']
            self.assertFalse(r['valid']);self.assertTrue(any('هدوی' in e for e in r['errors']))
            self.s.set_config(dict(headway_s=h*60))
            with self.assertRaises(ModelError):self.s.action(dict(op='schedule',value=True,limit=50))

    def test_phase_and_platform_conflict_even_above_base_headway(self):
        r=self.s.action(self.record(headway_min=8,fleet_count=30))['service']
        self.assertGreater(8*60,r['minimum_headway_s'])
        self.assertFalse(r['valid']);self.assertTrue(any('سکوی A' in e for e in r['errors']))
        self.assertTrue(all(v['status']=='conflict' for v in r['vehicles']))

    def test_insufficient_fleet_rejected_in_both_views(self):
        r=self.s.action(self.record(fleet_count=6))['service']
        self.assertEqual(r['required_fleet'],7);self.assertFalse(r['valid'])
        with self.assertRaises(ModelError):self.s.action(dict(op='schedule',value=True,limit=6))

    def test_valid_shared_settings_apply_atomically(self):
        obj=self.record(turn_a_s=480,fleet_count=8);obj['op']='service_apply'
        r=self.s.action(obj)['service']
        self.assertTrue(r['valid']);self.assertEqual(self.s.config['ehsan_turn_s'],480)
        self.assertEqual(self.s.config['headway_s'],r['headway_min']*60)
        self.assertEqual(self.s.capacity()['planning_bound_s'],482)
        self.assertFalse(self.s.scheduler['enabled']);self.assertFalse(self.s.running)

    def test_invalid_shared_settings_never_partially_apply(self):
        before=copy.deepcopy((self.s.config,self.s.profile,self.s.timetable))
        obj=self.record(headway_min=5,fleet_count=50);obj['op']='service_apply'
        with self.assertRaises(ModelError):self.s.action(obj)
        self.assertEqual(before,(self.s.config,self.s.profile,self.s.timetable))
        obj=self.record();obj['op']='service_apply';self.s.add_train()
        with self.assertRaises(ModelError):self.s.action(obj)

    def test_saved_lock_cannot_shorten_cycle_or_allow_second_owner(self):
        self.s.add_train('T21.2','B');self.s.advance(50)
        saved=self.s.export();other=Simulator();other.import_scenario(saved)
        self.assertEqual(other.terminal['owner'],self.s.terminal['owner'])
        self.assertEqual(other.terminal['ready_at'],self.s.terminal['ready_at'])
        corrupt=copy.deepcopy(saved);corrupt['terminal']['ready_at']=120
        with self.assertRaises(ModelError):other.import_scenario(corrupt)
        self.assertEqual(other.terminal['ready_at'],self.s.terminal['ready_at'])

    def test_legacy_mid_shunt_gets_conservative_new_lock(self):
        self.s.add_train('T22.2.2','A')
        saved=self.s.export();saved.pop('terminal');saved['config'].pop('ehsan_turn_s')
        other=Simulator();other.import_scenario(saved)
        self.assertIsNotNone(other.terminal['owner'])
        self.assertEqual(other.terminal['ready_at']-other.clock,420)

    def test_imported_served_stop_cannot_skip_remaining_budget(self):
        tid=self.s.add_train('T21.2','B');self.s.advance(380)
        saved=self.s.export();saved['trains'][0]['dwell_until']=0
        other=Simulator();other.import_scenario(saved);other.trains[tid]['hold']=False
        other.advance(10)
        self.assertEqual(other.trains[tid]['legs'][other.trains[tid]['leg']]['kind'],'dispatch')
        self.assertLess(other.clock,other.terminal['ready_at'])

    def test_import_cannot_falsely_mark_b_as_returned_a(self):
        self.s.add_train('T21.2','B');self.s.tick(.1)
        saved=self.s.export();saved['terminal']['returned']=True
        with self.assertRaises(ModelError):Simulator().import_scenario(saved)

    def test_requested_budget_480_honoured_without_double_count(self):
        self.s.set_config(dict(ehsan_turn_s=480))
        tid=self.s.add_train('T21.2','B')
        for _ in range(5000):
            self.s.tick(.1)
            if self.s.trains[tid]['leg']==0:break
        self.assertAlmostEqual(self.s.clock,480.1,delta=.3)

    def test_full_line_service_does_not_use_short_route_limit(self):
        self.s.profile=dict(low=7,high=19)
        r=self.s.action(self.record(headway_min=5,fleet_count=50))['service']
        self.assertFalse(r['valid']);self.assertGreaterEqual(r['minimum_headway_s'],422)


if __name__=='__main__':unittest.main()
