import copy
import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from simulator import Simulator, ModelError


class TimetableTests(unittest.TestCase):
    def setUp(self):
        self.s=Simulator()

    def test_reference_seven_active_eight_with_reserve(self):
        t=self.s.capacity()["timetable"]
        self.assertEqual(t["cycle_s"],5700)
        self.assertEqual(t["headway_s"],900)
        self.assertEqual((t["active_trains"],t["reserve"],t["total_trains"]),(7,1,8))
        self.assertFalse(t["certified"])
        self.assertEqual(t["source"],"legacy_reference_unverified")

    def test_asymmetric_and_reserve_separate(self):
        self.s.action(dict(op="plan",low=1,high=21,headway_s=900,
                           timetable=dict(run_a_s=2500,run_b_s=3000,reserve=2)))
        t=self.s.capacity()["timetable"]
        self.assertEqual(t["cycle_s"],6040)
        self.assertEqual(t["active_trains"],math.ceil(6040/900))
        self.assertEqual(t["total_trains"],t["active_trains"]+2)
        self.assertEqual(t["source"],"user_scenario_unverified")

    def test_short_route_does_not_reuse_full_line_time(self):
        self.s.action(dict(op="plan",low=7,high=19,headway_s=900))
        t=self.s.capacity()["timetable"]
        self.assertFalse(t["scope_matches"])
        self.assertIsNone(t["active_trains"])
        self.s.action(dict(op="plan",low=7,high=19,headway_s=900,
                           timetable=dict(run_a_s=1200,run_b_s=1300,reserve=0)))
        t=self.s.capacity()["timetable"]
        self.assertTrue(t["scope_matches"])
        self.assertEqual(t["active_trains"],4)

    def test_invalid_plan_is_atomic(self):
        old=copy.deepcopy((self.s.config,self.s.profile,self.s.timetable))
        for bad in [None,{},dict(run_a_s=0,run_b_s=2580,reserve=1),
                    dict(run_a_s=float("nan"),run_b_s=2580,reserve=1),
                    dict(run_a_s=2580,run_b_s=2580,reserve=1.5),
                    dict(run_a_s=2580,run_b_s=2580,reserve=1,low=7,high=19)]:
            with self.assertRaises(ModelError):
                self.s.action(dict(op="plan",low=1,high=21,headway_s=1200,timetable=bad))
            self.assertEqual(old,(self.s.config,self.s.profile,self.s.timetable))

    def test_export_import_timetable_and_legacy_compatibility(self):
        self.s.action(dict(op="plan",low=1,high=21,headway_s=450,
                           timetable=dict(run_a_s=2700,run_b_s=2600,reserve=3)))
        snap=self.s.export()
        other=Simulator()
        other.import_scenario(snap)
        self.assertEqual(other.timetable,self.s.timetable)
        self.assertEqual(other.capacity()["timetable"],self.s.capacity()["timetable"])
        snap.pop("timetable")
        other.import_scenario(snap)
        self.assertEqual(other.timetable["source"],"legacy_reference_unverified")

    def test_invalid_import_is_atomic(self):
        snap=self.s.export()
        snap["timetable"]["run_b_s"]=-1
        old=self.s.export()
        with self.assertRaises(ModelError):
            self.s.import_scenario(snap)
        self.assertEqual(old["timetable"],self.s.export()["timetable"])
        self.assertEqual(old["profile"],self.s.export()["profile"])

    def diagnostic(self,lengths,platforms=None,speeds=None):
        names=[]
        for i,length in enumerate(lengths):
            name=f"test-{i}"
            self.s.tracks[name]=dict(length_m=length,speed_kmh=(speeds or [72]*len(lengths))[i],
                                     platform=(platforms or [False]*len(lengths))[i])
            names.append(name)
        return self.s.leg_seconds(dict(kind="run",nodes=["unused-origin"]+names))

    def test_circuit_split_does_not_add_stops(self):
        whole=self.diagnostic([1000])
        split=self.diagnostic([100]*10)
        v=72/3.6;a=self.s.config["acceleration"];b=self.s.config["service_brake"]
        analytical=v/a+v/b+(1000-v*v/(2*a)-v*v/(2*b))/v
        self.assertAlmostEqual(whole,analytical)
        self.assertAlmostEqual(split,whole)
        self.assertGreater(self.diagnostic([500,500],[True,False]),whole)

    def test_triangle_and_speed_drop(self):
        value=self.diagnostic([20])
        a,b=self.s.config["acceleration"],self.s.config["service_brake"]
        peak=math.sqrt(2*20/(1/a+1/b))
        self.assertAlmostEqual(value,peak/a+peak/b)
        slow=self.diagnostic([500,500],speeds=[72,18])
        self.assertTrue(math.isfinite(slow))
        self.assertGreater(slow,self.diagnostic([500,500]))


if __name__=="__main__":
    unittest.main()