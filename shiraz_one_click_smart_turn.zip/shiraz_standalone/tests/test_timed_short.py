import copy
import unittest
from unittest.mock import patch
from short_loop import prepare, install
from simulator import Simulator

class TimedShortTests(unittest.TestCase):
    def make_one(self):
        s=Simulator();s.config['turn_s']=240
        i=s.add_train('T18.2','B');s.trains[i]['served']=[s.trains[i]['index']]
        s.action(dict(op='short_clock_set',datetime='2026-11-07T10:00:00'))
        req=dict(id=i,low=15,high=19,origin=19,departure='2026-11-07T10:20:00')
        return s,i,req

    def test_requires_clock_and_future_time(self):
        s,i,req=self.make_one();s.clock_reference=None
        self.assertFalse(s.action(dict(op='timed_short_preview',**req))['short_loop']['valid'])
        s.action(dict(op='short_clock_set',datetime='2026-11-07T10:00:00'))
        req['departure']='2026-11-07T09:59:00'
        self.assertFalse(s.action(dict(op='timed_short_apply',**req))['short_loop']['valid'])
        self.assertNotIn('short_loop',s.trains[i])

    def test_two_existing_trains_15_minute_departures_finish_once(self):
        s,i,req=self.make_one();j=s.add_train('T8.2','B');s.trains[j]['served']=[s.trains[j]['index']]
        first=s.action(dict(op='timed_short_apply',**req))['short_loop'];self.assertTrue(first['valid'],first['errors'])
        second=s.action(dict(op='timed_short_apply',id=j,low=15,high=19,origin=19,departure='2026-11-07T10:35:00'))['short_loop'];self.assertTrue(second['valid'],second['errors'])
        self.assertEqual(len(s.trains),2);before=s.next_id
        s.advance(5000);self.assertFalse(s.global_stop);self.assertEqual(s.next_id,before)
        for tid,due in [(i,1200),(j,2100)]:
            t=s.trains[tid];self.assertNotIn('short_loop',t);self.assertEqual((t['low'],t['high']),(1,21))
            self.assertNotIn('timed_result',t)
            dep=next(e for e in s.events if e['kind']=='SHORT_DEPART' and e['train']==tid)
            self.assertAlmostEqual(dep['time'],due,places=1)
            self.assertTrue(any(e['kind']=='SHORT_FINISH' and e['train']==tid and 'ST19' in e['message'] for e in s.events))
        for kind in ('SHORT_DEPART','SHORT_FINISH'):
            self.assertEqual(sum(e['kind']==kind for e in s.events),2)

    def test_new_blockage_at_due_reports_and_never_departs_late(self):
        s,i,req=self.make_one();r=s.action(dict(op='timed_short_apply',**req))['short_loop'];self.assertTrue(r['valid'],r['errors'])
        # A later blockage did not exist during the preview.
        s.closed.add('T19.1.1');s.advance(1500)
        t=s.trains[i];self.assertEqual(t['short_loop']['timed']['status'],'missed');self.assertFalse(any(e['kind']=='SHORT_DEPART' for e in s.events))
        self.assertTrue(any(e['kind']=='SHORT_MISSED' for e in s.events));self.assertTrue(t['hold']);self.assertNotIn('timed_result',t)
        s.closed.clear();s.advance(300);self.assertFalse(any(e['kind']=='SHORT_DEPART' for e in s.events))
        s.action(dict(op='short_return',id=i));self.assertEqual(t['short_loop']['timed']['status'],'cancelled')
        s.action(dict(op='hold',id=i,value=False));s.advance(800)
        self.assertNotIn('short_loop',t);self.assertFalse(any(e['kind']=='SHORT_DEPART' for e in s.events))

    def test_new_plan_cannot_break_prior_scheduled_trip(self):
        s,i,req=self.make_one();j=s.add_train('T8.2','B');s.trains[j]['served']=[s.trains[j]['index']]
        install(s,prepare(s,req))
        s.trains[i]['short_loop']['timed']=dict(due=1200,origin=19,destination=15,direction='A',status='pending',datetime='2026-11-07T10:20:00')
        calls=[]
        def fake_forecast(shadow, seconds, selected, region):
            calls.append(1)
            if len(calls)==1:
                shadow.trains[i].pop('short_loop')
                shadow.trains[i]['timed_result']=dict(status='completed',datetime='2026-11-07T10:20:00')
            else:
                shadow.trains[i]['short_loop']['timed']['status']='missed'
                shadow.trains[j].pop('short_loop')
                shadow.trains[j]['timed_result']=dict(status='completed',datetime='2026-11-07T10:35:00')
            return dict(error=None,waits={},arrivals={})
        with patch('timed_short.forecast',side_effect=fake_forecast):
            result=s.action(dict(op='timed_short_apply',id=j,low=15,high=19,origin=19,departure='2026-11-07T10:35:00'))['short_loop']
        self.assertFalse(result['valid']);self.assertTrue(any('تداخل' in error for error in result['errors']))
        self.assertNotIn('short_loop',s.trains[j]);self.assertEqual(s.trains[i]['short_loop']['timed']['status'],'pending')

    def test_future_plan_export_import_remains_held(self):
        s,i,req=self.make_one();r=s.action(dict(op='timed_short_apply',**req))['short_loop'];self.assertTrue(r['valid'],r['errors'])
        obj=s.export();restored=Simulator();restored.import_scenario(copy.deepcopy(obj))
        self.assertEqual(restored.clock_reference['datetime'],'2026-11-07T10:00:00')
        self.assertTrue(restored.trains[i]['hold']);self.assertEqual(restored.trains[i]['short_loop']['timed']['status'],'pending')
        self.assertAlmostEqual(restored.trains[i]['short_loop']['timed']['due'],1200)

    def test_incorrect_time_rejects_without_mutation(self):
        s,i,req=self.make_one();before=copy.deepcopy(s.trains);req['departure']='2026-11-07T10:01:00'
        r=s.action(dict(op='timed_short_apply',**req))['short_loop'];self.assertFalse(r['valid']);self.assertEqual(before,s.trains)
        self.assertTrue(any('اعزام' in e or 'زمان' in e for e in r['errors']))

if __name__=='__main__':unittest.main()
