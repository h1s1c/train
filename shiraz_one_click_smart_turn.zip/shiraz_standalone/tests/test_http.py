import json
import socket
import subprocess
import sys
import time
import unittest
import urllib.request
import urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
        cls.base = f"http://127.0.0.1:{port}"
        cls.process = subprocess.Popen([sys.executable, str(ROOT/"simulator.py"), "--port", str(port)],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            try:
                urllib.request.urlopen(cls.base+"/api/state", timeout=1).close()
                return
            except (OSError, urllib.error.URLError):
                time.sleep(.05)
        cls.process.terminate()
        raise RuntimeError("server did not start")

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate()
        cls.process.wait(timeout=5)

    def request(self, path, data=None, headers=None):
        req = urllib.request.Request(self.base+path, data=data, headers=headers or {})
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                return response.status, response.read()
        except urllib.error.HTTPError as err:
            return err.code, err.read()

    def test_get_state_and_data(self):
        status, data = self.request("/api/state")
        self.assertEqual(status, 200)
        self.assertIsNone(json.loads(data)["capacity"]["physical_line_capacity"])
        status, data = self.request("/api/line")
        self.assertEqual(status, 200)
        self.assertEqual(len(json.loads(data)["tracks"]), 240)

    def test_local_vazirmatn_font_is_served(self):
        status,data=self.request("/fonts/Vazirmatn-Variable.woff2")
        self.assertEqual(status,200)
        self.assertEqual(data[:4],b"wOF2")
        self.assertEqual(data,(ROOT/"static/fonts/Vazirmatn-Variable.woff2").read_bytes())
        self.assertEqual(self.request("/fonts/../simulator.py")[0],404)
        status,css=self.request("/style.css")
        self.assertIn(b'@font-face',css)
        self.assertIn(b'font-weight:100 900',css)
        self.assertNotIn(b'https://',css)

    def test_path_allowlist(self):
        for path in ("/simulator.py", "/../simulator.py", "/data/line.json", "/%2e%2e/simulator.py"):
            self.assertEqual(self.request(path)[0], 404)

    def test_service_clock_api_and_asset(self):
        status,data=self.request("/service.js")
        self.assertEqual(status,200)
        self.assertIn(b"ServiceClockUI",data)
        plan=dict(first_a="2026-10-13T05:30:00",last_a="2026-10-13T23:00:00",
                  first_b="2026-10-13T05:30:00",last_b="2026-10-13T23:00:00")
        body=json.dumps(dict(op="service_positions",plan=plan,now="2026-10-13T06:15:00")).encode()
        status,data=self.request("/api/action",body,{"Content-Type":"application/json"})
        result=json.loads(data)
        self.assertEqual(status,200)
        self.assertTrue(result["ok"])
        self.assertEqual(len(result["service"]["vehicles"]),7)
        self.assertFalse(result["service"]["live"])
        body=json.dumps(dict(op="service_positions",plan=plan,now="06:15")).encode()
        self.assertEqual(self.request("/api/action",body,{"Content-Type":"application/json"})[0],400)
        _,data=self.request("/api/state")
        self.assertEqual(json.loads(data)["counts"]["total"],0)

    def test_json_and_csrf_validation(self):
        self.assertEqual(self.request("/api/action", b"x", {"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.request("/api/action", b'{"op":"run"}',
            {"Content-Type": "application/json", "Origin": "https://evil.example"})[0], 403)
        for body in (b"[]", b"{", b'{"op":"unknown"}', b'{"op":"config","values":["acceleration"]}'):
            self.assertEqual(self.request("/api/action", body, {"Content-Type": "application/json"})[0], 400)

    def test_data_exports(self):
        status, data = self.request("/api/tracks.csv")
        self.assertEqual(status, 200)
        self.assertEqual(len(data.decode().splitlines()), 241)
        status, data = self.request("/api/export")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(data)["schema"], "shiraz-offline-scenario-v1")

    def test_minute_helper_is_served(self):
        status, data = self.request("/units.js")
        self.assertEqual(status, 200)
        self.assertIn(b"minutesToSeconds", data)


if __name__ == "__main__":
    unittest.main()