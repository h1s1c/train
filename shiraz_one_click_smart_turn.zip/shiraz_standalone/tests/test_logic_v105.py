import copy,json,sys,unittest,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tools')]
from simulator import Simulator,ModelError
from read_logic import read_logic

class LogicDataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw,cls.meta=read_logic(ROOT/'QA/logic_supplied.mhr')
        cls.reference={r['values'][1]:int(r['values'][3]) for r in cls.raw['Track']['rows']}
    def setUp(self):self.s=Simulator()
    def test_corrected_station_display_names(self):
        names={s['id']:s['name'] for s in self.s.data['stations']}
        self.assertEqual(names[2],'شهید دوران')
        self.assertEqual(names[20],'دکتر شریعتی')

    def test_rebuild_preserves_corrected_display_names(self):
        from update_from_logic import build
        baseline=json.loads((ROOT/'QA/line_v104_baseline.json').read_text(encoding='utf-8'))
        rebuilt,_,_=build(ROOT/'QA/logic_supplied.mhr',baseline)
        names={s['id']:s['name'] for s in rebuilt['stations']}
        self.assertEqual((names[2],names[20]),('شهید دوران','دکتر شریعتی'))
        self.assertNotEqual(baseline['stations'][1]['name'],names[2])

    def test_all_240_lengths_exact_and_not_rescaled(self):
        self.assertEqual(len(self.s.tracks),240)
        self.assertEqual(set(self.reference),set(self.s.tracks))
        for n,v in self.reference.items():
            self.assertEqual(self.s.length(n),v,n)
            self.assertTrue(self.s.tracks[n]['length_configured'])
            self.assertFalse(self.s.tracks[n]['length_verified'])
        self.assertEqual(self.meta['decoded_sha256'],'a449ab974094facda4ed95983a8a230aa51c03c18aa0cafab08486d9febeb3b0')
        self.assertEqual(sum(self.reference.values()),49536)
    def test_platform_lengths_are_not_assumed_100m(self):
        self.assertEqual(sum(t['platform'] for t in self.s.tracks.values()),40)
        self.assertEqual(self.s.length('T21.1'),150)
        self.assertEqual(self.s.length('T21.2'),150)
        self.assertEqual(self.s.length('T22.2.2'),115)
    def test_source_speed_sets_and_context_not_zero_or_maximum(self):
        t=self.s.tracks['T21.1']
        self.assertIn(0,t['atp_ceiling_values']['0'])
        self.assertEqual(self.s.speed('T21.1','run','T21.1.1'),50)
        self.assertEqual(self.s.speed('T21.1','turn','TP21.1'),15)
        self.assertEqual(self.s.speed('TP21.1','dispatch','T21.1'),10)
        self.assertEqual(self.s.speed('T21.1','run','TP21.1'),25)
        with self.assertRaises(ModelError):self.s.speed('T21.1','run','T1.1')
        for n in ['TP22.2','T22.1.0','T22.2.4','T22.2.6','T22.2.8']:
            self.assertIsNone(self.s.tracks[n]['speed_kmh'])
            with self.assertRaises(ModelError):self.s.speed(n)
    def test_every_service_edge_exists_in_source_and_has_speed(self):
        configured={(r['track'],r['next']) for r in self.s.data['configured_links']}
        turns=[x['station'] for x in self.s.data['turnbacks']]
        self.assertNotIn(18,turns)
        for low in turns:
            for high in turns:
                if low>=high:continue
                for leg in self.s.legs(low,high):
                    self.s.requirements(leg,leg['nodes'])
                    for i,(a,b) in enumerate(zip(leg['nodes'],leg['nodes'][1:])):
                        self.assertIn((a,b),configured)
                        self.assertGreater(self.s.route_speed(leg,i),0)
        self.assertIn('TP22.4',self.s.data['yard_outbound'])
        self.assertIn('T12.3',self.s.turn(12))
    def test_15_minute_dispatch_accepted_without_bypass(self):
        c=self.s.capacity()
        self.assertLess(c['planning_bound_s'],900)
        self.assertTrue(c['feasible_in_planner'])
        self.s.action(dict(op='schedule',value=True,limit=7))
        self.s.closed.add('T21.1');self.s.advance(5)
        self.assertEqual(len(self.s.trains),0)
        self.assertFalse(self.s.scheduler['enabled'])
        self.s.closed.clear();self.s.action(dict(op='schedule',value=True,limit=7));self.s.advance(6)
        self.assertEqual(len(self.s.trains),1)
        self.s.owners()
    def test_bad_or_legacy_source_data_cannot_restore_schematic_lengths(self):
        snap=self.s.export();before=self.s.export()
        bad=copy.deepcopy(snap);bad.pop('data_revision')
        with self.assertRaises(ModelError):self.s.import_scenario(bad)
        bad=copy.deepcopy(snap);bad['tracks']['T21.1']['length_m']=600
        with self.assertRaises(ModelError):self.s.import_scenario(bad)
        self.assertEqual(self.s.length('T21.1'),150)
        self.assertEqual(self.s.export()['config'],before['config'])
    def test_overrides_are_explicit_and_roundtrip(self):
        self.s.edit_track('T21.1',151,40)
        self.assertFalse(self.s.tracks['T21.1']['length_configured'])
        self.assertEqual(self.s.tracks['T21.1']['speed_mode'],'user_override')
        other=Simulator();other.import_scenario(self.s.export())
        self.assertEqual(other.length('T21.1'),151)
        self.assertEqual(other.speed('T21.1'),40)
    def test_esb_one_is_cycle_not_fake_second_delay(self):
        timing=self.s.snapshot()['esb_timing']
        self.assertEqual(timing['cycleVal'],1)
        self.assertEqual(timing['unit'],'logic_cycles')
        self.assertIsNone(timing['end_to_end_seconds'])
        self.assertIn('freeze',timing['model_mode'])

if __name__=='__main__':unittest.main()
