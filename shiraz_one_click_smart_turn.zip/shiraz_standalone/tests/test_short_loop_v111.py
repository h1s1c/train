import copy
import unittest
from unittest.mock import patch
from simulator import Simulator
from short_loop import clone,prepare,install


class ShortLoopTests(unittest.TestCase):
    def setUp(self):
        self.s=Simulator();self.s.config['turn_s']=240
        self.i=self.s.add_train('T19.1')
        self.s.trains[self.i]['served']=[self.s.trains[self.i]['index']]
        self.req=dict(id=self.i,low=7,high=19)

    def runtime(self):
        return copy.deepcopy((self.s.clock,self.s.trains,self.s.next_id,self.s.points,self.s.reserved,self.s.scheduler,self.s.profile,self.s.events,self.s.config,self.s.running))

    def test_success_preview_readonly(self):
        self.s.running=True;before=self.runtime()
        r=self.s.action(dict(op='short_preview',**self.req))['short_loop']
        self.assertTrue(r['valid'],r['errors']);self.assertEqual(self.runtime(),before)
        self.assertFalse(r['certified']);self.assertGreater(r['horizon_s'],3600)
        self.assertEqual(r['headway_s'],900)

    def test_apply_same_train_same_body_running_and_two_turns(self):
        self.s.running=True;t=self.s.trains[self.i]
        before=(t['head'],t['pos'],list(t['sections']),self.s.next_id,dict(self.s.scheduler),self.s.config['headway_s'])
        r=self.s.action(dict(op='short_apply',**self.req))['short_loop']
        self.assertTrue(r['applied'],r['errors'])
        self.assertEqual(before,(t['head'],t['pos'],t['sections'],self.s.next_id,self.s.scheduler,self.s.config['headway_s']))
        self.assertTrue(self.s.running);self.assertEqual(len(self.s.trains),1)
        self.s.advance(4500)
        self.assertGreaterEqual(t['short_loop']['wraps'],1)
        self.assertFalse(self.s.global_stop);self.assertEqual(set(self.s.owners().values()),{self.i})
        self.assertEqual((t['low'],t['high']),(7,19))

    def test_b_direction_install_preserves_body(self):
        s=Simulator();i=s.add_train('T7.2','B');t=s.trains[i]
        head,pos=t['head'],t['pos'];install(s,prepare(s,dict(id=i,low=7,high=19)))
        self.assertEqual((head,pos),(t['head'],t['pos']));self.assertEqual(t['legs'][0]['line'],'B')
        s.advance(4500);self.assertFalse(s.global_stop);self.assertGreaterEqual(t['short_loop']['wraps'],1)

    def test_conflicting_other_train_rejected_without_mutation(self):
        s=Simulator();s.config['turn_s']=240
        i=s.add_train('T8.1');j=s.add_train('T7.2','B');s.trains[j]['hold']=True
        before=copy.deepcopy((s.trains,s.scheduler,s.profile,s.config,s.next_id,s.clock))
        r=s.action(dict(op='short_apply',id=i,low=7,high=19))['short_loop']
        self.assertFalse(r['valid']);self.assertIn('تداخل',' '.join(r['errors']))
        self.assertEqual(before,(s.trains,s.scheduler,s.profile,s.config,s.next_id,s.clock))

    def test_even_one_sample_of_new_shared_resource_wait_is_rejected(self):
        baseline=dict(error=None,waits={},arrivals={})
        candidate=dict(error=None,waits={(self.i,99,'تراک T7.1'):{42}},arrivals={})
        with patch('short_loop.forecast',side_effect=[baseline,candidate]):
            report=self.s.action(dict(op='short_apply',**self.req))['short_loop']
        self.assertFalse(report['valid'])
        self.assertIn('تداخل',' '.join(report['errors']))
        self.assertNotIn('short_loop',self.s.trains[self.i])

    def test_local_turn_budget_auto_sufficient(self):
        s=Simulator();i=s.add_train('T19.1')
        p=prepare(s,dict(id=i,low=15,high=19));self.assertGreaterEqual(p['turn_s'],211)
        self.assertEqual(s.config['turn_s'],120)

    def test_same_main_dispatch_membership_no_replacement(self):
        self.s.active_route=dict(low=1,high=21)
        self.s.scheduler=dict(enabled=False,managed=True,next=900,limit=6,issued=1)
        self.assertEqual(self.s.dispatch_count(),1)
        install(self.s,prepare(self.s,self.req))
        self.assertEqual(self.s.dispatch_count(),1)
        self.assertEqual(self.s.profile,dict(low=1,high=21))

    def test_return_request_deferred_without_teleport(self):
        install(self.s,prepare(self.s,self.req));t=self.s.trains[self.i]
        before=(t['head'],t['pos'],list(t['sections']))
        self.s.action(dict(op='short_return',id=self.i))
        self.assertEqual(before,(t['head'],t['pos'],t['sections']))
        self.s.advance(3000)
        self.assertFalse(t.get('short_loop'));self.assertEqual((t['low'],t['high']),(1,21))
        self.assertFalse(self.s.global_stop)

    def test_export_import_approach_and_loop_held(self):
        install(self.s,prepare(self.s,self.req))
        for advance in (0,4500):
            if advance:self.s.advance(advance)
            f=Simulator();f.import_scenario(self.s.export());t=f.trains[self.i]
            self.assertEqual(t['head'],self.s.trains[self.i]['head'])
            self.assertTrue(t['hold']);self.assertTrue(t['short_loop']);self.assertFalse(f.scheduler['enabled'])

    def test_tampered_short_budget_import_rejected(self):
        install(self.s,prepare(self.s,self.req));obj=self.s.export();obj['trains'][0]['short_loop']['turn_s']=1
        with self.assertRaises(ValueError):Simulator().import_scenario(obj)

    def test_shadow_runtime_independent(self):
        shadow=clone(self.s);shadow.trains[self.i]['hold']=True;shadow.closed.add('T7.1');shadow.config['headway_s']=60
        self.assertFalse(self.s.trains[self.i]['hold']);self.assertFalse(self.s.closed);self.assertEqual(self.s.config['headway_s'],900)

    def test_reject_invalid_passed_unsafe_and_fault(self):
        for req in [dict(id=self.i,low=18,high=19),dict(id=999,low=7,high=19),dict(id=self.i,low=1,high=21)]:
            self.assertFalse(self.s.action(dict(op='short_preview',**req))['short_loop']['valid'])
        self.s.closed.add('T7.1')
        self.assertFalse(self.s.action(dict(op='short_preview',**self.req))['short_loop']['valid'])
        self.s.closed.clear();t=self.s.trains[self.i];t['speed']=200
        self.assertFalse(self.s.action(dict(op='short_preview',**self.req))['short_loop']['valid'])

    def test_main_headway_is_not_user_override(self):
        self.s.config['headway_s']=30
        r=self.s.action(dict(op='short_preview',headway_s=3600,**self.req))['short_loop']
        self.assertFalse(r['valid']);self.assertEqual(self.s.config['headway_s'],30)


class MapPlacementTests(unittest.TestCase):
    def test_map_infers_b_direction(self):
        s=Simulator();r=s.action(dict(op='map_add',section='T19.2',line='A'))
        self.assertEqual(s.trains[r['id']]['head'],'T19.2');self.assertEqual(s.trains[r['id']]['line'],'B')

    def test_map_reject_occupied_without_mutation(self):
        s=Simulator();s.action(dict(op='map_add',section='T19.1'))
        with self.assertRaises(ValueError):s.action(dict(op='map_add',section='T19.1'))
        self.assertEqual(len(s.trains),1)

    def test_short_track_auto_body_footprint(self):
        s=Simulator();chain=s.legs()[0]['nodes'];n=next(n for n in chain[2:] if s.length(n)<100)
        r=s.action(dict(op='map_add',section=n));t=s.trains[r['id']]
        self.assertEqual(t['head'],n);self.assertGreater(len(t['sections']),1)
        self.assertEqual(set(s.owners().values()),{r['id']})

    def test_map_rejects_unready_point_without_creating_train(self):
        s=Simulator();leg=s.legs()[0]
        found=False
        for n in leg['nodes']:
            req=s.requirements(leg,[n])
            if req and s.length(n)>=100:
                point=next(iter(req));s.points[point]['fault']=True
                with self.assertRaisesRegex(ValueError,'سوزن'):
                    s.action(dict(op='map_add',section=n,line=leg['line']))
                self.assertFalse(s.trains);found=True;break
        self.assertTrue(found)

    def test_planned_clock_does_not_create_occupancy(self):
        from pathlib import Path
        js=(Path(__file__).parents[1]/'static/app.js').read_text();self.assertIn('data-planned-train',js)
        self.assertIn('op:"service_positions",plan,now',js);self.assertIn('map_add',js)

if __name__=='__main__':unittest.main()
