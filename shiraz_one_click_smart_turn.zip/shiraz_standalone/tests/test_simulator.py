import copy
import json
import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from simulator import Simulator, ModelError


class ModelTests(unittest.TestCase):
    def setUp(self):
        self.s = Simulator()

    def test_empty_not_live(self):
        snap = self.s.snapshot()
        self.assertEqual(snap["counts"]["total"], 0)
        self.assertIn("not_live_field", snap["origin"])
        self.assertIsNone(snap["capacity"]["physical_line_capacity"])
        self.assertFalse(snap["capacity"]["certified"])

    def test_unique_train_two_detection_sections(self):
        tid = self.s.add_train("T21.2", "B", sections=["T21.2.1", "T21.2"])
        snap = self.s.snapshot()
        self.assertEqual(snap["counts"]["total"], 1)
        self.assertEqual(snap["counts"]["occupied_sections"], 2)
        self.assertEqual(set(snap["occupied"].values()), {tid})
        with self.assertRaises(ModelError):
            self.s.add_train("T21.2", "B")

    def test_invalid_body_direction(self):
        with self.assertRaises(ModelError):
            self.s.add_train("T21.2.1", "B", sections=["T21.2", "T21.2.1"])

    def test_b_waits_for_l4_without_wrong_reverse(self):
        tid = self.s.add_train("T21.2", "B", sections=["T21.2.1", "T21.2"])
        self.s.closed.add("T22.2.2")
        self.s.advance(500)
        tr = self.s.trains[tid]
        self.assertEqual(tr["head"], "T21.2")
        self.assertEqual(tr["line"], "B")
        self.assertEqual(tr["speed"], 0)
        self.assertFalse(self.s.global_stop)
        self.assertEqual(tr["trips"], 1)

    def test_l4_then_a_waits_for_same_object_on_a(self):
        a = self.s.add_train("T21.1.1", "A", sections=["T21.1", "T21.1.1"])
        self.s.trains[a]["hold"] = True
        b = self.s.add_train("T21.2", "B", sections=["T21.2.1", "T21.2"])
        self.s.advance(2000)
        self.assertEqual(self.s.trains[b]["head"], "T22.2.2")
        self.assertEqual(self.s.trains[b]["speed"], 0)
        self.assertEqual(self.s.snapshot()["counts"]["total"], 2)
        self.assertFalse(self.s.global_stop)
        self.s.trains[a]["hold"] = False
        self.s.advance(2000)
        self.assertNotEqual(self.s.trains[b]["head"], "T22.2.2")
        self.assertEqual(self.s.trains[b]["line"], "A")
        self.assertFalse(self.s.global_stop)

    def test_full_cycle_and_identity(self):
        tid = self.s.add_train()
        visited = set()
        for _ in range(32):
            self.s.advance(500)
            tr = self.s.trains[tid]
            visited.add(tr["leg"])
            self.assertFalse(self.s.global_stop)
            self.assertEqual(self.s.snapshot()["counts"]["total"], 1)
        self.assertEqual(visited, {0, 1, 2, 3, 4})
        self.assertGreaterEqual(tr["trips"], 2)

    def test_short_route(self):
        self.s.action({"op": "plan", "low": 7, "high": 19, "headway_s": 1800})
        tid = self.s.add_train()
        self.s.advance(14000)
        self.assertGreaterEqual(self.s.trains[tid]["trips"], 2)
        self.assertFalse(self.s.global_stop)
        self.assertTrue(all(7 <= self.s.tracks[n]["station"] <= 19
                            for leg in self.s.trains[tid]["legs"] for n in leg["nodes"]))

    def test_esb_and_software_stop(self):
        tid = self.s.add_train("T10.1", "A")
        self.s.advance(25)
        self.s.action({"op": "esb", "station": 10, "value": True})
        old = self.s.trains[tid]["pos"]
        self.s.advance(5)
        self.assertEqual(self.s.trains[tid]["pos"], old)
        self.assertEqual(self.s.trains[tid]["speed"], 0)
        self.s.action({"op": "emergency", "value": True})
        with self.assertRaises(ModelError):
            self.s.action({"op": "run"})

    def test_manual_hold_immediate_when_paused(self):
        tid = self.s.add_train("T10.1", "A")
        self.s.advance(25)
        self.assertGreater(self.s.trains[tid]["speed"], 0)
        self.s.action({"op": "hold", "id": tid, "value": True})
        self.assertEqual(self.s.trains[tid]["speed"], 0)
        self.s.remove_train(tid)
        self.assertEqual(len(self.s.trains), 0)

    def test_point_fault_blocks_shunt_and_no_throw_under_train(self):
        tid = self.s.add_train("T22.2.2", "A")
        self.s.points["P22.3"]["fault"] = True
        self.s.advance(60)
        self.assertEqual(self.s.trains[tid]["head"], "T22.2.2")
        self.assertEqual(self.s.trains[tid]["speed"], 0)
        self.s.points["P22.3"]["fault"] = False
        for _ in range(120):
            self.s.advance(5)
            if "TP22.3" in self.s.owners():
                break
        self.assertIn("TP22.3", self.s.owners())
        with self.assertRaises(ModelError):
            self.s.action({"op": "point", "point": "P22.3", "position": "R"})

    def test_speed_limits_and_tail_clear(self):
        tid = self.s.add_train("T10.1", "A")
        seen = set()
        for _ in range(3000):
            self.s.tick(.1)
            tr = self.s.trains[tid]
            seen.update(tr["sections"])
            limit = self.s.snapshot()["trains"][0]["limit_kmh"]/3.6
            self.assertLessEqual(tr["speed"], limit+0.03)
            self.assertEqual(len(self.s.owners()), len(tr["sections"]))
        self.assertGreater(len(seen), 2)
        self.assertNotIn("T10.1", self.s.owners())

    def test_counts_partition_and_scheduler(self):
        self.s.set_config({"headway_s": 1800})
        self.s.action({"op": "schedule", "value": True, "limit": 6})
        for _ in range(28):
            self.s.advance(500)
            c = self.s.snapshot()["counts"]
            self.assertEqual(c["on_line"] + c["yard_only"], c["total"])
            self.s.owners()
            self.assertFalse(self.s.global_stop)
        self.assertEqual(len(self.s.trains), 6)
        self.assertTrue(all(t["distance_m"] > 1000 for t in self.s.trains.values()))

    def test_planner_independent_arithmetic(self):
        c = self.s.capacity()
        self.assertEqual(c["fleet_requested"], math.ceil(c["cycle_s"]/self.s.config["headway_s"]))
        self.assertEqual(c["fleet_at_effective"], math.ceil(c["cycle_s"]/c["effective_headway_s"]))
        self.assertAlmostEqual(c["departures_per_hour"], 3600/c["effective_headway_s"])
        for line in ("A", "B"):
            self.assertEqual(sum(self.s.length(n) for n in self.s.data["chains"][line]), {"A":22379,"B":22374}[line])

    def test_invalid_config_and_plan_atomic(self):
        for v in (float("nan"), float("inf"), -1, 10):
            with self.assertRaises(ModelError):
                self.s.set_config({"service_brake": v})
        before = copy.deepcopy(self.s.profile), copy.deepcopy(self.s.config)
        with self.assertRaises(ModelError):
            self.s.action({"op": "plan", "low": 5, "high": 19, "headway_s": 2000})
        self.assertEqual(before, (self.s.profile, self.s.config))
        with self.assertRaises(ModelError):
            self.s.edit_track("T21.1", float("nan"), 20)

    def test_export_import_mid_shunt_and_resume(self):
        tid = self.s.add_train("T22.2.2", "A")
        for _ in range(1500):
            self.s.tick(.1)
            if self.s.trains[tid]["head"] == "TP22.3":
                break
        self.assertEqual(self.s.trains[tid]["head"], "TP22.3")
        before = self.s.export()
        self.assertEqual(self.s.trains[tid]["leg"], 4)
        other = Simulator()
        other.import_scenario(json.loads(json.dumps(before)))
        restored = other.trains[tid]
        self.assertEqual(restored["head"], self.s.trains[tid]["head"])
        self.assertEqual(restored["sections"], self.s.trains[tid]["sections"])
        self.assertEqual(restored["leg"], 4)
        self.assertEqual(restored["pos"], self.s.trains[tid]["pos"])
        self.assertEqual(restored["speed"], 0)
        self.assertTrue(restored["hold"])
        self.assertFalse(other.running)
        other.action({"op": "hold", "id": tid, "value": False})
        other.advance(1500)
        self.assertEqual(restored["leg"], 0)
        self.assertFalse(other.global_stop)

    def test_import_invalid_transaction_preserves_scene(self):
        tid = self.s.add_train()
        before = self.s.export()
        obj = copy.deepcopy(before)
        bad = copy.deepcopy(obj["trains"][0])
        bad["id"] = 2
        obj["trains"].append(bad)
        with self.assertRaises(ModelError):
            self.s.import_scenario(obj)
        after = self.s.export()
        # Export timestamps describe each export, not a change to model state.
        before.pop("exported_at", None)
        after.pop("exported_at", None)
        self.assertEqual(before, after)
        self.assertEqual(list(self.s.trains), [tid])

    def test_import_track_edits_visible_to_api(self):
        self.s.edit_track("T10.1", 300, 50)
        other = Simulator()
        other.import_scenario(self.s.export())
        self.assertEqual(other.data["tracks"]["T10.1"]["speed_kmh"], 50)
        self.assertEqual(other.tracks["T10.1"]["length_m"], 300)


if __name__ == "__main__":
    unittest.main()