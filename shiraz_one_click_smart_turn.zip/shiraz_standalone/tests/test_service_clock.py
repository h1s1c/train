import copy
import json
import math
import unittest
from datetime import datetime, timedelta
from simulator import Simulator
from service_clock import ServiceClock, civil


class ServiceClockTests(unittest.TestCase):
    def setUp(self):
        self.s = Simulator()
        self.p = dict(first_a='2026-10-13T05:30:00',last_a='2026-10-13T23:00:00',
                      first_b='2026-10-13T05:30:00',last_b='2026-10-13T23:00:00',
                      headway_min=15,fleet_count=7,run_a_s=2580,run_b_s=2580,
                      turn_a_s=420,turn_b_s=120,dwell_s=20,profile_mode='estimated')

    def calc(self, now='2026-10-13T06:15:00', **changes):
        return ServiceClock(self.s,dict(self.p,**changes)).calculate(now)

    def test_seven_trains_with_persistent_identity(self):
        r=self.calc()
        self.assertTrue(r['valid']);self.assertEqual(r['required_fleet'],7)
        self.assertEqual(len(r['vehicles']),7)
        self.assertEqual(r['cycle_s'],5700)
        trips=[t for t in r['trips'] if t['vehicle']==1]
        self.assertEqual([(t['direction'],t['departure'][11:],t['arrival'][11:]) for t in trips[:3]],
                         [('A','05:30:00','06:13:00'),('B','06:15:00','06:58:00'),('A','07:15:00','07:58:00')])
        self.assertEqual(r['vehicles'][0]['direction'],'B')

    def test_all_trips_nonoverlapping_and_no_teleport(self):
        r=self.calc()
        for vid in range(1,8):
            trips=[t for t in r['trips'] if t['vehicle']==vid]
            for a,b in zip(trips,trips[1:]):
                self.assertLessEqual(a['ready'],b['departure'])
                self.assertEqual(a['destination'],b['origin'])
        self.assertEqual(len({(t['direction'],t['departure']) for t in r['trips']}),len(r['trips']))

    def test_before_first_departure(self):
        r=self.calc('2026-10-13T05:00:00')
        self.assertEqual(r['counts']['not_started'],7)
        self.assertEqual([v['station'] for v in r['vehicles']],[21,1,21,1,21,1,21])
        self.assertTrue(all(v['track'] is None for v in r['vehicles']))

    def test_first_departure_and_arrival_boundaries(self):
        self.assertEqual(self.calc('2026-10-13T05:30:00')['vehicles'][0]['status'],'moving')
        v=self.calc('2026-10-13T06:13:00')['vehicles'][0]
        self.assertEqual((v['status'],v['station']),('turnaround',1))
        v=self.calc('2026-10-13T06:15:00')['vehicles'][0]
        self.assertEqual((v['status'],v['direction']),('moving','B'))

    def test_waiting_when_ready_before_headway(self):
        r=self.calc('2026-10-13T06:14:00',run_a_s=2500)
        self.assertEqual(r['vehicles'][0]['status'],'waiting')
        self.assertEqual(r['vehicles'][0]['next_departure'],'2026-10-13T06:15:00')

    def test_station_dwell_and_after_departure(self):
        c=ServiceClock(self.s,self.p);row=c.profiles['A'][3]
        moment=datetime(2026,10,13,5,30)+timedelta(seconds=math.ceil(row['arrival_s'])+1)
        v=c.calculate(moment.isoformat())['vehicles'][0]
        self.assertEqual((v['status'],v['station']),('station',row['station']))
        moment=datetime(2026,10,13,5,30)+timedelta(seconds=math.ceil(row['departure_s'])+1)
        v=ServiceClock(self.s,self.p).calculate(moment.isoformat())['vehicles'][0]
        self.assertEqual((v['status'],v['from_station']),('moving',row['station']))

    def test_between_station_head_within_track(self):
        for time in ['05:31:00','05:38:45','05:42:31','05:57:55','06:05:00']:
            r=self.calc('2026-10-13T'+time)
            for v in r['vehicles']:
                if v['track']:
                    self.assertGreaterEqual(v['head_m'],0)
                    self.assertLessEqual(v['head_m'],self.s.length(v['track'])+.1)
                    self.assertFalse(v['live'])

    def test_finished_and_reserve_have_no_invented_track(self):
        r=self.calc('2026-10-14T01:00:00',fleet_count=8)
        self.assertEqual((r['counts']['finished'],r['counts']['reserve']),(7,1))
        self.assertIsNone(r['vehicles'][-1]['station'])
        self.assertTrue(all(v['track'] is None for v in r['vehicles']))

    def test_insufficient_fleet_blocks_false_positions(self):
        r=self.calc(fleet_count=6)
        self.assertFalse(r['valid']);self.assertEqual(r['required_fleet'],7)
        self.assertEqual(len(r['vehicles']),6)
        self.assertTrue(all(v['status']=='conflict' and v['track'] is None and v['station'] is None for v in r['vehicles']))

    def test_changed_reference_time_changes_positions(self):
        a=self.calc('2026-10-13T05:37:00')['vehicles'];b=self.calc('2026-10-13T05:52:00')['vehicles']
        self.assertNotEqual([(v['track'],v['status']) for v in a],[(v['track'],v['status']) for v in b])
        self.assertEqual([v['id'] for v in a],[v['id'] for v in b])

    def test_overnight_explicit_dates(self):
        r=self.calc('2026-10-14T00:10:00', first_a='2026-10-13T22:30:00',first_b='2026-10-13T22:30:00',
                    last_a='2026-10-14T02:00:00',last_b='2026-10-14T02:00:00')
        self.assertTrue(r['valid']);self.assertEqual(r['windows']['A']['last_arrival'],'2026-10-14T02:43:00')
        self.assertEqual(r['counts']['moving']+r['counts']['station'],6)

    def test_off_grid_last_departure_not_added(self):
        r=self.calc(last_a='2026-10-13T23:07:00')
        self.assertEqual(r['windows']['A']['last_departure'],'2026-10-13T23:00:00')
        self.assertTrue(any('برای حفظ فاصله اعزام‌ها' in x for x in r['warnings']))

    def test_only_one_departure_at_each_terminal(self):
        r=self.calc(last_a=self.p['first_a'],last_b=self.p['first_b'])
        self.assertEqual(r['required_fleet'],2);self.assertEqual(len(r['trips']),2)
        self.assertEqual(r['counts']['reserve'],5)

    def test_custom_timetable_controls_station_status(self):
        rows=ServiceClock(self.s,self.p).template()['profiles']
        rows['A'][1]['arrival_s']=115;rows['A'][1]['departure_s']=135
        r=self.calc('2026-10-13T05:32:00',profiles=rows,profile_mode='custom')
        self.assertEqual(r['vehicles'][0]['station'],rows['A'][1]['station'])
        self.assertEqual(r['vehicles'][0]['status'],'station')
        self.assertEqual(r['position_basis'],'entered_station_timetable')

    def test_bad_profiles_rejected(self):
        good=ServiceClock(self.s,self.p).template()['profiles']
        for variant in ('missing','order','overlap','last','nan'):
            rows=copy.deepcopy(good)
            if variant=='missing': rows['A'].pop()
            elif variant=='order': rows['B'][1]['station']=999
            elif variant=='overlap': rows['A'][2]['arrival_s']=1
            elif variant=='last': rows['A'][-1]['arrival_s']=2579
            else: rows['A'][1]['arrival_s']=float('nan')
            with self.subTest(variant=variant),self.assertRaises(ValueError):
                self.calc(profiles=rows,profile_mode='custom')

    def test_invalid_inputs(self):
        for changes in [dict(headway_min=0),dict(headway_min=float('nan')),dict(fleet_count=6.1),dict(fleet_count=True),
                        dict(last_a='2026-10-12T23:00:00'),dict(run_a_s=100),dict(turn_a_s=-1),
                        dict(labels=['X']*7),dict(labels=['X']*8),dict(labels=['TR-002']),dict(first_a='05:30')]:
            with self.subTest(changes=changes),self.assertRaises(ValueError): self.calc(**changes)
        for now in [None,'06:15','2026-10-13T06:15:00Z','2101-01-01T06:15:00']:
            with self.subTest(now=now),self.assertRaises(ValueError): self.calc(now)

    def test_custom_labels(self):
        labels=['قطار '+str(i) for i in range(7)]
        self.assertEqual([v['label'] for v in self.calc(labels=labels)['vehicles']],labels)

    def test_optional_labels_keep_slot_identity(self):
        vehicles=self.calc(labels=['احسان', '', '۱۰۳'])['vehicles']
        self.assertEqual([v['label'] for v in vehicles[:4]],['احسان','TR-002','۱۰۳','TR-004'])
        self.assertEqual([v['id'] for v in vehicles],list(range(1,8)))

    def test_no_mutation_of_movement_model_or_config(self):
        before=copy.deepcopy(self.s.export())
        self.s.action(dict(op='service_positions',plan=self.p,now='2026-10-13T06:15:00'))
        after=self.s.export()
        before.pop('exported_at');after.pop('exported_at')
        self.assertEqual(after,before)
        self.assertEqual(len(self.s.tracks),240)
        self.assertEqual(self.s.length('T22.2.2'),115)

    def test_asymmetric_windows_are_allocated_not_cycle_only(self):
        r=self.calc(first_b='2026-10-13T06:15:00',last_b='2026-10-13T23:00:00')
        self.assertTrue(r['valid']);self.assertEqual(r['required_fleet'],7)
        initial=self.calc('2026-10-13T05:00:00',first_b='2026-10-13T06:15:00',last_b='2026-10-13T23:00:00')
        self.assertTrue(all(v['station']==21 for v in initial['vehicles']))
        for vid in {t['vehicle'] for t in r['trips']}:
            ts=[t for t in r['trips'] if t['vehicle']==vid]
            for a,b in zip(ts,ts[1:]): self.assertLessEqual(a['ready'],b['departure'])

    def test_serializable_finite_json(self):
        json.dumps(self.calc(),ensure_ascii=False,allow_nan=False)


if __name__=='__main__':unittest.main()
