import unittest
from simulator import Simulator

class StationList(unittest.TestCase):
    def test_from_ehsan_to_mirza_stations_follow_run(self):
        s=Simulator(); tid=s.add_train('T22.2.2','A'); s.action(dict(op='short_clock_set',datetime='2026-11-08T10:00:00'))
        result=s.action(dict(op='timed_short_preview',id=tid,low=19,high=21,origin=21,departure='2026-11-08T10:15:00'))['short_loop']
        self.assertTrue(result['valid'],result['errors'])
        self.assertEqual([(x['id'],x['name']) for x in result['stations']],[(21,'احسان'),(20,'دکتر شریعتی'),(19,'میرزای شیرازی')])
        self.assertNotIn('short_loop',s.trains[tid])
    def test_from_mirza_to_ovini_stations_follow_run(self):
        s=Simulator(); tid=s.add_train('T18.2','B'); s.trains[tid]['served']=[s.trains[tid]['index']]
        s.action(dict(op='short_clock_set',datetime='2026-11-07T10:00:00'))
        result=s.action(dict(op='timed_short_apply',id=tid,low=15,high=19,origin=19,departure='2026-11-07T10:20:00'))['short_loop']
        self.assertTrue(result['valid'],result['errors'])
        self.assertEqual([x['id'] for x in result['stations']],[19,18,17,16,15])
        self.assertTrue(result['applied'])
        s.advance(3600)
        station_events=[e['message'] for e in s.events if e['kind']=='SHORT_STATION']
        for name in ('شاهد','قصر دشت','مطهری','اوینی'):
            self.assertTrue(any(name in e for e in station_events),name)
        self.assertEqual(len(station_events),8)

if __name__=='__main__':unittest.main()
