import copy
import unittest
from simulator import Simulator

class SmartReadyTests(unittest.TestCase):
    def base(self,section='T21.1',direction='A'):
        s=Simulator();i=s.add_train(section,direction,label='قطار ۱۰۱')
        s.action(dict(op='short_clock_set',datetime='2026-11-08T10:00:00'))
        return s,i,dict(op='smart_short_predicted_ready',id=i,low=19,high=21,origin=21,model_only_confirmed=True)
    def test_prediction_is_read_only_and_uses_actual_position(self):
        s,i,q=self.base('T22.2.2','A');before=copy.deepcopy(s.export());r=s.action(q)['ready'];after=s.export();before.pop('exported_at');after.pop('exported_at')
        self.assertEqual(before,after);self.assertTrue(r['valid']);self.assertGreaterEqual(r['seconds_from_now'],420);self.assertEqual(s.trains[i]['head'],'T22.2.2')
        self.assertEqual(r['datetime'],'2026-11-08T10:07:00')
    def test_ready_alone_does_not_claim_route_is_valid(self):
        s,i,q=self.base();r=s.action(q)['ready'];self.assertTrue(r['valid']);self.assertFalse(r['certified'])
        j=s.add_train('T20.2','B');s.action(dict(op='hold',id=j,value=True))
        check=s.action(dict(op='timed_short_preview',id=i,low=19,high=21,origin=21,departure='2026-11-08T10:01:00'))['short_loop']
        self.assertFalse(check['valid']);self.assertNotIn('short_loop',s.trains[i])
    def test_held_train_and_invalid_station_rejected(self):
        s,i,q=self.base();s.trains[i]['hold']=True;self.assertFalse(s.action(q)['ready']['valid']);self.assertEqual(s.trains[i]['head'],'T21.1')
        s.trains[i]['hold']=False;q['origin']=20;self.assertFalse(s.action(q)['ready']['valid'])
    def test_unmapped_fleet_requires_confirmation(self):
        s,i,q=self.base();q['model_only_confirmed']=False
        with self.assertRaisesRegex(ValueError,'همه قطارهای'):s.action(q)
        self.assertNotIn('short_loop',s.trains[i])

if __name__=='__main__':unittest.main()
