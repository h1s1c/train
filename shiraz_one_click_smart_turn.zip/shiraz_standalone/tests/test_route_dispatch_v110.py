import copy
import unittest
from simulator import Simulator


class RouteDispatchTests(unittest.TestCase):
    def setUp(self):
        self.s = Simulator()
        self.s.config['turn_s'] = 240
        self.request = dict(op='route_start', low=1, high=7, headway_s=900, limit=4)

    def preview(self, **changes):
        return self.s.action(dict(self.request, op='route_preview', **changes))['route']

    def start(self, **changes):
        return self.s.action(dict(self.request, **changes))['route']

    def test_preview_readonly_selected_length(self):
        before = copy.deepcopy(self.s.export())
        r = self.preview()
        self.assertTrue(r['valid'], r['errors'])
        self.assertEqual(before, self.s.export())
        self.assertEqual(r['route_length_m']['A'], sum(self.s.length(n) for n in self.s.legs(1,7)[0]['nodes']))
        self.assertLess(r['route_length_m']['A'], self.s.capacity(1,21)['route_length_m']['A'])

    def test_immediate_spawn_running_and_motion(self):
        r = self.start()
        self.assertTrue(r['started'], r['errors'])
        self.assertTrue(self.s.running)
        t = self.s.trains[r['train_id']]
        self.assertEqual((t['low'],t['high']), (1,7))
        before = (t['head'],t['pos'])
        self.s.advance(15)
        self.assertNotEqual(before, (t['head'],t['pos']))
        self.assertEqual(self.s.snapshot()['active_route']['high'],7)

    def test_live_disjoint_service_keeps_train(self):
        old = self.s.add_train(low=15,high=19)
        self.s.running = True
        before = copy.deepcopy(self.s.trains[old])
        r = self.start()
        self.assertTrue(r['started'],r['errors'])
        self.assertEqual(before,self.s.trains[old])
        self.assertEqual(self.s.dispatch_count(),1)
        self.s.advance(901)
        self.assertEqual(self.s.dispatch_count(),2)
        self.assertEqual(len(self.s.trains),3)
        self.assertEqual(self.s.scheduler["limit"],2)
        self.assertEqual(self.s.scheduler["available_limit"],4)
        self.assertFalse(self.s.global_stop)

    def test_foreign_future_overlap_no_mutation(self):
        old = self.s.add_train(low=1,high=21)
        self.s.running=True
        before=(copy.deepcopy(self.s.trains),dict(self.s.config),dict(self.s.scheduler),dict(self.s.profile),self.s.next_id)
        r=self.start()
        self.assertFalse(r['valid'])
        self.assertIn(self.s.trains[old]['label'],' '.join(r['errors']))
        self.assertEqual(before,(self.s.trains,self.s.config,self.s.scheduler,self.s.profile,self.s.next_id))
        self.assertTrue(self.s.running)
        self.assertIsNone(self.s.active_route)

    def test_same_service_keeps_identity_position(self):
        tid=self.s.add_train(low=1,high=7)
        self.s.advance(15)
        before=copy.deepcopy(self.s.trains[tid])
        r=self.start()
        self.assertTrue(r['started'],r['errors'])
        self.assertFalse(r['created'])
        self.assertEqual(r['train_id'],tid)
        self.assertEqual(before,self.s.trains[tid])

    def test_held_not_silently_released(self):
        tid=self.s.add_train(low=1,high=7)
        self.s.trains[tid]['hold']=True
        self.assertFalse(self.start()['valid'])
        self.assertTrue(self.s.trains[tid]['hold'])

    def test_recheck_after_preview(self):
        self.assertTrue(self.preview()['valid'])
        n=self.s.legs(1,7)[0]['nodes'][3]
        self.s.closed.add(n)
        r=self.start()
        self.assertFalse(r['valid'])
        self.assertIn(n,' '.join(r['errors']))
        self.assertFalse(self.s.trains)

    def test_emergency_esb_points_release(self):
        self.s.global_stop=True
        self.assertFalse(self.preview()['valid'])
        self.s.global_stop=False
        self.s.esb.add(7)
        self.assertFalse(self.preview()['valid'])
        self.s.esb.clear()
        from route_dispatch import resources
        _,points=resources(self.s,self.s.legs(1,7))
        p=next(iter(points));self.s.points[p]['fault']=True
        self.assertFalse(self.preview()['valid'])
        self.s.points[p]['fault']=False
        self.s.release_until['T7.1']=10
        self.assertFalse(self.preview()['valid'])

    def test_headway_fleet_and_turn_budget(self):
        self.assertFalse(self.preview(headway_s=30)['valid'])
        self.assertFalse(self.preview(limit=1)['valid'])
        self.s.config['turn_s']=30
        self.assertFalse(self.preview()['valid'])

    def test_invalid_inputs(self):
        for changes in [dict(low=21,high=1),dict(low=18),dict(headway_s=float('nan')),dict(limit=2.5)]:
            self.assertFalse(self.preview(**changes)['valid'])

    def test_stop_reset_import_clear_metadata(self):
        self.assertTrue(self.start()['started'])
        self.s.action(dict(op='schedule',value=False))
        self.assertFalse(self.s.scheduler['enabled'])
        self.assertTrue(self.s.running)
        exported=self.s.export()
        self.s.running=False
        self.s.import_scenario(exported)
        self.assertIsNone(self.s.active_route)
        self.assertFalse(self.s.scheduler['enabled'])
        self.s.reset_line()
        self.assertIsNone(self.s.active_route)

    def test_yellow_underlay_and_explicit_start_wiring(self):
        from pathlib import Path
        js=(Path(__file__).parents[1]/'static/app.js').read_text()
        self.assertIn('data-route-track',js)
        self.assertIn('pointer-events":"none"',js)
        self.assertIn('routeCheck(true)',js)
        self.assertIn('focusRoute(r.train_id)',js)
        self.assertIn('routeInput(start?"route_start":"route_preview")',js)

if __name__=='__main__':unittest.main()
