"""One offline policy shared by movement, timetable and dispatcher.
420 s is the user's B-platform -> A-platform Ehsan cycle, NOT an
independently certified field value. No timer can override physical occupancy.
"""
import math

EHSAN_MIN_S = 420.0
POLICY = 'ehsan-exclusive-shunt-v1'


def ehsan_time(value):
    try:
        value = float(value)
    except (ValueError, TypeError):
        raise ValueError('زمان گردش احسان را به‌صورت عدد، بر حسب ثانیه وارد کنید.') from None
    if not math.isfinite(value) or not EHSAN_MIN_S <= value <= 3600:
        raise ValueError('زمان گردش احسان، از سکوی B تا بازگشت به سکوی A، باید بین ۴۲۰ ثانیه (۷ دقیقه) و ۳۶۰۰ ثانیه (۶۰ دقیقه) باشد.')
    return value


def minimum_shunts(model, low=None, high=None):
    legs = model.legs(low,high)
    ehsan = [l for l in legs if l['kind'] in ('receive','dispatch')]
    # Free-run lower estimate plus stops and point-setting allowances.
    # Actual blockage, body speed restrictions and route occupancy can take longer.
    e = sum(model.leg_seconds(l)+model.config['dwell_s']+model.config['point_throw_s'] for l in ehsan)
    others = [model.leg_seconds(l)+model.config['dwell_s']+model.config['point_throw_s']
              for l in legs if l['kind']=='turn']
    return dict(ehsan_s=e, other_s=max(others,default=0))


def platform_exit_s(model, track, direction):
    nodes = model.data['chains'][direction]
    i = nodes.index(track)
    next_node = nodes[i+1] if i+1 < len(nodes) else None
    cap = model.speed(track,'run',next_node)/3.6
    if next_node:
        cap = min(cap,model.speed(next_node,'run',nodes[i+2] if i+2<len(nodes) else None)/3.6)
    start = min(model.length(track)-1,model.config['train_length_m']+20)
    distance = model.length(track)-start+model.config['train_length_m']+model.config['margin_m']
    a = model.config['acceleration']
    ramp = cap*cap/(2*a)
    moving = math.sqrt(2*distance/a) if distance<=ramp else cap/a+(distance-ramp)/cap
    return moving+model.config['release_s']
