"""Placement by selected track; never overrides occupancy or invents a turnout route."""
def add_at(model,obj):
    section=obj['section']
    if section not in model.tracks:raise ValueError('تراک انتخاب‌شده شناخته‌شده نیست.')
    low,high=int(obj.get('low',model.profile['low'])),int(obj.get('high',model.profile['high']))
    legs=model.legs(low,high)
    if section=='T22.2.2' and high==21:
        # The verified model route starts on this yard track; never relocate it.
        return model.add_train(section,'A',low,high,label=obj.get('label'))
    if model.tracks[section].get('yard') and not model.data['graph'].get(section):
        raise ValueError('برای '+section+' اتصال خروج و سرعت معتبر در داده موجود نیست؛ قطار به سکوی احسان منتقل نشد. اطلاعات مسیر و سرعت این تراک لازم است.')
    options=[l for l in legs if l['kind']=='run' and section in l['nodes']]
    if not options:raise ValueError('این قطعه روی مسیر مستقیم سرویس انتخاب‌شده نیست؛ برای قطعه مانور باید سناریوی بدنه و جهت جداگانه تعریف شود.')
    preferred=obj.get('line')
    leg=next((l for l in options if l['line']==preferred),options[0])
    footprint=[section]
    if model.length(section)<model.config['train_length_m']:
        i=leg['nodes'].index(section);coverage=1.0
        while coverage<model.config['train_length_m'] and i>0:
            i-=1;n=leg['nodes'][i];footprint.insert(0,n);coverage+=model.length(n)
        if coverage<model.config['train_length_m']:raise ValueError('پشت این تراک فضای متصل کافی برای بدنه قطار وجود ندارد.')
    for point,desired in model.requirements(leg,footprint).items():
        state=model.points[point]
        if (state['fault'] or state['position']!=desired or state['target']!=desired
                or state['ready_at']>model.clock or state['owner'] is not None):
            raise ValueError(f'سوزن {point} برای قرارگیری قطار آماده نیست؛ ابتدا وضعیت و آزادبودن سوزن را بررسی کنید. قطار اضافه نشد.')
    return model.add_train(section,leg['line'],low,high,label=obj.get('label'),sections=footprint)
