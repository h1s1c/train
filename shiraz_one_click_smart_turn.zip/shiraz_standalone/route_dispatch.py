"""Conservative admission of ONE selected cyclic service; not field interlocking.

Read-only preview; action handler holds the model lock during recheck and commit.
Foreign cyclic services sharing any track/point are deliberately rejected, even
when currently distant. No mid-trip rerouting, teleportation or automatic hold release.
"""
import copy
import math


def resources(model, legs):
    nodes = {n for leg in legs for n in leg["nodes"]}
    points = {p for leg in legs for p in model.requirements(leg, leg["nodes"])}
    return nodes, points


def evaluate(model, obj):
    # Import only here to avoid a module import cycle.
    from simulator import ModelError, BOUNDS
    try:
        low, high = float(obj["low"]), float(obj["high"])
        limit = float(obj["limit"])
        h = float(obj["headway_s"])
        if not all(math.isfinite(x) for x in (low, high, limit, h)) or not all(x.is_integer() for x in (low, high, limit)):
            raise ModelError("ایستگاه‌ها و تعداد قطارها باید عدد صحیح باشند.")
        low, high, limit = int(low), int(high), int(limit)
        if not 1 <= limit <= 150 or not BOUNDS["headway_s"][0] <= h <= BOUNDS["headway_s"][1]:
            raise ModelError("تعداد قطار باید بین ۱ تا ۱۵۰ و هدوی بین نیم تا ۶۰ دقیقه باشد.")
        legs = model.legs(low, high)
        probe = copy.copy(model)
        probe.config = dict(model.config, headway_s=h)
        cap = probe.capacity(low, high)
        nodes, points = resources(model, legs)
        errors = []
        if model.global_stop:
            errors.append("توقف فوری مدل فعال است؛ ابتدا علت توقف را بررسی و آن را رفع کنید.")
        if h < cap["planning_bound_s"]:
            errors.append(f"هدوی کوتاه است؛ حداقل برآورد این مدل برای مسیر انتخاب‌شده {cap['planning_bound_s']/60:.2f} دقیقه است.")
        if limit < cap["fleet_requested"]:
            errors.append(f"قطار کافی نیست؛ برای زمان حرکت محاسبه‌شده و این هدوی حداقل {cap['fleet_requested']} قطار در سرویس لازم است.")
        if any(model.length(l["nodes"][-1]) <= model.config["train_length_m"] for l in legs):
            errors.append("قطعه انتهای حرکت یا گردش برای جاگیری کامل قطار کوتاه است.")
        mins = cap["shunt_minimums"]
        if model.config["turn_s"] + .001 < mins["other_s"]:
            errors.append(f"زمان گردش پایانه دیگر کم است؛ در تنظیمات دست‌کم {math.ceil(mins['other_s'])} ثانیه اختصاص دهید.")
        if high == 21 and model.config["ehsan_turn_s"] + .001 < mins["ehsan_s"]:
            errors.append(f"زمان گردش احسان کم است؛ دست‌کم {math.ceil(mins['ehsan_s'])} ثانیه لازم است.")
        for n in sorted(nodes):
            if n in model.closed:
                errors.append(f"تراک {n} در مسیر انتخاب‌شده مسدود است.")
            if model.tracks[n]["station"] in model.esb:
                errors.append(f"توقف اضطراری ایستگاه در مسیر تراک {n} فعال است.")
        matching = []
        for t in model.trains.values():
            if (t["low"], t["high"]) == (low, high):
                matching.append(t["id"])
                if t["hold"]:
                    errors.append(f"قطار {t['label']} در همین سرویس توقف دستی دارد؛ ابتدا وضعیت آن را تعیین کنید.")
                continue
            foreign, foreign_points = resources(model, t["legs"])
            shared = nodes & (foreign | set(t["sections"]))
            shared_points = points & foreign_points
            if shared or shared_points:
                resource = "تراک " + sorted(shared)[0] if shared else "سوزن " + sorted(shared_points)[0]
                errors.append(f"تداخل با قطار {t['label']} (شناسه {t['id']}) در {resource}؛ مسیر فعلی یا ادامه رفت‌وبرگشت آن با سرویس جدید مشترک است. قطار در حال حرکت به مسیر دیگری منتقل نمی‌شود.")
        for p in sorted(points):
            state = model.points[p]
            if state["fault"]:
                errors.append(f"سوزن {p} در مسیر خراب است.")
            if state["owner"] and state["owner"] not in matching:
                errors.append(f"سوزن {p} در اختیار قطار {state['owner']} است.")
        for n, owner in model.reserved.items():
            if n in nodes and owner not in matching:
                errors.append(f"تراک {n} برای قطار {owner} رزرو شده است.")
        if len(model.trains) - len(matching) + cap["fleet_requested"] > 150:
            errors.append("با قطارهای سرویس‌های دیگر، تعداد کل موردنیاز از حد ۱۵۰ قطار مدل بیشتر می‌شود.")
        if len(matching) > limit:
            errors.append("تعداد قطارهای موجود این سرویس از سقف واردشده بیشتر است؛ سقف را اصلاح کنید.")
        if not matching:
            origin = legs[0]["nodes"][0]
            if not model.check_clear(origin, 0):
                errors.append(f"مبدأ اعزام {origin} آزاد نیست یا زمان آزادسازی آن کامل نشده است؛ شروع حرکت اکنون ممکن نیست.")
            if len(model.trains) >= 150:
                errors.append("حداکثر تعداد کل قطارهای مدل پر شده است.")
        return dict(valid=not errors, errors=list(dict.fromkeys(errors)), low=low, high=high,
                    headway_s=h, limit=limit, tracks=sorted(nodes), matching=matching,
                    route_length_m=cap["route_length_m"], cycle_s=cap["cycle_s"],
                    run_a_s=model.leg_seconds(legs[0]), run_b_s=model.leg_seconds(legs[2]),
                    minimum_headway_s=cap["planning_bound_s"], required_fleet=cap["fleet_requested"],
                    certified=False, started=False)
    except (ModelError, ValueError, TypeError, KeyError) as exc:
        return dict(valid=False, errors=[str(exc)], started=False, certified=False)


def start(model, report):
    # Evaluate already checked the immediate origin; add_train still validates it.
    # Existing compatible trains retain identity, route, position and hold state.
    tid = report["matching"][0] if report["matching"] else model.add_train(low=report["low"], high=report["high"])
    created = not report["matching"]
    if created:
        model.trains[tid]["served"] = [0]
    model.profile = dict(low=report["low"], high=report["high"])
    model.config["headway_s"] = report["headway_s"]
    model.active_route = {k: copy.deepcopy(report[k]) for k in ("low", "high", "tracks", "headway_s", "cycle_s", "route_length_m")}
    model.active_route["started_at"] = model.clock
    model.scheduler = dict(enabled=True, managed=True, next=model.clock + report["headway_s"],
                           limit=max(report["required_fleet"], len(report["matching"])), available_limit=report["limit"], issued=int(created), blocked_reason=None)
    model.running = True
    report.update(started=True, train_id=tid, created=created)
    model.log("SCHEDULE", f"سرویس ST{report['high']} تا ST{report['low']} شروع شد؛ قطار {tid} روی نقشه نمایش داده می‌شود. مسیر زرد، سرویس انتخاب‌شده مدل است.")
