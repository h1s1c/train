#!/usr/bin/env python3
"""Shiraz standalone operations sandbox. No MainIO/ELLSI/UDP dependency."""
from __future__ import annotations
import argparse
import copy
import csv
import io
import json
import math
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from service_clock import ServiceClock
from terminal_rules import EHSAN_MIN_S, POLICY, ehsan_time, minimum_shunts

ROOT = Path(__file__).resolve().parent
VERSION = "1.0.12"
DEFAULTS = dict(train_length_m=100.0, acceleration=0.8, service_brake=0.8,
                emergency_brake=1.2, reaction_s=1.0, margin_m=20.0,
                dwell_s=20.0, turn_s=120.0, ehsan_turn_s=420.0, point_throw_s=4.0,
                headway_s=900.0, release_s=2.0, shunt_kmh=15.0)
BOUNDS = dict(train_length_m=(20, 200), acceleration=(.1, 1.5),
              service_brake=(.1, 1.5), emergency_brake=(.2, 2),
              reaction_s=(0, 10), margin_m=(5, 100), dwell_s=(5, 180),
              turn_s=(30, 3600), ehsan_turn_s=(420, 3600), point_throw_s=(1, 15), headway_s=(30, 3600),
              release_s=(1, 30), shunt_kmh=(3, 25))


class ModelError(ValueError):
    pass


class Simulator:
    def __init__(self, line=None):
        # The bundled JSON is UTF-8, regardless of the Windows ANSI locale.
        # utf-8-sig also accepts a BOM added by Windows text editors.
        self.data = copy.deepcopy(line or json.loads(
            (ROOT / "data/line.json").read_text(encoding="utf-8-sig")))
        self.tracks = self.data["tracks"]
        self.config = dict(DEFAULTS)
        self.lock = threading.RLock()
        self.running = False
        self.scale = 1
        self.clock = 0.0
        self.clock_reference = None  # Explicit civil-time anchor; not a live clock.
        self.next_id = 1
        self.trains = {}
        self.reserved = {}
        self.release_until = {}
        self.closed = set()
        self.esb = set()
        self.global_stop = False
        self.events = deque(maxlen=500)
        self.points = {n: dict(position="N", target="N", ready_at=0, fault=False, owner=None)
                       for n in self.data["points"]}
        self.profile = {"low": 1, "high": 21}
        # A timetable fleet estimate is separate from uncalibrated track physics.
        ref = self.data["reference_timetable"]
        self.timetable = dict(run_a_s=ref["one_way_min"]*60.0,
                              run_b_s=ref["one_way_min"]*60.0, reserve=1,
                              low=1, high=21, source="legacy_reference_unverified")
        self.active_route = None
        self.scheduler = {"enabled": False, "next": 0.0, "limit": 0, "issued": 0}
        self.terminal = dict(policy=POLICY, owner=None, started_at=None, ready_at=None, clear_after=0.0, returned=False, overrun=False)
        self.origin = "new_empty_model_not_live_field"
        self.imported_at = None
        self.log("START", "مدل مستقل خالی؛ هیچ قطار واقعی از میدان دریافت نشده است")

    def log(self, kind, message, train=None):
        self.events.append({"time": round(self.clock, 1), "kind": kind,
                            "message": message, "train": train})

    def length(self, n):
        return float(self.tracks[n]["length_m"])

    def speed(self, n, kind="run", next_node=None):
        track = self.tracks[n]
        if track.get("speed_mode") == "atp_positive_route_envelope":
            modes = track.get("atp_route_caps", [])
            if next_node is not None:
                modes = [r for r in modes if r["next"] == next_node]
            candidates = [r["ceiling_kmh"] for r in modes if r["ceiling_kmh"] > 0]
            if not candidates:
                raise ModelError(f"برای {n} به {next_node or 'پایان مسیر'} برای این بخش از مسیر، محدودیت سرعت مثبت در داده‌های منبع ثبت نشده است.")
            # Offline envelope, not a full live ATP calculation. Only used after
            # independent model occupancy/route/closure/ESB checks. Never replace
            # dynamic stop states with a globally permitted maximum speed.
            v = float(min(candidates))
        else:
            v = float(track["speed_kmh"])
        if not math.isfinite(v) or v <= 0:
            raise ModelError(f"سرعت معتبر برای بخش {n} در داده‌های منبع پیدا نشد.")
        return min(v, self.config["shunt_kmh"]) if kind != "run" else v

    def route_speed(self, leg, index):
        nodes = leg["nodes"]
        return self.speed(nodes[index], leg["kind"],
                          nodes[index+1] if index+1 < len(nodes) else None)

    def turn(self, station, reverse=False):
        record = next((x for x in self.data["turnbacks"] if x["station"] == station), None)
        if not record:
            raise ModelError("برای این ایستگاه، مسیر تغییر خط در داده‌های استخراج‌شده تعریف نشده است.")
        return record["path_b_to_a" if reverse else "path_a_to_b"]

    def chain_slice(self, line, origin, destination):
        chain = self.data["chains"][line]
        a, b = chain.index(origin), chain.index(destination)
        if a > b:
            raise ModelError("حرکت در جهت مخالف بدون انجام مانور شانت امکان‌پذیر نیست.")
        return chain[a:b + 1]

    def legs(self, low=None, high=None):
        low = int(low if low is not None else self.profile["low"])
        high = int(high if high is not None else self.profile["high"])
        candidates = {x["station"] for x in self.data["turnbacks"]}
        if low >= high or low not in candidates or high not in candidates:
            raise ModelError("برای انتخاب دو پایانه، ایستگاه‌هایی را انتخاب کنید که مسیر تغییر خط آن‌ها در مدل تعریف شده باشد.")
        a = self.chain_slice("A", f"T{high}.1", f"T{low}.1")
        b = self.chain_slice("B", f"T{low}.2", f"T{high}.2")
        legs = [dict(kind="run", line="A", nodes=a), dict(kind="turn", line="B", nodes=self.turn(low)),
                dict(kind="run", line="B", nodes=b)]
        if high == 21:
            legs += [dict(kind="receive", line="B", nodes=self.data["yard_inbound"]),
                     dict(kind="dispatch", line="A", nodes=self.data["yard_outbound"])]
        else:
            legs += [dict(kind="turn", line="A", nodes=self.turn(high, True))]
        for leg in legs:
            if not leg["nodes"] or any(n not in self.tracks for n in leg["nodes"]):
                raise ModelError("مسیر انتخاب‌شده شامل بخش ناشناخته‌ای است. مسیر و داده‌های آن را بررسی کنید.")
            if any(b not in self.data["graph"].get(a, []) for a, b in zip(leg["nodes"], leg["nodes"][1:])):
                raise ModelError("اتصال فیزیکی بخش‌های مسیر در مدل کامل نیست. داده‌های مسیر را بررسی کنید.")
        return legs

    def owners(self):
        result = {}
        for tr in self.trains.values():
            for n in tr["sections"]:
                if n in result and result[n] != tr["id"]:
                    raise ModelError("در مدل، دو قطار به یک مدار تشخیص اختصاص یافته‌اند. وضعیت قطارها را بررسی کنید.")
                result[n] = tr["id"]
        return result

    def terminal_sections(self):
        return (set(self.data['yard_inbound']) | set(self.data['yard_outbound'])) - {'T21.1'}

    def terminal_available(self, tid):
        t = self.terminal
        return t['owner'] in (None,tid) and (t['owner']==tid or t['clear_after']<=self.clock)

    def claim_terminal(self, tr):
        if self.terminal['owner']==tr['id']:
            return True
        if not self.terminal_available(tr['id']):
            tr['reason']='قطار دیگری از مسیر پایانه احسان استفاده می‌کند یا زمان آزادسازی مسیر هنوز تمام نشده است'
            return False
        sections=self.terminal_sections()-{'T21.2'}
        occupied=self.owners()
        if any(occupied.get(n,tr['id'])!=tr['id'] or self.reserved.get(n,tr['id'])!=tr['id']
               or self.release_until.get(n,0)>self.clock for n in sections):
            tr['reason']='مسیر مشترک شانت احسان هنوز آزاد نشده است'
            return False
        self.terminal.update(owner=tr['id'],started_at=self.clock,
                             ready_at=self.clock+self.config['ehsan_turn_s'],returned=False,overrun=False)
        tr['turn_started_at']=self.clock
        tr['turn_ready_at']=self.terminal['ready_at']
        tr['turn_station']=21
        self.log('TERMINAL_LOCK',f"چرخه انحصاری احسان برای {tr['label']}؛ حداقل {self.config['ehsan_turn_s']} ثانیه",tr['id'])
        return True

    def update_terminal(self):
        t=self.terminal
        if t['owner'] is None:
            return
        tr=self.trains.get(t['owner'])
        if tr is None:
            t.update(owner=None,started_at=None,ready_at=None,clear_after=self.clock+self.config['release_s'],returned=False,overrun=False)
            return
        if t['returned'] and self.clock+1e-7>=t['ready_at']:
            shared=self.terminal_sections()-{'T21.2'}
            if not (set(tr['sections']) & shared) and all(self.release_until.get(n,0)<=self.clock for n in shared):
                self.log('TERMINAL_RELEASE',f"آزادسازی چرخه احسان برای {tr['label']}",tr['id'])
                t.update(owner=None,started_at=None,ready_at=None,clear_after=self.clock+self.config['release_s'],returned=False,overrun=False)
                return
        if not t['returned'] and self.clock > t['ready_at']+.5 and not t['overrun']:
            t['overrun']=True
            self.log('TERMINAL_OVERRUN','چرخه احسان در زمان مقرر کامل نشد؛ تمدید زمان هرگز مجوز اشغال مسیر نیست',tr['id'])
            if self.scheduler['enabled']:
                self.scheduler.update(enabled=False,blocked_reason='گردش احسان از برنامه عقب افتاد؛ اعزام خودکار متوقف شد')
                self.running=False
                for vehicle in self.trains.values():vehicle['speed']=0.0

    def check_clear(self, n, tid):
        return ((n not in self.terminal_sections() or self.terminal_available(tid)) and n not in self.closed and self.tracks[n]["station"] not in self.esb
                and self.owners().get(n, tid) == tid and self.reserved.get(n, tid) == tid
                and self.release_until.get(n, 0) <= self.clock)

    def requirements(self, leg, nodes):
        req = {}
        route = leg["nodes"]
        links = self.data.get("configured_links", [])
        for n in nodes:
            if n not in route:
                continue
            i = route.index(n)
            prev = route[i-1] if i else None
            nxt = route[i+1] if i+1 < len(route) else None
            for name in self.tracks[n].get("point_names", [self.tracks[n].get("point")]):
                if not name:
                    continue
                pid = self.data["points"][name].get("logic_id")
                sets = []
                for a,b in ((n,nxt),):
                    values = {r["point_pos"] for r in links
                              if r["track"] == a and r["next"] == b and r["point_id"] == pid}
                    if values:
                        sets.append(values)
                allowed = set.intersection(*sets) if sets else {0,1}
                if not allowed:
                    raise ModelError(f"وضعیت سوزن {name} با مسیر انتخاب‌شده سازگار نیست.")
                preferred = 0 if leg["kind"] == "run" else 1
                value = preferred if preferred in allowed else min(allowed)
                req[name] = "N" if value == 0 else "R"
        return req

    def set_config(self, values):
        if self.running or self.trains:
            raise ModelError("برای تغییر پارامترهای فیزیکی، ابتدا مدل را متوقف و همهٔ قطارها را حذف کنید.")
        if not isinstance(values, dict):
            raise ModelError("ساختار پارامترها معتبر نیست. لطفاً فایل یا دادهٔ ورودی را بررسی کنید.")
        if set(values) - set(BOUNDS):
            raise ModelError("یکی از پارامترهای ارسالی شناخته‌شده نیست. تنظیمات را بررسی کنید.")
        candidate = dict(self.config)
        for key, val in values.items():
            labels = dict(train_length_m="طول قطار (متر)", acceleration="شتاب (متر بر مجذور ثانیه)",
                          service_brake="ترمز سرویس", emergency_brake="ترمز اضطراری",
                          reaction_s="زمان واکنش (ثانیه)", margin_m="حاشیه توقف (متر)",
                          dwell_s="توقف ایستگاه میانی (ثانیه)", turn_s="گردش پایانه دیگر (ثانیه)",
                          ehsan_turn_s="گردش احسان (ثانیه)", point_throw_s="تغییر وضعیت سوزن (ثانیه)",
                          headway_s="فاصله اعزام / هدوی (دقیقه)", release_s="آزادسازی مدار (ثانیه)",
                          shunt_kmh="سرعت مانور پایانه (کیلومتر بر ساعت)")
            label = labels[key]
            try:
                if isinstance(val, bool): raise ValueError()
                val = float(val)
            except (TypeError, ValueError):
                raise ModelError(f"{label}: لطفاً یک عدد معتبر وارد کنید.") from None
            low, high = BOUNDS[key]
            if not math.isfinite(val) or not low <= val <= high:
                lo, hi = (low/60, high/60) if key == "headway_s" else (low, high)
                raise ModelError(f"{label}: مقدار باید بین {lo:g} و {hi:g} باشد.")
            candidate[key] = val
        if candidate["emergency_brake"] < candidate["service_brake"]:
            raise ModelError("قدرت ترمز اضطراری نمی‌تواند از ترمز سرویس کمتر باشد.")
        endpoints = [leg["nodes"][-1] for leg in self.legs()]
        if any(self.length(n) <= candidate["train_length_m"] for n in endpoints):
            raise ModelError("طول قطار برای بخش توقف یا تغییر جهت این سرویس بیش از حد مجاز است.")
        self.config = candidate
        self.log("CONFIG", "پارامترهای فرضی مدل تغییر کردند")

    def edit_track(self, n, length_m, speed_kmh, verified=False):
        if self.running or self.trains:
            raise ModelError("برای ویرایش مشخصات مسیر، مدل را متوقف کنید و همهٔ قطارها را حذف کنید.")
        if n not in self.tracks:
            raise ModelError("بخش مسیر انتخاب‌شده در مدل شناخته‌شده نیست. مسیر را دوباره انتخاب کنید.")
        length_m, speed_kmh = float(length_m), float(speed_kmh)
        if not math.isfinite(length_m + speed_kmh) or not 20 <= length_m <= 5000 or not 1 <= speed_kmh <= 100:
            raise ModelError("طول یا سرعت واردشده معتبر نیست. مقادیر را بررسی کنید.")
        self.tracks[n].update(length_m=length_m, speed_kmh=speed_kmh,
                              length_verified=bool(verified), speed_verified=bool(verified),
                              length_source="user_entered", speed_source="user_entered",
                              length_configured=False, speed_configured=False, speed_mode="user_override")
        self.log("DATA", f"ویرایش داده {n}؛ تأیید توسط کاربر، نه گواهی ایمنی")

    def add_train(self, section=None, line="A", low=None, high=None, label=None, sections=None):
        if len(self.trains) >= 150:
            raise ModelError("این برنامه حداکثر ۱۵۰ قطار را پشتیبانی می‌کند. این عدد به معنی ظرفیت واقعی خط نیست.")
        low = int(low or self.profile["low"])
        high = int(high or self.profile["high"])
        legs = self.legs(low, high)
        if any(self.length(leg["nodes"][-1]) <= self.config["train_length_m"] for leg in legs):
            raise ModelError("بدنهٔ قطار در بخش توقف یا تغییر جهت این سرویس جا نمی‌گیرد. طول قطار یا سرویس را بررسی کنید.")
        section = section or (f"T{high}.1" if line == "A" else f"T{low}.2")
        if section not in self.tracks:
            raise ModelError("بخش مسیر انتخاب‌شده در مدل شناخته‌شده نیست. مسیر را دوباره انتخاب کنید.")
        match = next(((i, leg["nodes"].index(section)) for i, leg in enumerate(legs)
                      if section in leg["nodes"] and leg["kind"] == "run" and leg["line"] == line), None)
        if section == "T22.2.2" and high == 21:
            match = (len(legs)-1, 0)
        if match is None:
            raise ModelError("محل انتخاب‌شده برای تعریف قطار، روی مسیر تعیین‌شده قرار ندارد.")
        own = self.owners()
        footprint = sections or [section]
        if not footprint or footprint[-1] != section or len(set(footprint)) != len(footprint):
            raise ModelError("بخش‌های بدنهٔ قطار را به‌ترتیب از عقب به جلو انتخاب کنید.")
        if any(n not in self.tracks or n in own or not self.check_clear(n, 0) for n in footprint):
            raise ModelError("این بخش از مسیر اشغال، مسدود یا برای حرکت دیگری رزرو شده است.")
        if any(b not in self.data["graph"].get(a, []) for a, b in zip(footprint, footprint[1:])):
            raise ModelError("بخش‌های انتخاب‌شده برای بدنهٔ قطار به یکدیگر متصل نیستند.")
        if len(footprint) == 1 and self.length(section) < self.config["train_length_m"]:
            raise ModelError("قطار در این بخش جا نمی‌گیرد. برای تعریف بدنه، چند بخش متصل را انتخاب کنید.")
        if len(footprint) > 1:
            nodes = legs[match[0]]["nodes"]
            if match[1] + 1 < len(footprint) or nodes[match[1]+1-len(footprint):match[1]+1] != footprint:
                raise ModelError("ترتیب بخش‌های بدنه با جهت حرکت انتخاب‌شده سازگار نیست.")
            if sum(self.length(n) for n in footprint[1:-1]) + 1 >= self.config["train_length_m"]:
                raise ModelError("تعداد مدارهای انتخاب‌شده با طول تعریف‌شدهٔ قطار سازگار نیست.")
        tid = self.next_id
        pos = 1.0 if len(footprint) > 1 else min(self.length(section)-1, self.config["train_length_m"] + 20)
        self.trains[tid] = dict(id=tid, label=str(label or f"TR-{tid:03d}")[:50], line=line,
                              low=low, high=high, legs=legs, leg=match[0], index=match[1],
                              head=section, pos=pos, speed=0.0, sections=list(footprint),
                              dwell_until=0.0, served=[], hold=False, doors=False,
                              state="stabled", reason="", distance_m=0.0, trips=0,
                              last_from=footprint[-2] if len(footprint)>1 else None)
        self.next_id += 1
        self._release_tail(self.trains[tid])
        self.log("TRAIN", f"تعریف یک قطار {self.trains[tid]['label']} در {section}", tid)
        return tid

    def remove_train(self, tid):
        tr = self.trains[int(tid)]
        if self.running or tr["speed"] > .01:
            raise ModelError("برای حذف قطار، ابتدا حرکت مدل را متوقف کنید.")
        del self.trains[int(tid)]
        self.reserved = {n: v for n, v in self.reserved.items() if v != int(tid)}
        for p in self.points.values():
            if p["owner"] == int(tid):
                p["owner"] = None
        self.update_terminal()
        self.log("REMOVE", f"حذف قطار {tr['label']}", int(tid))

    def _release_tail(self, tr):
        while len(tr["sections"]) > 1:
            coverage = tr["pos"] + sum(self.length(n) for n in tr["sections"][1:-1])
            if coverage < self.config["train_length_m"] - 1e-8:
                break
            n = tr["sections"].pop(0)
            self.release_until[n] = self.clock + self.config["release_s"]
            self.reserved.pop(n, None)

    def _next_leg(self, tr):
        from short_loop import resume_main_at_boundary
        if resume_main_at_boundary(self, tr):
            return
        previous = tr["legs"][tr["leg"]]
        if previous['kind'] in ('turn','dispatch'):
            if previous['kind']=='dispatch' and tr['high']==21:
                if not self.claim_terminal(tr):
                    tr['state']='held'
                    return
                deadline=self.terminal['ready_at']
            else:
                if 'turn_ready_at' not in tr:
                    tr.update(turn_started_at=self.clock,turn_ready_at=self.clock+tr.get('short_loop',{}).get('turn_s',self.config['turn_s']))
                deadline=tr['turn_ready_at']
            if self.clock+1e-7<deadline:
                tr['speed']=0.0
                tr['state']='dwell'
                tr['dwell_until']=deadline
                return
        next_index = (tr["leg"] + 1) % len(tr["legs"])
        from timed_short import before_departure
        if not before_departure(self, tr, previous, next_index):
            return
        tr["leg"] = next_index
        if tr.get("short_loop") and tr["leg"] == 0:
            tr["legs"][0]["nodes"] = list(tr["short_loop"]["normal_first"])
            tr["short_loop"]["wraps"] += 1
        new = tr["legs"][tr["leg"]]
        if new["nodes"][0] != tr["head"]:
            raise ModelError("تغییر مرحله امکان‌پذیر نیست؛ بین بخش‌های مسیر پیوستگی وجود ندارد.")
        if len(new["nodes"]) > 1 and new["nodes"][1] == tr["last_from"]:
            if len(tr["sections"]) != 1:
                tr["leg"] = (tr["leg"] - 1) % len(tr["legs"])
                tr["state"] = "held"
                tr["reason"] = "بدنه هنوز کامل در سکوی تغییر جهت قرار نگرفته"
                return
            tr["pos"] = min(self.length(tr["head"]), self.length(tr["head"]) -
                            tr["pos"] + self.config["train_length_m"])
            self.log("TURN", f"تغییر جهت هدف‌دار {tr['label']} در {tr['head']}", tr["id"])
        tr["index"] = 0
        tr["line"] = new["line"]
        tr["served"] = [0] if previous['kind']!='run' and new['kind']=='run' else []
        if previous['kind']=='dispatch' and new['kind']=='run' and tr['high']==21:
            self.terminal['returned']=True
        tr["doors"] = False
        tr["state"] = "ready"
        if previous["kind"] == "run":
            tr["trips"] += 1

    def _reserve(self, tr, distance):
        leg = tr["legs"][tr["leg"]]
        if tr['high']==21 and leg['kind'] in ('receive','dispatch') and not self.claim_terminal(tr):
            return [],False
        future = leg["nodes"][tr["index"]+1:]
        selected, covered = [], self.length(tr["head"]) - tr["pos"]
        for n in future:
            if leg["kind"] == "run" and covered >= distance:
                break
            if not self.check_clear(n, tr["id"]):
                tr["reason"] = f"منتظر آزادشدن تراک {n}"
                break
            selected.append(n)
            covered += self.length(n)
        # A target shunt is not started against an occupied destination.
        if leg["kind"] != "run" and len(selected) != len(future):
            return [], False
        req = self.requirements(leg, [tr["head"]] + selected)
        occ = self.owners()
        for p, desired in req.items():
            state = self.points[p]
            point_track = self.data["points"][p]["track"]
            if state["fault"] or state["owner"] not in (None, tr["id"]):
                tr["reason"] = f"سوزن {p} خراب است یا برای مسیر قطار دیگری رزرو شده است"
                return [], False
            if state["position"] != desired and point_track in occ:
                tr["reason"] = f"سوزن {p} زیر بدنه است"
                return [], False
        for n in selected:
            self.reserved[n] = tr["id"]
        ready = True
        for p, desired in req.items():
            state = self.points[p]
            state["owner"] = tr["id"]
            if state["target"] != desired:
                state["target"] = desired
                state["ready_at"] = self.clock + self.config["point_throw_s"]
                self.log("POINT", f"{p} → {desired} در مدل مستقل", tr["id"])
            if state["position"] != desired or state["ready_at"] > self.clock:
                ready = False
        return selected, ready

    def _step_train(self, tr, dt):
        if tr["hold"] or self.global_stop or any(self.tracks[n]["station"] in self.esb for n in tr["sections"]):
            tr["speed"] = 0
            tr["state"], tr["reason"] = "held", "توقف دستی یا توقف فوری شبیه‌ساز"
            return
        if tr["dwell_until"] > self.clock:
            tr["speed"], tr["state"], tr["doors"] = 0, "dwell", True
            return
        tr["doors"] = False
        tr["reason"] = ""
        leg = tr["legs"][tr["leg"]]
        head, index = tr["head"], tr["index"]
        length = self.length(head)
        platform = self.tracks[head]["platform"]
        timed_now=tr.get('short_loop',{}).get('timed',{})
        if (timed_now.get('status')=='pending' and leg['kind']=='run' and leg['line']==timed_now.get('direction')
                and platform and self.tracks[head]['station']==timed_now.get('origin') and tr['speed']<.05
                and abs(tr['pos']-min(length-1,self.config['train_length_m']+20))<.05):
            # A train already standing at the departure platform must wait for
            # the requested time, not loop around first or leave immediately.
            from timed_short import before_departure
            if not before_departure(self,tr,{'kind':'turn'},tr['leg']):
                tr['doors']=True
                return
            if index not in tr['served']:tr['served'].append(index)
        endpoint = index == len(leg["nodes"])-1
        if endpoint and leg.get('through'):
            # Continue onto the return line once the head clears the crossover;
            # retain speed, occupied circuits and point locks until the tail clears.
            self._next_leg(tr)
            return
        stop_key = index
        need_stop = (endpoint or (platform and leg["kind"] == "run")) and stop_key not in tr["served"]
        goal = min(length-1, self.config["train_length_m"]+20) if need_stop else length
        if need_stop and tr["pos"] >= goal-1e-7:
            tr["speed"] = 0
            timed = tr.get('short_loop', {}).get('timed', {})
            finishing_round=(timed.get('status')=='departed' and timed.get('round_trip') and timed.get('turn_reached')
                             and leg['line']!=timed.get('direction') and self.tracks[head]['station']==timed.get('origin'))
            if endpoint and leg['kind']=='run' and not finishing_round:
                if tr['high']==21 and head=='T21.2':
                    if not self.claim_terminal(tr):
                        tr['state']='held'
                        return
                else:
                    tr.update(turn_started_at=self.clock,turn_ready_at=self.clock+tr.get('short_loop',{}).get('turn_s',self.config['turn_s']),turn_station=self.tracks[head]['station'])
            tr["served"].append(stop_key)
            if platform and leg['kind'] == 'run' and timed.get('status') == 'departed' and (leg['line']==timed.get('direction') or timed.get('turn_reached')):
                station = self.tracks[head]['station']
                station_name = next((x['name'] for x in self.data['stations'] if x['id'] == station), f'ST{station}')
                self.log('SHORT_STATION', f"در مدل، {tr['label']} به ST{station} — {station_name} رسید و توقف کرد.", tr['id'])
            from timed_short import finish_at_destination
            if endpoint and leg['kind']=='run' and finish_at_destination(self, tr):
                return
            # Turn budgets INCLUDE movement: no additional 420-second pre-shunt wait.
            if endpoint and leg['kind']=='run':
                tr['dwell_until']=(max(self.clock+self.config['dwell_s'],tr.get('turn_ready_at',self.clock)) if timed.get('round_trip') and timed.get('turn_reached') and tr.get('short_loop',{}).get('direct_turn') else self.clock+(self.config['dwell_s'] if timed.get('round_trip') and timed.get('turn_reached') else 0))
            elif endpoint and leg['kind'] in ('turn','dispatch'):
                tr['dwell_until']=max(self.clock+self.config['dwell_s'],tr.get('turn_ready_at',self.clock))
            else:
                tr['dwell_until']=self.clock+self.config['dwell_s']
            tr["doors"] = platform
            tr["state"] = "dwell"
            self.log("BERTH", f"توقف {tr['label']} در {head}", tr["id"])
            return
        if endpoint and stop_key in tr["served"]:
            self._next_leg(tr)
            return
        v = tr["speed"]
        b, reaction, margin = self.config["service_brake"], self.config["reaction_s"], self.config["margin_m"]
        protection = v*v/(2*b)+v*reaction+margin+5
        selected, ready = self._reserve(tr, protection)
        # Retain occupied sections and currently needed reservations, never a
        # phantom whole-line lock. Point locks follow occupied/reserved circuits.
        keep = set(tr["sections"]) | set(selected)
        self.reserved = {n: owner for n, owner in self.reserved.items() if owner != tr["id"] or n in keep}
        permitted = self.route_speed(leg, index) / 3.6
        # A low-speed point/track remains restrictive until the whole body clears.
        for i, n in enumerate(tr["sections"][:-1]):
            permitted = min(permitted, self.speed(n, leg["kind"], tr["sections"][i+1])/3.6)
        previous = tr['legs'][(tr['leg']-1) % len(tr['legs'])]
        if previous.get('through') and any(n in previous['nodes'][:-1] for n in tr['sections']):
            permitted = min(permitted, self.config['shunt_kmh']/3.6)
        dist = length-tr["pos"]
        stop_distance = max(0.0, goal-tr["pos"]) if need_stop else None
        if not ready:
            stop_distance = min(stop_distance if stop_distance is not None else float("inf"),
                                0.0 if v < .01 else max(0, dist-margin))
            tr["reason"] = tr["reason"] or "منتظر تأیید قرارگرفتن سوزن در حالت درخواستی"
        if not selected and not endpoint:
            stop_distance = min(stop_distance if stop_distance is not None else float("inf"),
                                max(0, dist-margin))
        elif selected:
            free = dist
            for n in selected:
                upcoming = self.route_speed(leg, leg["nodes"].index(n))/3.6
                permitted = min(permitted, math.sqrt(max(0, upcoming*upcoming+2*b*max(0,free-v*reaction))))
                free += self.length(n)
            if len(selected) < len(leg["nodes"])-index-1:
                stop_distance = min(stop_distance if stop_distance is not None else float("inf"),
                                    max(0, free-margin))
        if stop_distance is not None:
            # Solve b*T + sqrt((b*T)^2 + 2*b*d), subtracting b*T, for a
            # conservative reaction + braking envelope. Finite-step margin.
            d = max(0, stop_distance - v*dt)
            permitted = min(permitted, max(0, math.sqrt((b*reaction)**2+2*b*d)-b*reaction))
        if v < permitted:
            new_v = min(permitted, v+self.config["acceleration"]*dt)
        else:
            new_v = max(permitted, v-b*dt)
        advance = (v+new_v)/2*dt
        if need_stop and advance >= goal-tr["pos"] and goal-tr["pos"] < 1.0:
            advance, new_v = max(0, goal-tr["pos"]), 0.0
        if not ready and v < .01:
            advance, new_v = 0, 0
        if advance > dist and not endpoint:
            nxt = leg["nodes"][index+1]
            if nxt not in selected or not ready or not self.check_clear(nxt, tr["id"]):
                self.global_stop = True
                self.running = False
                self.log("SAFETY", "حرکت غیرمجاز در مدل شناسایی شد؛ همهٔ قطارها متوقف شدند.", tr["id"])
                tr["speed"] = 0
                return
            tr["last_from"] = head
            tr["head"], tr["index"] = nxt, index+1
            tr["sections"].append(nxt)
            tr["pos"] = advance-dist
        else:
            tr["pos"] = min(goal if need_stop else length, tr["pos"]+advance)
        tr["speed"] = new_v
        tr["distance_m"] += advance
        self._release_tail(tr)
        if need_stop and goal-tr["pos"] < .02 and new_v < .1:
            tr["pos"] = goal
            tr["speed"] = 0
        tr["state"] = "moving" if new_v > .01 else "held"
        if tr["state"] == "held" and not tr["reason"]:
            tr["reason"] = "منتظر آزادشدن و آماده‌شدن مسیر در شبیه‌ساز"

    def tick(self, dt):
        if not math.isfinite(dt) or not 0 < dt <= 1:
            raise ModelError("گام زمانی واردشده معتبر نیست.")
        self.clock += dt
        self.update_terminal()
        for p in self.points.values():
            if not p["fault"] and p["ready_at"] <= self.clock:
                p["position"] = p["target"]
        if self.scheduler["enabled"] and self.clock >= self.scheduler["next"] and self.dispatch_count() < self.scheduler["limit"]:
            try:
                if self.scheduler.get("managed"):
                    tid = self.add_train(low=self.active_route["low"], high=self.active_route["high"])
                    self.trains[tid]["served"] = [0]
                else:
                    self.add_train()
                self.scheduler["issued"] += 1
                self.scheduler["next"] += self.config["headway_s"]
            except ModelError as exc:
                # Never silently change an impossible departure to +5 seconds.
                self.scheduler.update(enabled=False,blocked_reason=str(exc))
                self.running=False
                self.log('SCHEDULE_CONFLICT','اعزام در موعد ممکن نبود؛ برنامه متوقف شد: '+str(exc))
                for vehicle in self.trains.values():vehicle['speed']=0.0
                return
        for tr in sorted(self.trains.values(), key=lambda t: t["id"]):
            self._step_train(tr, dt)
            from timed_short import check_deadline
            check_deadline(self, tr)
        occ = self.owners()
        for name, p in self.points.items():
            sec = self.data["points"][name]["track"]
            if sec not in occ and sec not in self.reserved:
                p["owner"] = None
        self.update_terminal()
        self.owners()  # invariant assertion

    def advance(self, seconds):
        if not math.isfinite(seconds) or not 0 <= seconds <= 86400:
            raise ModelError("زمان سناریو معتبر نیست. مقدار زمان را بررسی کنید.")
        for _ in range(round(seconds/.1)):
            self.tick(.1)

    def leg_seconds(self, leg):
        # Continuous free-run envelope: circuit boundaries are NOT stops.
        # Configured lengths + conservative ATP envelopes, not a measured field time.
        nodes = leg["nodes"][1:]
        if not nodes:
            return 0.0
        a, b = self.config["acceleration"], self.config["service_brake"]
        lengths = [self.length(n) for n in nodes]
        limits = [self.route_speed(leg, i)/3.6 for i in range(1,len(leg["nodes"]))]
        stops = [leg["kind"] == "run" and self.tracks[n]["platform"] for n in nodes]
        boundary = [0.0] + [min(limits[i-1], limits[i]) for i in range(1,len(nodes))] + [0.0]
        for i, stop in enumerate(stops):
            if stop:
                boundary[i+1] = 0.0
        for i,d in enumerate(lengths):
            boundary[i+1] = min(boundary[i+1], math.sqrt(boundary[i]**2+2*a*d))
        for i in range(len(nodes)-1,-1,-1):
            boundary[i] = min(boundary[i], math.sqrt(boundary[i+1]**2+2*b*lengths[i]))
        total = 0.0
        for i,(d,limit) in enumerate(zip(lengths,limits)):
            u,w = boundary[i],boundary[i+1]
            peak = min(limit, math.sqrt((2*d+u*u/a+w*w/b)/(1/a+1/b)))
            ramp = (peak*peak-u*u)/(2*a)+(peak*peak-w*w)/(2*b)
            total += (peak-u)/a+(peak-w)/b+max(0,d-ramp)/peak
            if stops[i] and i < len(nodes)-1:
                total += self.config["dwell_s"]
        return total

    def validate_timetable(self, record, profile):
        if not isinstance(record, dict):
            raise ModelError("ساختار برنامهٔ زمانی معتبر نیست. اطلاعات ورودی را بررسی کنید.")
        try:
            a,b = float(record["run_a_s"]),float(record["run_b_s"])
            spare = float(record["reserve"])
            low,high = int(record.get("low",profile["low"])),int(record.get("high",profile["high"]))
        except (KeyError, TypeError, ValueError):
            raise ModelError("زمان رفت‌وبرگشت و تعداد قطارهای ذخیره باید به‌صورت عدد وارد شوند.")
        self.legs(low,high)
        if not all(math.isfinite(v) for v in (a,b,spare)) or not (30 <= a <= 21600 and 30 <= b <= 21600):
            raise ModelError("زمان هر جهت باید بین ۳۰ تا ۲۱۶۰۰ ثانیه باشد.")
        if not spare.is_integer() or not 0 <= spare <= 50:
            raise ModelError("تعداد قطارهای ذخیره باید عدد صحیحی بین صفر تا ۵۰ باشد.")
        return dict(run_a_s=a,run_b_s=b,reserve=int(spare),low=low,high=high,
                    source="user_scenario_unverified")

    def timetable_fleet(self, low, high):
        t = dict(self.timetable)
        matches = (t["low"],t["high"]) == (low,high)
        cycle = t["run_a_s"]+t["run_b_s"]+self.config["turn_s"]+(self.config["ehsan_turn_s"] if high==21 else self.config["turn_s"]) if matches else None
        active = math.ceil(cycle/self.config["headway_s"]) if matches else None
        return dict(**t, scope_matches=matches, cycle_s=cycle, active_trains=active,
                    total_trains=active+t["reserve"] if matches else None,
                    headway_s=self.config["headway_s"], certified=False)

    def capacity(self, low=None, high=None):
        legs = self.legs(low, high)
        ehsan=any(l['kind']=='receive' for l in legs)
        minimums=minimum_shunts(self,low,high)
        # Budgets are total B/A-to-A/B cycles, not extra pre-shunt waits.
        other=max(self.config['turn_s'],minimums['other_s'])
        e_time=max(self.config['ehsan_turn_s'],minimums['ehsan_s'])
        cycle=sum(self.leg_seconds(l) for l in legs if l['kind']=='run')+other+(e_time if ehsan else other)
        headways = []
        nodes = set(n for leg in legs for n in leg["nodes"])
        for n in nodes:
            v = self.speed(n, "run" if not self.tracks[n]["yard"] else "shunt")/3.6
            h = ((self.length(n)+self.config["train_length_m"]+self.config["margin_m"])/v
                 + self.config["release_s"])
            if self.tracks[n]["platform"]:
                h += self.config["dwell_s"]
            headways.append((h, n))
        bottleneck_h, bottleneck = max(headways)
        # Conservative serial terminal conflict allowance, not a proof of capacity.
        for leg in legs:
            if leg["kind"] != "run":
                h = self.leg_seconds(leg)+self.config["point_throw_s"]+self.config["dwell_s"]
                if h > bottleneck_h:
                    bottleneck_h, bottleneck = h, f"{leg['kind']}:{leg['nodes'][0]}"
        network_bound=bottleneck_h
        if ehsan and e_time+self.config['release_s']>bottleneck_h:
            bottleneck_h,bottleneck=e_time+self.config['release_s'],'ehsan:exclusive_420s_cycle'
        desired = self.config["headway_s"]
        effective = max(desired, bottleneck_h)
        return dict(cycle_s=cycle, requested_headway_s=desired, planning_bound_s=bottleneck_h,
                    effective_headway_s=effective, bottleneck=bottleneck,
                    fleet_requested=math.ceil(cycle/desired), fleet_at_effective=math.ceil(cycle/effective),
                    departures_per_hour=3600/effective, feasible_in_planner=desired >= bottleneck_h,
                    physical_line_capacity=None, certified=False,
                    network_bound_s=network_bound,terminal_policy=POLICY,ehsan_cycle_s=e_time if ehsan else None,
                    shunt_minimums=minimums,
                    timetable=self.timetable_fleet(
                        int(low if low is not None else self.profile["low"]),
                        int(high if high is not None else self.profile["high"])),
                    method="configured lengths / conservative positive ATP route-envelope diagnostic; not field capacity",
                    configured_lengths=sum(bool(self.tracks[n].get("length_configured")) for n in nodes),
                    configured_speeds=sum(bool(self.tracks[n].get("speed_configured")) for n in nodes),
                    service_track_count=len(nodes),
                    route_length_m={leg["line"]:sum(self.length(n) for n in leg["nodes"]) for leg in legs if leg["kind"] == "run"},
                    missing_verified_lengths=sum(not self.tracks[n]["length_verified"] for n in nodes),
                    missing_verified_speeds=sum(not self.tracks[n]["speed_verified"] for n in nodes))

    def dispatch_count(self):
        if not self.scheduler.get("managed") or not self.active_route:
            return len(self.trains)
        return sum((t.get("dispatch_profile",t)["low"], t.get("dispatch_profile",t)["high"]) == (self.active_route["low"], self.active_route["high"]) for t in self.trains.values())

    def route_action(self, obj):
        from route_dispatch import evaluate, start
        report = evaluate(self, obj)
        if obj["op"] == "route_start" and report["valid"]:
            start(self, report)
        return {"route": report}

    def path_neighbours(self, tr):
        legs, leg, ix = tr["legs"], tr["leg"], tr["index"]
        nodes = legs[leg]["nodes"]
        if not 0 <= ix < len(nodes) or nodes[ix] != tr["head"]:
            return None, None
        prev = nodes[ix-1] if ix > 0 else (tr["sections"][-2] if len(tr["sections"]) > 1 else None)
        if prev is None:
            before = legs[(leg-1) % len(legs)]["nodes"]
            prev = before[-2] if len(before) > 1 and before[-1] == tr["head"] else None
        nxt = nodes[ix+1] if ix+1 < len(nodes) else None
        if nxt is None:
            after = legs[(leg+1) % len(legs)]["nodes"]
            nxt = after[1] if len(after) > 1 and after[0] == tr["head"] else None
        return prev, nxt

    def snapshot(self):
        occ = self.owners()
        trains = []
        for tr in self.trains.values():
            r = {k: copy.deepcopy(v) for k, v in tr.items() if k != "legs"}
            r["speed_kmh"] = round(tr["speed"]*3.6, 2)
            r["kind"] = tr["legs"][tr["leg"]]["kind"]
            limits = [self.route_speed(tr["legs"][tr["leg"]], tr["index"])]
            limits += [self.speed(n,r["kind"],tr["sections"][i+1]) for i,n in enumerate(tr["sections"][:-1])]
            r["limit_kmh"] = min(limits)
            # Neighbouring circuits in the direction of travel. The schematic
            # polylines are drawn left-to-right regardless of direction, so the
            # map needs these to orient the head marker (otherwise it slides
            # backwards along the track and then jumps to the next one).
            r["path_prev"], r["path_next"] = self.path_neighbours(tr)
            body_leg = tr['legs'][tr['leg']]
            body_prev = tr['legs'][(tr['leg']-1) % len(tr['legs'])]['nodes']
            r['body_route'] = body_prev[:-1] + body_leg['nodes'][:tr['index']+1]
            if tr.get('short_loop'):
                sl=tr['short_loop']
                route=self.legs(sl['low'],sl['high'])
                timed=sl.get('timed')
                if timed:
                    # Trace the ACTUAL remaining approach, reversal and outbound
                    # legs. This includes the run from Ehsan before a ST19 turn;
                    # it avoids highlighting an unused side or the full line.
                    legs=tr['legs']; j=tr['leg']; path=[]
                    departed=timed['status']=='departed';turned=bool(timed.get('turn_reached'))
                    for step in range(len(legs)*2+1):
                        leg=legs[j]; nodes=list(sl['normal_first'] if j==0 and step>0 else leg['nodes'])
                        if step==0:nodes=nodes[tr['index']:]
                        path.append(nodes)
                        if leg['kind']=='run':
                            if not timed.get('round_trip') and leg['line']==timed['direction'] and (departed or step>0):break
                            if timed.get('round_trip'):
                                if turned and leg['line']!=timed['direction']:break
                                if leg['line']==timed['direction'] and (departed or step>0 or self.tracks[tr['head']]['station']==timed['origin']):
                                    departed=True;turned=True
                        j=(j+1)%len(legs)
                    r['short_route_paths']=[nodes for nodes in path if nodes]
                else:r['short_route_paths']=[list(l['nodes']) for l in route]
            trains.append(r)
        on_line = sum(any(self.tracks[n]["station"] <= 21 for n in tr["sections"]) for tr in self.trains.values())
        return dict(version=VERSION, clock=round(self.clock, 1), running=self.running, scale=self.scale,
                    clock_reference=copy.deepcopy(self.clock_reference),
                    origin=self.origin, imported_at=self.imported_at, data_revision=self.data.get("data_revision"),
                    esb_timing=self.data.get("esb_timing"),
                    counts=dict(total=len(trains), on_line=on_line, yard_only=len(trains)-on_line,
                                occupied_sections=len(occ), moving=sum(t["speed"] > .01 for t in trains)),
                    trains=trains, occupied=occ, reserved=dict(self.reserved),
                    closed=sorted(self.closed), esb=sorted(self.esb), global_stop=self.global_stop,
                    points=copy.deepcopy(self.points), config=dict(self.config),
                    profile=dict(self.profile), scheduler=dict(self.scheduler),active_route=copy.deepcopy(self.active_route),terminal=copy.deepcopy(self.terminal),
                    capacity=self.capacity(), events=list(self.events)[-80:])

    def export(self):
        return dict(schema="shiraz-offline-scenario-v1", exported_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
                    origin=self.origin, data_revision=self.data.get("data_revision"), config=dict(self.config), profile=dict(self.profile),
                    clock=self.clock, clock_reference=copy.deepcopy(self.clock_reference), tracks=self.tracks, trains=self.snapshot()["trains"],
                    closed=sorted(self.closed), esb=sorted(self.esb),
                    points=copy.deepcopy(self.points), timetable=dict(self.timetable),terminal=copy.deepcopy(self.terminal), events=list(self.events))

    def import_scenario(self, obj):
        if self.running:
            raise ModelError("برای بارگذاری وضعیت، ابتدا مدل را متوقف کنید.")
        if not isinstance(obj, dict) or obj.get("schema") != "shiraz-offline-scenario-v1":
            raise ModelError("قالب فایل شناخته‌شده نیست. لطفاً فایل وضعیت ذخیره‌شده از همین برنامه را انتخاب کنید.")
        if obj.get("data_revision") != self.data.get("data_revision"):
            raise ModelError("داده‌های این سناریو با طول‌ها و مسیرهای نسخهٔ فعلی سازگار نیست. سناریو را در نسخهٔ فعلی دوباره ایجاد و ذخیره کنید.")
        for key in ("config", "profile", "tracks", "points"):
            if key in obj and not isinstance(obj[key], dict):
                raise ModelError("ساختار اطلاعات فایل معتبر نیست یا فایل آسیب دیده است.")
        for key in ("trains", "closed", "esb"):
            if key in obj and not isinstance(obj[key], list):
                raise ModelError("ساختار فهرست‌های داخل فایل معتبر نیست. فایل را بررسی کنید.")
        # Transactional validation: do not partially replace a valid scene.
        fresh = Simulator(self.data)
        fresh.profile = {k: int(obj.get("profile", {}).get(k, self.profile[k])) for k in ("low", "high")}
        fresh.legs()
        for n, r in obj.get("tracks", {}).items():
            if n not in fresh.tracks:
                raise ModelError("بخش مسیر انتخاب‌شده در مدل شناخته‌شده نیست. مسیر را دوباره انتخاب کنید. در فایل")
            if not isinstance(r, dict):
                raise ModelError("اطلاعات یکی از بخش‌های مسیر در فایل معتبر نیست.")
            if r.get("speed_mode") == "user_override":
                fresh.edit_track(n, r["length_m"], r["speed_kmh"], False)
                fresh.tracks[n]["length_verified"] = bool(r.get("length_verified", False))
                fresh.tracks[n]["speed_verified"] = bool(r.get("speed_verified", False))
            else:
                baseline = fresh.tracks[n]
                # Source-backed rows cannot overwrite corrected lengths, mode,
                # speed envelopes or provenance with stale/tampered scenarios.
                for key in ("logic_id","length_m","speed_kmh","speed_mode","atp_route_caps",
                            "length_source","speed_source","length_configured","speed_configured"):
                    if r.get(key) != baseline.get(key):
                        raise ModelError(f"اطلاعات بخش مسیر {n} با پیکربندی نسخهٔ فعلی سازگار نیست.")
        fresh.set_config(obj.get("config", {}))
        if "timetable" in obj:
            fresh.timetable = fresh.validate_timetable(obj["timetable"], fresh.profile)
            if obj["timetable"].get("source") == "legacy_reference_unverified":
                ref = fresh.data["reference_timetable"]["one_way_min"]*60
                if (fresh.timetable["run_a_s"],fresh.timetable["run_b_s"],
                    fresh.timetable["low"],fresh.timetable["high"]) == (ref,ref,1,21):
                    fresh.timetable["source"] = "legacy_reference_unverified"
        if len(obj.get("trains", [])) > 150:
            raise ModelError("تعداد قطارها از حد پشتیبانی‌شدهٔ برنامه بیشتر است.")
        ids = set()
        for r in obj.get("trains", []):
            if not isinstance(r, dict):
                raise ModelError("اطلاعات یکی از قطارها معتبر نیست.")
            ident = int(r["id"])
            if ident <= 0 or ident in ids:
                raise ModelError("شناسهٔ قطار تکراری یا نامعتبر است. شناسه‌ای یکتا وارد کنید.")
            ids.add(ident)
            short_record = None
            if r.get("short_loop"):
                from short_loop import record_legs
                legs, short_record = record_legs(fresh,r)
            else:
                legs = fresh.legs(int(r["low"]), int(r["high"]))
            leg_index, index = int(r["leg"]), int(r["index"])
            if not 0 <= leg_index < len(legs) or not 0 <= index < len(legs[leg_index]["nodes"]):
                raise ModelError("مرحله یا موقعیت قطار در مسیر معتبر نیست.")
            head = legs[leg_index]["nodes"][index]
            if r["head"] != head or r["line"] != legs[leg_index]["line"]:
                raise ModelError("بخش مسیر یا جهت حرکت با مرحلهٔ فعلی قطار سازگار نیست.")
            sections = r["sections"]
            if not isinstance(sections, list) or not sections or sections[-1] != head or len(set(sections)) != len(sections):
                raise ModelError("ترتیب مدارهای انتخاب‌شده برای بدنهٔ قطار معتبر نیست.")
            if any(n not in fresh.tracks or n in fresh.owners() for n in sections):
                raise ModelError("یکی از بخش‌های بدنه نامشخص است یا قبلاً به قطار دیگری اختصاص داده شده است.")
            # A body may straddle a leg junction. Prepend the preceding leg,
            # except at a planned reversal where the train must fit one section.
            route = legs[leg_index]["nodes"][:index+1]
            prev = legs[(leg_index-1) % len(legs)]["nodes"]
            route = prev[:-1] + route
            if len(sections) > len(route) or route[-len(sections):] != sections:
                raise ModelError("بدنهٔ قطار با مسیر یا جهت حرکت انتخاب‌شده سازگار نیست.")
            pos = float(r["pos"])
            if not math.isfinite(pos) or not 0 <= pos <= fresh.length(head):
                raise ModelError("موقعیت واردشده برای قطار معتبر نیست.")
            coverage = pos + sum(fresh.length(n) for n in sections[1:-1])
            train_len = fresh.config["train_length_m"]
            if len(sections) == 1 and pos < train_len - 1e-7:
                raise ModelError("طول بخش‌های انتخاب‌شده برای بدنه از طول تعریف‌شدهٔ قطار کمتر است.")
            if len(sections) > 1 and not coverage < train_len <= coverage + fresh.length(sections[0]) + 1e-7:
                raise ModelError("مدارهای اشغال‌شده با طول بدنهٔ قطار سازگار نیستند.")
            served = [int(x) for x in r.get("served", [])]
            if any(x < 0 or x > index for x in served) or len(set(served)) != len(served):
                raise ModelError("اطلاعات توقف قطار در سکو معتبر نیست.")
            dwell = float(r.get("dwell_until", 0))
            distance = float(r.get("distance_m", 0))
            if not math.isfinite(dwell + distance) or min(dwell, distance) < 0:
                raise ModelError("زمان توقف یا مسافت واردشده معتبر نیست.")
            fresh.trains[ident] = dict(id=ident, label=str(r.get("label", f"TR-{ident:03d}"))[:50],
                low=int(r["low"]), high=int(r["high"]), line=r["line"], legs=legs,
                leg=leg_index, index=index, head=head, pos=pos, sections=list(sections),
                speed=0.0, hold=True, state="imported_held", reason="", doors=False,
                dwell_until=dwell, served=served, distance_m=distance,
                trips=max(0, int(r.get("trips", 0))),
                last_from=sections[-2] if len(sections)>1 else
                          (legs[leg_index]["nodes"][index-1] if index else
                           prev[-2] if len(prev)>1 else None))
            if 'reserve_vehicle_id' in r:
                reserve_id=int(r['reserve_vehicle_id'])
                if not 1<=reserve_id<=150 or any(t.get('reserve_vehicle_id')==reserve_id for t in fresh.trains.values()):raise ModelError('شناسه قطار ذخیره نامعتبر یا تکراری است.')
                fresh.trains[ident]['reserve_vehicle_id']=reserve_id
            if short_record:
                fresh.trains[ident]['short_loop'] = short_record
                fresh.trains[ident]['dispatch_profile'] = dict(low=short_record['main_low'],high=short_record['main_high'])
            for k in ('turn_started_at','turn_ready_at'):
                if k in r:
                    value=float(r[k])
                    if not math.isfinite(value) or value<0:raise ModelError('زمان گردش ذخیره‌شده در فایل معتبر نیست.')
                    fresh.trains[ident][k]=value
            if 'turn_station' in r:fresh.trains[ident]['turn_station']=int(r['turn_station'])
            if short_record and 'turn_started_at' in r and 'turn_ready_at' in r and int(r.get('turn_station',0)) != 21:
                if float(r['turn_ready_at'])+.001 < float(r['turn_started_at'])+short_record['turn_s']:
                    raise ModelError('زمان ذخیره‌شده اجازه کوتاه‌کردن بودجه گردش کوتاه را نمی‌دهد.')
        fresh.next_id = max(ids, default=0)+1
        fresh.closed = set(obj.get("closed", []))
        fresh.esb = set(int(x) for x in obj.get("esb", []))
        if not fresh.closed <= set(fresh.tracks) or not fresh.esb <= {s["id"] for s in fresh.data["stations"]} | {22}:
            raise ModelError("فایل شامل محدودیتی است که این نسخه از برنامه نمی‌شناسد.")
        clock = float(obj.get("clock", 0))
        if not math.isfinite(clock) or clock < 0:
            raise ModelError("زمان واردشده معتبر نیست. ساعت و تاریخ را بررسی کنید.")
        for name, record in obj.get("points", {}).items():
            if not isinstance(record, dict):
                raise ModelError("اطلاعات سوزن در فایل معتبر نیست. است")
            if name not in fresh.points or record.get("position") not in ("N", "R") or record.get("target") not in ("N", "R"):
                raise ModelError("وضعیت تعریف‌شده برای سوزن معتبر نیست.")
            fresh.points[name].update(position=record["position"], target=record["position"],
                                     ready_at=clock, fault=bool(record.get("fault")), owner=None)
        for name, p in fresh.points.items():
            sec = fresh.data["points"][name]["track"]
            ident = fresh.owners().get(sec)
            if ident:
                tr = fresh.trains[ident]
                required = fresh.requirements(tr["legs"][tr["leg"]], [sec]).get(name)
                if required and p["position"] != required:
                    raise ModelError("وضعیت سوزن زیر بدنهٔ قطار با مسیر حرکت آن سازگار نیست.")
                p["owner"] = ident
        fresh.clock=clock
        reference=obj.get('clock_reference')
        if reference is not None:
            from service_clock import civil
            if not isinstance(reference,dict):raise ModelError('مرجع ساعت ذخیره‌شده معتبر نیست.')
            stamp_value=civil(reference.get('datetime')).isoformat(timespec='seconds')
            ref_clock=float(reference.get('clock'))
            if not math.isfinite(ref_clock) or ref_clock<0 or ref_clock>clock:raise ModelError('مرجع ساعت ذخیره‌شده معتبر نیست.')
            fresh.clock_reference=dict(datetime=stamp_value,clock=ref_clock)
        term=obj.get('terminal')
        if term is not None:
            if not isinstance(term,dict) or term.get('policy')!=POLICY:raise ModelError('قواعد قفل پایانه در فایل شناخته‌شده نیست.')
            owner=term.get('owner')
            if owner is not None:
                if owner not in fresh.trains:raise ModelError('قطار مالک قفل پایانه در فهرست قطارها پیدا نشد.')
                start=float(term['started_at']);ready=float(term['ready_at'])
                if not math.isfinite(start+ready) or start<0 or start>clock+1e-6 or ready+1e-6<start+fresh.config['ehsan_turn_s']:
                    raise ModelError('اطلاعات ذخیره‌شده نمی‌تواند حداقل زمان گردش ۴۲۰ ثانیه‌ای احسان را نادیده بگیرد.')
                own_train=fresh.trains[owner]
                is_a=(own_train['head']=='T21.1' and own_train['line']=='A')
                if term.get('returned') and not is_a:raise ModelError('وضعیت بازگشت پایانه معتبر نیست؛ قطار هنوز در سکوی A قرار ندارد.')
                if own_train['legs'][own_train['leg']]['kind']=='run' and own_train['line']=='A' and clock+1e-6<ready:
                    raise ModelError('قطار پیش از پایان زمان تعیین‌شدهٔ گردش، از سکوی A اعزام شده است.')
                fresh.terminal.update(owner=owner,started_at=start,ready_at=ready,returned=bool(term.get('returned')),overrun=bool(term.get('overrun')))
                fresh.trains[owner].update(turn_started_at=start,turn_ready_at=ready,turn_station=21)
            clear=float(term.get('clear_after',0))
            if not math.isfinite(clear) or clear<0:raise ModelError('زمان آزادسازی پایانه معتبر نیست.')
            fresh.terminal['clear_after']=clear
        active=[t for t in fresh.trains.values() if t['high']==21 and t['legs'][t['leg']]['kind'] in ('receive','dispatch')]
        if len(active)>1:raise ModelError('در هر لحظه فقط یک قطار می‌تواند در چرخهٔ انحصاری احسان باشد.')
        if active and fresh.terminal['owner'] not in (None,active[0]['id']):raise ModelError('مالک قفل پایانه با قطار در حال شانت مطابقت ندارد.')
        if active and fresh.terminal['owner'] is None:
            t=active[0]
            fresh.terminal.update(owner=t['id'],started_at=clock,ready_at=clock+fresh.config['ehsan_turn_s'])
            t.update(turn_started_at=clock,turn_ready_at=clock+fresh.config['ehsan_turn_s'],turn_station=21)
        for name in ("tracks", "config", "profile", "trains", "next_id", "closed", "esb", "points", "timetable", "terminal"):
            setattr(self, name, getattr(fresh, name))
        self.data["tracks"] = self.tracks
        self.clock = clock
        self.clock_reference = fresh.clock_reference
        self.reserved.clear()
        self.release_until.clear()
        self.global_stop = False
        self.active_route = None
        self.scheduler = {"enabled": False, "next": clock, "limit": 0, "issued": 0}
        self.origin = "imported_snapshot_not_live_field"
        self.imported_at = obj.get("exported_at")
        # The event history is optional for old scenario files. Limit and validate
        # it before showing it; imported events are still simulator records only.
        saved_events=obj.get('events',[])
        self.events.clear()
        if isinstance(saved_events,list):
            for e in saved_events[-500:]:
                if isinstance(e,dict) and isinstance(e.get('kind'),str) and isinstance(e.get('message'),str):
                    try:
                        event_time=float(e.get('time',0))
                        if math.isfinite(event_time) and event_time>=0:
                            self.events.append(dict(time=round(event_time,1),kind=e['kind'][:50],message=e['message'][:1000],train=e.get('train')))
                    except (ValueError,TypeError):pass
        self.log("IMPORT", "وضعیت بارگذاری شد؛ همهٔ قطارها متوقف‌اند و تا تأیید شما حرکت نمی‌کنند.")

    def reset_line(self):
        """Explicit destructive reset of the offline movement scene only.

        Called under the same lock as clock ticks via the HTTP action handler.
        Keep user track/config/profile/timetable data; reset all runtime locks.
        """
        removed = len(self.trains)
        self.running = False
        self.trains.clear()
        self.reserved.clear()
        self.release_until.clear()
        self.closed.clear()
        self.esb.clear()
        self.global_stop = False
        self.clock = 0.0
        self.clock_reference = None
        self.scale = 1
        self.next_id = 1
        self.points = {n: dict(position="N", target="N", ready_at=0, fault=False, owner=None)
                       for n in self.data["points"]}
        self.active_route = None
        self.scheduler = dict(enabled=False, next=0.0, limit=0, issued=0, blocked_reason=None)
        self.terminal = dict(policy=POLICY, owner=None, started_at=None, ready_at=None,
                             clear_after=0.0, returned=False, overrun=False)
        self.origin = "new_empty_model_not_live_field"
        self.imported_at = None
        self.events.clear()
        self.log("RESET", f"خط شبیه‌ساز بازنشانی شد؛ {removed} قطار حذف شد. تنظیمات طول، سرعت و برنامه زمانی حفظ شدند.")
        return {"removed_trains": removed}

    def action(self, obj):
        if not isinstance(obj, dict):
            raise ModelError("ساختار درخواست معتبر نیست. لطفاً دوباره تلاش کنید.")
        op = obj.get("op")
        if op in ('smart_short_candidates','smart_short_predicted_ready','smart_short_existing_preview','smart_short_existing_apply','smart_short_reserve_preview','smart_short_reserve_apply'):
            from smart_short import dispatch
            return dispatch(self,obj)
        if op == 'short_clock_set':
            from timed_short import set_clock
            return set_clock(self,obj)
        if op in ('timed_short_preview','timed_short_apply'):
            from timed_short import evaluate
            return evaluate(self,obj,apply=op=='timed_short_apply')
        if op in ("short_preview", "short_apply"):
            from short_loop import evaluate
            return evaluate(self,obj,apply=op=="short_apply")
        if op == "short_return":
            from short_loop import return_main
            return return_main(self,obj["id"])
        if op == "map_add":
            from map_tools import add_at
            return {"id":add_at(self,obj)}
        if op in ("route_preview", "route_start"):
            return self.route_action(obj)
        if op == "reset_line":
            if obj.get("confirm") is not True:
                raise ModelError("برای بازنشانی خط باید حذف همه قطارها را تأیید کنید. این کار قابل بازگشت نیست.")
            return self.reset_line()
        elif op == "service_template":
            return {"service": ServiceClock(self, obj.get("plan", {})).template()}
        elif op == "service_positions":
            return {"service": ServiceClock(self, obj.get("plan", {})).calculate(obj.get("now"))}
        elif op in ('service_seed_preview','service_seed_apply'):
            from seed_timetable import seed
            return seed(self, obj, apply=op.endswith('_apply'))
        elif op == 'service_apply':
            if self.running or self.trains:raise ModelError('برای اعمال تنظیمات مشترک، مدل باید متوقف و بدون قطار باشد.')
            record=ServiceClock(self,obj.get('plan',{})).calculate(obj.get('now'))
            if not record['valid']:raise ModelError('برنامه رد شد: '+'؛ '.join(record['errors']))
            fresh=Simulator(self.data)
            fresh.config=dict(self.config)
            fresh.set_config(dict(ehsan_turn_s=record['turn_a_s'],turn_s=record['turn_b_s'],headway_s=record['headway_min']*60))
            fresh.timetable=fresh.validate_timetable(dict(run_a_s=record['run_a_s'],run_b_s=record['run_b_s'],reserve=record['reserve'],low=1,high=21),dict(low=1,high=21))
            self.config,self.profile,self.timetable=fresh.config,dict(low=1,high=21),fresh.timetable
            self.active_route = None
            self.scheduler.update(enabled=False,next=self.clock)
            self.log('TERMINAL_POLICY','محدودیت‌های برنامه زمانی بر مدل حرکتی اعمال شد؛ این کار اعزام بر اساس ساعت شبانه‌روز را آغاز نمی‌کند')
            return {'service':record}
        elif op == "run":
            if self.global_stop:
                raise ModelError("پیش از ادامه، توقف اضطراری را بازنشانی کنید.")
            self.running = True
        elif op == "pause":
            self.running = False
        elif op == "scale":
            val = float(obj["value"])
            if not math.isfinite(val) or not 1 <= val <= 60:
                raise ModelError("ضریب سرعت شبیه‌سازی باید بین ۱ تا ۶۰ باشد.")
            self.scale = val
        elif op == "add":
            return {"id": self.add_train(obj.get("section"), obj.get("line", "A"),
                                          obj.get("low"), obj.get("high"), obj.get("label"), obj.get("sections"))}
        elif op == "remove":
            self.remove_train(obj["id"])
        elif op == "hold":
            tr = self.trains[int(obj["id"])]
            tr["hold"] = bool(obj["value"])
            if tr["hold"]:
                tr["speed"] = 0.0
                tr["state"], tr["reason"] = "held", "قطار با دستور کاربر متوقف شده است"
        elif op == "close":
            n = obj["section"]
            if n not in self.tracks:
                raise ModelError("بخش مسیر انتخاب‌شده در مدل شناخته‌شده نیست. مسیر را دوباره انتخاب کنید.")
            (self.closed.add if obj["value"] else self.closed.discard)(n)
            self.log("CLOSURE", f"{n}: {'بسته' if obj['value'] else 'آزاد'}")
        elif op == "esb":
            st = int(obj["station"])
            if st not in {x["id"] for x in self.data["stations"]} | {22}:
                raise ModelError("ایستگاه انتخاب‌شده در مدل شناخته‌شده نیست.")
            (self.esb.add if obj["value"] else self.esb.discard)(st)
            if obj["value"]:
                for tr in self.trains.values():
                    if any(self.tracks[n]["station"] == st for n in tr["sections"]):
                        tr["speed"] = 0.0
                        tr["state"], tr["reason"] = "held", "توقف اضطراری ایستگاه (ESB) در شبیه‌ساز فعال است"
            self.log("ESB", f"ایستگاه ST{st}: " + ("توقف اضطراری فعال شد" if obj["value"] else "توقف اضطراری برداشته شد"))
        elif op == "emergency":
            self.global_stop = bool(obj["value"])
            if self.global_stop:
                self.running = False
                for t in self.trains.values():
                    t["speed"] = 0
            self.log("EMERGENCY", "توقف فوری شبیه‌ساز فعال شد" if self.global_stop else "توقف فوری شبیه‌ساز برداشته شد؛ برای حرکت، شروع / ادامه را بزنید")
        elif op == "point_fault":
            name = obj["point"]
            if name not in self.points:
                raise ModelError("سوزن انتخاب‌شده در مدل شناخته‌شده نیست.")
            self.points[name]["fault"] = bool(obj["value"])
            self.log("POINT_FAULT", f"سوزن {name}: " + ("خرابی آزمایشی فعال شد" if obj["value"] else "خرابی آزمایشی برطرف شد"))
        elif op == "point":
            name, pos = obj["point"], obj["position"]
            if name not in self.points or pos not in ("N", "R"):
                raise ModelError("فرمان واردشده برای سوزن معتبر نیست.")
            sec = self.data["points"][name]["track"]
            if sec in self.owners() or sec in self.reserved:
                raise ModelError("امکان تغییر وضعیت سوزن وجود ندارد؛ سوزن زیر بدنهٔ قطار است یا مسیر آن رزرو شده است.")
            p = self.points[name]
            if p["fault"]:
                raise ModelError("این سوزن در وضعیت خرابی قرار دارد. ابتدا خرابی را برطرف کنید.")
            p.update(target=pos, ready_at=self.clock+self.config["point_throw_s"])
        elif op == "config":
            self.set_config(obj["values"])
        elif op == "track":
            self.edit_track(obj["section"], obj["length_m"], obj["speed_kmh"], obj.get("verified", False))
        elif op == "profile":
            if self.running or self.trains:
                raise ModelError("برای تغییر سرویس، ابتدا همهٔ قطارها را از مدل حذف کنید.")
            self.legs(int(obj["low"]), int(obj["high"]))
            self.profile = {"low": int(obj["low"]), "high": int(obj["high"])}
            self.active_route = None
            self.scheduler["enabled"] = False
        elif op == "plan":
            if self.running or self.trains:
                raise ModelError("برای تغییر برنامه، مدل را متوقف کنید و همهٔ قطارها را حذف کنید.")
            profile = {"low": int(obj["low"]), "high": int(obj["high"])}
            self.legs(profile["low"], profile["high"])
            h = float(obj["headway_s"])
            if not math.isfinite(h) or not BOUNDS["headway_s"][0] <= h <= BOUNDS["headway_s"][1]:
                raise ModelError("فاصلهٔ زمانی بین اعزام‌ها (هدوی) معتبر نیست.")
            timetable = self.validate_timetable(obj["timetable"],profile) if "timetable" in obj else None
            if timetable and (timetable["low"],timetable["high"]) != (profile["low"],profile["high"]):
                raise ModelError("برنامهٔ زمانی با سرویس انتخاب‌شده مطابقت ندارد. سرویس و زمان‌ها را بررسی کنید.")
            self.profile = profile
            self.config["headway_s"] = h
            if timetable:
                self.timetable = timetable
            self.active_route = None
            self.scheduler["enabled"] = False
            self.log("PLAN", "پایانه‌ها و هدوی برنامه‌ریز تغییر کردند")
        elif op == "schedule":
            cap = self.capacity()
            if obj["value"] and any(self.length(leg["nodes"][-1]) <= self.config["train_length_m"] for leg in self.legs()):
                raise ModelError("بخش‌های مسیر گردش برای طول قطار این سرویس کافی نیستند.")
            if obj["value"] and self.config["headway_s"] < cap["planning_bound_s"]:
                raise ModelError(f"فاصله اعزام (هدوی) کوتاه است؛ طبق تنظیمات فعلی حداقل {cap['planning_bound_s']/60:.2f} دقیقه لازم است. فاصله اعزام را در تنظیمات افزایش دهید و دوباره تلاش کنید. این عدد محدودیت شبیه‌ساز است، نه ظرفیت تأییدشده خط واقعی.")
            mins=cap['shunt_minimums']
            if obj['value'] and self.config['turn_s']+.001<mins['other_s']:
                raise ModelError('زمان اختصاص‌یافته به گردش پایانهٔ دیگر از حداقل زمان موردنیاز مدل کمتر است.')
            if obj['value'] and cap['ehsan_cycle_s'] is not None and self.config['ehsan_turn_s']+.001<mins['ehsan_s']:
                raise ModelError('زمان مانور شانت احسان از زمان اختصاص‌یافته برای گردش بیشتر است.')
            limit = int(obj.get("limit", cap["fleet_at_effective"]))
            if not 1 <= limit <= 150:
                raise ModelError("سقف قطارهای اعزامی باید عددی بین ۱ و ۱۵۰ باشد.")
            needed=cap['timetable']['active_trains'] if cap['timetable']['scope_matches'] else cap['fleet_requested']
            if obj['value'] and limit<needed:raise ModelError(f'ناوگان کافی نیست؛ حداقل {needed} قطار برای این هدوی لازم است')
            if obj["value"]:
                self.active_route = None
                self.scheduler["managed"] = False
            self.scheduler.update(enabled=bool(obj["value"]), limit=limit, next=self.clock,blocked_reason=None)
        elif op == "import":
            self.import_scenario(obj["scenario"])
        else:
            raise ModelError("درخواست انجام این عملیات شناخته‌شده نیست. صفحه را تازه‌سازی کنید و دوباره تلاش کنید.")
        return {}


def serve(host="127.0.0.1", port=8790):
    model = Simulator()
    stop = threading.Event()

    def clock_loop():
        while not stop.wait(.1):
            with model.lock:
                if model.running:
                    try:
                        for _ in range(round(model.scale)):
                            if not model.running:break
                            model.tick(.1)
                    except Exception as exc:
                        model.running = False
                        model.global_stop = True
                        model.log("ERROR", f"{type(exc).__name__}: {exc}")

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(self, body, kind="application/json", status=200):
            if not isinstance(body, (str, bytes)):
                body = json.dumps(body, ensure_ascii=False, allow_nan=False)
            if isinstance(body, str):
                body = body.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", kind if kind.startswith("font/") else kind+"; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (OSError, BrokenPipeError):
                pass

        def do_GET(self):
            path = urlsplit(self.path).path
            with model.lock:
                if path == "/api/state":
                    return self.send(model.snapshot())
                if path == "/api/line":
                    return self.send(model.data)
                if path == "/api/export":
                    return self.send(model.export())
                if path == "/api/tracks.csv":
                    out = io.StringIO()
                    w = csv.DictWriter(out, fieldnames=["id", "logic_id", "station", "length_m", "length_source", "length_configured", "speed_kmh", "speed_source", "speed_configured", "speed_mode", "length_verified", "speed_verified"])
                    w.writeheader()
                    w.writerows({k: r[k] for k in w.fieldnames} for r in model.tracks.values())
                    return self.send(out.getvalue(), "text/csv")
            files = {"/": ("index.html", "text/html"), "/app.js": ("app.js", "text/javascript"),
                     "/units.js": ("units.js", "text/javascript"),
                     "/service.js": ("service.js", "text/javascript"),
                     "/style.css": ("style.css", "text/css"),
                     "/fonts/Vazirmatn-Variable.woff2": ("fonts/Vazirmatn-Variable.woff2", "font/woff2")}
            if path not in files:
                return self.send({"ok": False, "error": "این بخش در برنامه پیدا نشد."}, status=404)
            filename, content = files[path]
            self.send((ROOT / "static" / filename).read_bytes(), content)

        def do_POST(self):
            origin = self.headers.get("Origin")
            if origin and urlsplit(origin).netloc != self.headers.get("Host"):
                return self.send({"ok": False, "error": "درخواست از نشانی دیگری پذیرفته نمی‌شود؛ برنامه را از نشانی محلی خود باز کنید."}, status=403)
            if urlsplit(self.path).path != "/api/action":
                return self.send({"ok": False, "error": "این بخش در برنامه پیدا نشد."}, status=404)
            if "application/json" not in self.headers.get("Content-Type", ""):
                return self.send({"ok": False, "error": "فرمت اطلاعات ارسالی باید JSON باشد."}, status=415)
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= 1_048_576:
                    raise ModelError("حجم اطلاعات ارسالی معتبر نیست. لطفاً درخواست را کوچک‌تر کنید.")
                obj = json.loads(self.rfile.read(size))
                with model.lock:
                    result = model.action(obj)
                self.send({"ok": True, **result})
            except json.JSONDecodeError:
                self.send({"ok": False, "error": "فایل یا اطلاعات ارسالی JSON معتبر نیست؛ فایل ذخیره‌شده از همین برنامه را انتخاب کنید."}, status=400)
            except (KeyError, TypeError, IndexError):
                self.send({"ok": False, "error": "بخشی از اطلاعات ضروری درخواست وجود ندارد یا ساختار آن درست نیست. ورودی‌ها یا فایل انتخاب‌شده را بررسی کنید."}, status=400)
            except (ModelError, ValueError) as exc:
                text = str(exc)
                if not any("\u0600" <= ch <= "\u06ff" for ch in text):
                    text = "یکی از مقدارهای ورودی معتبر نیست؛ عددها و تاریخ و ساعت را بررسی کنید."
                self.send({"ok": False, "error": text}, status=400)

    server = ThreadingHTTPServer((host, port), Handler)
    threading.Thread(target=clock_loop, daemon=True).start()
    print(f"Shiraz standalone {VERSION}: http://{host}:{server.server_address[1]}")
    print("Independent simulation only. No UDP/MainIO/bridge sockets. Empty initial scene.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        server.server_close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8790)
    args = parser.parse_args()
    serve(args.host, args.port)