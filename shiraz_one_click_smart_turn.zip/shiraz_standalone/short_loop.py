"""Selected physical vehicle is diverted; no new service or vehicle is created.
Admission is a finite-horizon shadow run, not a field-interlocking certificate.
"""
import copy
import math
from collections import defaultdict


def clone(model):
    shadow = copy.copy(model)
    shadow._forecast = True
    # Immutable geometry/ATP data can be shared; ALL runtime containers are private.
    for key in ('config','trains','reserved','release_until','closed','esb','points',
                'profile','timetable','scheduler','terminal','active_route','events','clock_reference'):
        setattr(shadow,key,copy.deepcopy(getattr(model,key)))
    return shadow


def direct_turn_legs(model, low, high):
    """Build the A-to-B crossover from the modeled graph; fail closed if absent."""
    legs = copy.deepcopy(model.legs(low, high))
    a = next(i for i, leg in enumerate(legs) if leg['kind'] == 'run' and leg['line'] == 'A')
    turn, back = legs[(a+1) % len(legs)], legs[(a+2) % len(legs)]
    if turn['kind'] != 'turn' or back['kind'] != 'run' or back['line'] != 'B':
        raise ValueError('مسیر مستقیم برگشت در داده مدل مشخص نیست.')
    candidates = [(i, back['nodes'].index(n)) for i, n in enumerate(turn['nodes'])
                  if n in back['nodes'] and back['nodes'].index(n) + 1 < len(back['nodes'])]
    candidates = [(i,j) for i,j in candidates
                  if j > 0 and back['nodes'][j+1] in model.data['graph'].get(turn['nodes'][i], [])
                  and model.length(back['nodes'][j+1]) > model.config['train_length_m']]
    if not candidates:
        raise ValueError('برای این ایستگاه اتصال مستقیم و مناسب برگشت در داده مدل یافت نشد؛ گردش ثبت نمی‌شود.')
    i,j = candidates[-1]
    turn['nodes'] = turn['nodes'][:i+1] + [back['nodes'][j+1]]
    turn['through'] = True
    back['nodes'] = back['nodes'][j+1:]
    return legs


def prepare(model, obj, require_headway=True, direct_turn=False):
    tid, low, high = int(obj['id']), int(obj['low']), int(obj['high'])
    if tid not in model.trains:raise ValueError('ابتدا یک قطار موجود در مدل حرکتی را انتخاب کنید؛ نشان‌های بنفش برنامه‌ای، قطار مدل حرکتی نیستند.')
    tr=model.trains[tid]
    if tr.get('short_loop'):raise ValueError('این قطار هم‌اکنون در گردش کوتاه است؛ ابتدا بازگشت آن به سرویس اصلی را درخواست کنید.')
    if model.global_stop or tr['hold']:raise ValueError('قطار یا کل مدل توقف دستی/اضطراری دارد؛ ابتدا علت توقف را بررسی کنید.')
    if not tr['low'] <= low < high <= tr['high']:raise ValueError('دو ایستگاه گردش کوتاه باید به‌ترتیب داخل محدوده سرویس اصلی همین قطار باشند.')
    if (low,high)==(tr['low'],tr['high']):raise ValueError('این دو ایستگاه همان پایانه‌های سرویس اصلی هستند؛ مسیر کوتاه‌تری انتخاب کنید.')
    leg=tr['legs'][tr['leg']]
    standard=direct_turn_legs(model,low,high) if direct_turn else model.legs(low,high)
    entry='run'
    if leg['kind']=='dispatch' and high==21 and tr['high']==21 and tr['line']=='A':
        # Continue from the actual yard position via the known Ehsan dispatch
        # path, then run A. Do not place the train on the station platform.
        expected=standard[-1]
        if leg['nodes']!=expected['nodes'] or leg['nodes'][tr['index']]!=tr['head']:
            raise ValueError('مسیر خروج از پایانه با داده معتبر مسیر مطابقت ندارد.')
        rotation=copy.deepcopy([standard[-1]]+standard[:-1]);normal_first=list(rotation[0]['nodes']);entry='yard_dispatch'
    else:
        if leg['kind']!='run':raise ValueError('قطار در حال مانور یا گردش است؛ پس از ورود به مسیر اصلی دوباره بررسی کنید.')
        ci=next(i for i,l in enumerate(standard) if l['kind']=='run' and l['line']==tr['line'])
        rotation=copy.deepcopy(standard[ci:]+standard[:ci])
        destination=rotation[0]['nodes'][-1]
        if destination not in leg['nodes'] or leg['nodes'].index(destination)<tr['index']:
            raise ValueError('قطار از ایستگاه برگشت انتخاب‌شده گذشته است؛ تغییر جهت ناگهانی در تراک مجاز نیست.')
        finish=leg['nodes'].index(destination)
        distance=sum(model.length(n) for n in leg['nodes'][tr['index']:finish])+min(model.length(destination)-1,model.config['train_length_m']+20)-tr['pos']
        stop=tr['speed']**2/(2*model.config['service_brake'])+tr['speed']*model.config['reaction_s']+model.config['margin_m']
        if distance+1e-6<stop:raise ValueError('فاصله تا ایستگاه برگشت برای توقف با ترمز تعریف‌شده کافی نیست؛ قطار دیگری یا ایستگاه دورتر را انتخاب کنید.')
        normal_first=list(rotation[0]['nodes'])
        rotation[0]['nodes']=list(leg['nodes'][:finish+1])
    if any(n not in rotation[0]['nodes'] for n in tr['sections']):raise ValueError('بدنه قطار هنوز در بخش مناسب برای اتصال به گردش کوتاه قرار نگرفته است.')
    nodes={n for l in standard for n in l['nodes']}
    for l in rotation:
        if any(b not in model.data['graph'].get(a,[]) for a,b in zip(l['nodes'],l['nodes'][1:])):raise ValueError('اتصال پیوسته مسیر گردش در داده‌ها وجود ندارد.')
        if model.length(l['nodes'][-1])<=model.config['train_length_m']:raise ValueError('بدنه قطار در انتهای مسیر گردش جا نمی‌گیرد.')
    for n in nodes:
        if n in model.closed or model.tracks[n]['station'] in model.esb:raise ValueError('تراک '+n+' بسته است یا توقف اضطراری ایستگاه آن فعال است.')
    points={p for l in standard for p in model.requirements(l,l['nodes'])}
    for p in points:
        if model.points[p]['fault']:raise ValueError('سوزن '+p+' در مسیر گردش خراب است.')
    cap=model.capacity(low,high)
    if require_headway and model.config['headway_s']<cap['planning_bound_s']:raise ValueError(f"هدوی اصلی برای گردش کوتاه کافی نیست؛ حد اولیه این مدل {cap['planning_bound_s']/60:.2f} دقیقه است.")
    return dict(id=tid,low=low,high=high,legs=rotation,normal_first=normal_first,tracks=sorted(nodes),
                main_low=tr['low'],main_high=tr['high'],first_line=tr['line'],entry=entry,direct_turn=direct_turn,
                turn_s=max(model.config['turn_s'],math.ceil(cap['shunt_minimums']['other_s'])),
                route_length_m=cap['route_length_m'],cycle_s=cap['cycle_s'],headway_s=model.config['headway_s'])


def install(model, prepared):
    p=prepared;tr=model.trains[p['id']]
    tr['dispatch_profile']=tr.get('dispatch_profile',dict(low=tr['low'],high=tr['high']))
    tr['short_loop']={k:copy.deepcopy(p[k]) for k in ('low','high','main_low','main_high','normal_first','tracks','turn_s','headway_s','first_line','entry','direct_turn')}
    tr['short_loop'].update(started_at=model.clock,wraps=0,return_requested=False)
    tr['legs']=copy.deepcopy(p['legs']);tr['leg']=0
    # Initial approach keeps the original run prefix/index, served indices and body.
    tr['low'],tr['high']=p['low'],p['high']
    keep={n for l in tr['legs'] for n in l['nodes']}|set(tr['sections'])
    model.reserved={n:o for n,o in model.reserved.items() if o!=tr['id'] or n in keep}


def inspect_wait(model,tr):
    if tr['speed']>.05:return None
    leg=tr['legs'][tr['leg']];future=leg['nodes'][tr['index']+1:]
    search=future if leg['kind']!='run' else future[:1]
    owners=model.owners()
    for n in search:
        owner=owners.get(n) or model.reserved.get(n)
        if owner and owner!=tr['id']:return ('تراک '+n,int(owner))
    for p in model.requirements(leg,[tr['head']]+search):
        owner=model.points[p]['owner']
        if owner and owner!=tr['id']:return ('سوزن '+p,int(owner))
    return None


def forecast(shadow, seconds, selected, region):
    waits=defaultdict(set);arrivals=defaultdict(list);seen=set();start=shadow.clock
    for _ in range(math.ceil(seconds)):
        for _step in range(10):
            shadow.tick(.1)
            if shadow.global_stop:break
        if shadow.global_stop or (shadow.scheduler.get('blocked_reason') and not shadow.scheduler['enabled']):
            return dict(error=shadow.scheduler.get('blocked_reason') or 'توقف حفاظتی مدل',waits=waits,arrivals=arrivals)
        for tr in shadow.trains.values():
            block=inspect_wait(shadow,tr)
            if block:waits[(tr['id'],block[1],block[0])].add(round(shadow.clock-start))
            leg=tr['legs'][tr['leg']]
            if leg['kind']=='run' and shadow.tracks[tr['head']]['platform'] and tr['index'] in tr['served']:
                key=(tr['id'],tr['head'],tr['trips'])
                if key not in seen:
                    seen.add(key)
                    station=shadow.tracks[tr['head']]['station']
                    if region[0]<=station<=region[1]:arrivals[(station,tr['line'])].append((shadow.clock-start,tr['id']))
    return dict(error=None,waits=waits,arrivals=arrivals)


def evaluate(model,obj,apply=False):
    try:
        p=prepare(model,obj)
        baseline=clone(model);candidate=clone(model);install(candidate,p)
        seconds=max(3600,model.capacity()['cycle_s']+2*model.config['headway_s'],p['cycle_s']*2)
        if seconds>10800:raise ValueError('بازه لازم برای بررسی از سه ساعت بیشتر است؛ این نسخه امکان تأیید این سناریو را ندارد و آن را اجرا نمی‌کند.')
        b=forecast(baseline,seconds,p['id'],(p['low'],p['high']))
        if b['error']:raise ValueError('خود سرویس اصلی در پیش‌بینی متوقف می‌شود: '+b['error']+'؛ ابتدا برنامه اصلی را اصلاح کنید.')
        c=forecast(candidate,seconds,p['id'],(p['low'],p['high']))
        if c['error']:raise ValueError('گردش کوتاه در پیش‌بینی قابل اجرا نیست: '+c['error'])
        for key,samples in c['waits'].items():
            extra=len(samples-b['waits'].get(key,set()))
            if extra>0:
                raise ValueError(f'تداخل پیش‌بینی‌شده: قطار {key[0]} در {key[2]} به‌خاطر قطار {key[1]} حدود {math.ceil(extra)} ثانیه بیشتر از سرویس اصلی منتظر می‌ماند. گردش کوتاه اعمال نشد.')
        for (station,line),events in c['arrivals'].items():
            events.sort()
            for left,right in zip(events,events[1:]):
                if p['id'] in (left[1],right[1]) and right[0]-left[0]+1<model.config['headway_s']:
                    raise ValueError(f'هدوی اصلی در ST{station} جهت {line} نقض می‌شود؛ فاصله عبور شناسه‌های {left[1]} و {right[1]} حدود {(right[0]-left[0])/60:.2f} دقیقه است؛ هدوی لازم {model.config["headway_s"]/60:.2f} دقیقه است. گردش کوتاه اعمال نشد.')
        if candidate.trains[p['id']]['short_loop']['wraps']<1:raise ValueError('در بازه پیش‌بینی یک چرخه کامل گردش کوتاه انجام نشد؛ اجرای آن تأیید نمی‌شود.')
        report={k:p[k] for k in ('id','low','high','tracks','turn_s','route_length_m','cycle_s','headway_s')}
        report.update(valid=True,applied=False,errors=[],horizon_s=math.ceil(seconds),certified=False)
        if apply:
            install(model,p)
            model.trains[p['id']]['short_loop']['checked_until']=model.clock+seconds
            model.log('SHORT_LOOP',f"قطار {p['id']} از سرویس اصلی به گردش کوتاه ST{p['low']} تا ST{p['high']} اختصاص یافت؛ هدوی اصلی تغییر نکرد.",p['id'])
            report['applied']=True
        return {'short_loop':report}
    except (ValueError,KeyError,TypeError,IndexError) as exc:
        return {'short_loop':dict(valid=False,applied=False,errors=[str(exc)],certified=False)}


def return_main(model,tid):
    tr=model.trains[int(tid)];sl=tr.get('short_loop')
    if not sl:raise ValueError('این قطار در گردش کوتاه نیست.')
    sl['return_requested']=True
    if sl.get('timed') and sl['timed']['status'] in ('pending','missed'):sl['timed']['status']='cancelled'
    return {'message':'درخواست لغو ثبت شد؛ قطار در مرز مناسب مسیر به سرویس اصلی بازمی‌گردد. اگر قطار توقف دستی دارد، پس از بررسی آن را آزاد کنید.'}


def resume_main_at_boundary(model,tr):
    sl=tr.get('short_loop')
    if not sl or not sl.get('return_requested'):return False
    old=tr['legs'][tr['leg']]
    if old['kind']!='run':return False
    legs=model.legs(sl['main_low'],sl['main_high'])
    i=next(i for i,l in enumerate(legs) if l['kind']=='run' and l['line']==tr['line'])
    nodes=legs[i]['nodes']
    if tr['head'] not in nodes:return False
    index=nodes.index(tr['head'])
    # Continue forward in the same direction; body, speed and position unchanged.
    tr.update(legs=legs,leg=i,index=index,served=[index],low=sl['main_low'],high=sl['main_high'])
    tr.pop('short_loop',None)
    model.log('SHORT_RETURN','قطار '+str(tr['id'])+' به ادامه مسیر اصلی همان جهت بازگشت.',tr['id'])
    return True


def record_legs(model,record):
    """Rebuild a stored short route only from trusted topology, not supplied nodes."""
    raw=record.get('short_loop')
    if not isinstance(raw,dict):raise ValueError('اطلاعات مسیر گردش کوتاه ذخیره‌شده معتبر نیست.')
    low,high=int(record['low']),int(record['high'])
    ml,mh=int(raw['main_low']),int(raw['main_high'])
    if not ml<=low<high<=mh or (ml,mh)==(low,high):raise ValueError('محدوده گردش کوتاه ذخیره‌شده معتبر نیست.')
    original=model.legs(ml,mh);direct=raw.get('direct_turn',False)
    if not isinstance(direct,bool):raise ValueError('نوع مسیر برگشت ذخیره‌شده معتبر نیست.')
    standard=direct_turn_legs(model,low,high) if direct else model.legs(low,high)
    first=raw.get('first_line')
    if first not in ('A','B'):raise ValueError('جهت آغاز گردش کوتاه ذخیره‌شده مشخص نیست.')
    entry=raw.get('entry','run')
    if entry not in ('run','yard_dispatch'):raise ValueError('نوع ورود به گردش کوتاه معتبر نیست.')
    if entry=='yard_dispatch':
        if high!=21 or mh!=21 or first!='A':raise ValueError('ورود از پایانه با محدوده مسیر سازگار نیست.')
        legs=copy.deepcopy([standard[-1]]+standard[:-1])
    else:
        ci=next(i for i,l in enumerate(standard) if l['kind']=='run' and l['line']==first)
        legs=copy.deepcopy(standard[ci:]+standard[:ci])
    normal_first=list(legs[0]['nodes'])
    wraps=int(raw.get('wraps',0))
    if wraps<0:raise ValueError('شمار چرخه گردش کوتاه معتبر نیست.')
    if not wraps and entry=='run':
        main=next(l for l in original if l['kind']=='run' and l['line']==first)
        legs[0]['nodes']=main['nodes'][:main['nodes'].index(normal_first[-1])+1]
    cap=model.capacity(low,high);turn=float(raw['turn_s'])
    if not math.isfinite(turn) or not max(model.config['turn_s'],cap['shunt_minimums']['other_s'])-.001<=turn<=3600:
        raise ValueError('بودجه گردش کوتاه ذخیره‌شده از زمان مجاز مدل کمتر یا خارج از محدوده است.')
    sl=dict(low=low,high=high,main_low=ml,main_high=mh,normal_first=normal_first,
            first_line=first,entry=entry,direct_turn=direct,tracks=sorted({n for l in standard for n in l['nodes']}),turn_s=turn,
            headway_s=model.config['headway_s'],wraps=wraps,return_requested=bool(raw.get('return_requested')),started_at=0)
    if raw.get('timed'):
        from timed_short import restore_timed
        sl['timed']=restore_timed(raw['timed'],low,high)
    return legs,sl
