@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Open http://127.0.0.1:8790 in your browser after startup.
where py >nul 2>&1
if %ERRORLEVEL% EQU 0 (
  py -3 -X utf8 simulator.py %*
) else (
  python -X utf8 simulator.py %*
)
pause