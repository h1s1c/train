"""Place timetable-estimated active trains into a paused empty model.

This is a starting scenario, never a source of actual live positions. Trains
without a known circuit, or with an inconsistent footprint, are reported and
not made up. New movement starts from rest; future timetable departures are
not synthesized by this operation.
"""
import copy
import math
from datetime import datetime
from service_clock import ServiceClock
from short_loop import clone


def seed(model, obj, apply=False):
    from simulator import ModelError
    if model.running or model.trains:
        raise ModelError('برای انتقال برنامه، مدل باید متوقف و بدون قطار باشد؛ هیچ قطار موجودی حذف یا جابه‌جا نمی‌شود.')
    if model.global_stop:
        raise ModelError('توقف فوری مدل فعال است؛ پیش از انتقال علت آن را بررسی کنید.')
    record=ServiceClock(model,obj.get('plan',{})).calculate(obj.get('now'))
    if not record['valid']:
        raise ModelError('برنامه زمانی معتبر نیست: '+'؛ '.join(record['errors']))
    shadow=clone(model)
    shadow.set_config(dict(ehsan_turn_s=record['turn_a_s'],turn_s=record['turn_b_s'],
                           headway_s=record['headway_min']*60,dwell_s=obj['plan']['dwell_s']))
    shadow.profile=dict(low=1,high=21)
    shadow.timetable=shadow.validate_timetable(dict(run_a_s=record['run_a_s'],run_b_s=record['run_b_s'],
                                                      reserve=record['reserve'],low=1,high=21),shadow.profile)
    shadow.clock_reference=dict(datetime=record['now'],clock=shadow.clock)
    shadow.active_route=None
    shadow.scheduler.update(enabled=False,next=shadow.clock)
    placed=[];unresolved=[];reserves=[]
    for v in record['vehicles']:
        if v['status']=='reserve':
            reserves.append(dict(label=v['label'],reason='ذخیره؛ محل استقرار معلوم نیست'))
            continue
        if v['status'] not in ('moving','station') or not v['track'] or v['head_m'] is None:
            unresolved.append(dict(label=v['label'],status=v['status'],reason='تراک دقیق در این وضعیت از برنامه زمانی معلوم نیست؛ محل، جهت و وضعیت قطار باید تعیین شود.'))
            continue
        old_points=copy.deepcopy(shadow.points)
        prior=(copy.deepcopy(shadow.trains),shadow.next_id,copy.deepcopy(shadow.reserved),copy.deepcopy(shadow.release_until),copy.deepcopy(shadow.events))
        try:
            direction=v['direction']; head=v['track']; pos=float(v['head_m'])
            leg=next(x for x in shadow.legs(1,21) if x['kind']=='run' and x['line']==direction)
            nodes=leg['nodes'];index=nodes.index(head)
            if not math.isfinite(pos) or not 0<=pos<=shadow.length(head):raise ValueError('موقعیت سر قطار خارج از تراک است.')
            footprint=[head];covered=pos;i=index
            while covered+1e-7<shadow.config['train_length_m'] and i>0:
                i-=1;footprint.insert(0,nodes[i]);covered+=shadow.length(nodes[i])
            if covered+1e-7<shadow.config['train_length_m']:
                raise ValueError('بدنه قطار در ابتدای مسیر قابل تعیین نیست.')
            if any(not shadow.check_clear(n,0) for n in footprint):
                raise ValueError('مدار بدنه اشغال، مسدود یا رزرو است.')
            # add_train uses pos=1 during initialization; if the exact computed
            # footprint cannot survive this temporary position, fail closed.
            if len(footprint)>1 and sum(shadow.length(n) for n in footprint[1:-1])+1>=shadow.config['train_length_m']:
                raise ValueError('بدنه قطار در مرز مدار با دقت این مدل قابل مقداردهی نیست.')
            req=shadow.requirements(leg,footprint)
            for point,desired in req.items():
                p=shadow.points[point]
                if p['fault'] or p['owner'] is not None or p['ready_at']>shadow.clock:
                    raise ValueError('سوزن '+point+' خراب، در حال تغییر یا متعلق به قطار دیگری است.')
                p.update(position=desired,target=desired,ready_at=shadow.clock)
            tid=shadow.add_train(head,direction,1,21,label=v['label'],sections=footprint)
            tr=shadow.trains[tid];tr['pos']=pos;tr['last_from']=nodes[index-1] if index else None
            # A moving train may be approaching, not leaving, a platform.
            # Only skip the stop if it has already departed that same station.
            at_platform=shadow.tracks[head]['platform']
            already_departed=(v['status']=='station' or shadow.tracks[head]['station']==v.get('from_station'))
            tr['served']=[index] if at_platform and already_departed else []
            tr['speed']=0.0;tr['state']='stabled';tr['reason']='موقعیت اولیه تخمینی برنامه؛ حرکت از حالت سکون'
            if v['status']=='station':
                remaining=max(0,(datetime.fromisoformat(v['station_departure'])-datetime.fromisoformat(record['now'])).total_seconds())
                tr.update(dwell_until=shadow.clock+remaining,state='dwell',doors=True,reason='توقف باقیمانده از جدول برنامه‌ای')
            for point in req:
                if shadow.data['points'][point]['track'] in footprint:
                    shadow.points[point]['owner']=tid
            placed.append(dict(id=tid,label=v['label'],track=head,position_m=pos,direction=direction,sections=list(footprint),status=v['status']))
        except (ValueError,KeyError,TypeError,StopIteration) as exc:
            shadow.points=old_points
            shadow.trains,shadow.next_id,shadow.reserved,shadow.release_until,shadow.events=prior
            unresolved.append(dict(label=v['label'],status=v['status'],reason=str(exc)))
    summary=dict(placed=placed,unresolved=unresolved,reserves=reserves,complete=not unresolved,
                 applied=False,now=record['now'])
    if apply:
        if obj.get('expected') != summary:
            raise ModelError('وضعیت یا نتیجه پیش‌نمایش تغییر کرد؛ انتقال انجام نشد. دوباره بررسی کنید.')
        if not placed:raise ModelError('هیچ قطاری با موقعیت و بدنه قابل تعیین پیدا نشد؛ مدل تغییر نکرد.')
        for k in ('config','profile','timetable','trains','next_id','points','reserved','release_until','events','clock_reference','active_route','scheduler'):
            setattr(model,k,getattr(shadow,k))
        model.log('PLAN_SEED',f"انتقال {len(placed)} قطار از موقعیت تخمینی برنامه به مدل؛ {len(unresolved)} قطار برنامه‌ای بدون موقعیت معتبر باقی ماند.")
        summary['applied']=True
    return {'service':record,'seed':summary}
