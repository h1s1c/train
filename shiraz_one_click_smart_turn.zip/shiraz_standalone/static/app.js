"use strict";
let lineData=null,state=null,selected=null,zoom=1,busy=false,renderedData=false,mapPlanned=null,mapClockBusy=false,shortBusy=false,mapFocusTrain=null;
const $=id=>document.getElementById(id),fa=new Intl.NumberFormat("fa-IR",{maximumFractionDigits:1});
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmt=v=>fa.format(v),code=s=>`<code>${esc(s)}</code>`;
// Only touch the DOM when markup changes; polling every 700 ms otherwise destroys buttons mid-click and resets focus/scroll.
function setHTML(node,html){if(node&&node._html!==html){node._html=html;node.innerHTML=html;return true;}return false;}
function setText(node,text){if(node&&node.textContent!==text){node._html=undefined;node.textContent=text;}}
function speedText(t){
 if(t.speed_mode==="user_override")return fmt(t.speed_kmh);
 const values=[...new Set(Object.values(t.atp_ceiling_values||{}).flat().filter(x=>x>0))].sort((a,b)=>a-b);
 return values.length?values.map(fmt).join(" / "):"نامشخص؛ بدون محدودیت سرعت بیشتر از صفر در فایل ATP";
}
let toastTimer;
function toast(message,error=false){$("toast").textContent=message;$("toast").style.display="block";$("toast").style.background=error?"var(--red)":"var(--text)";clearTimeout(toastTimer);toastTimer=setTimeout(()=>$("toast").style.display="none",5500);}
async function action(obj){try{const r=await fetch("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(obj)});const result=await r.json();if(!result.ok)throw Error(result.error);await poll();return result;}catch(e){toast(e instanceof SyntaxError?"پاسخ سرور خوانده نشد؛ اتصال را بررسی و دوباره تلاش کنید.":e instanceof TypeError?"ارتباط با شبیه‌ساز برقرار نیست؛ پنجره اجرای برنامه را بررسی کنید.":e.message,true);return null;}}
function userError(error){if(error instanceof SyntaxError)return "فایل یا پاسخ خوانده نشد؛ فایل JSON ذخیره‌شده از همین برنامه را انتخاب کنید.";if(error?.name==="TimeoutError"||error?.name==="AbortError")return "پاسخ برنامه دیر رسید؛ اتصال محلی را بررسی و دوباره تلاش کنید.";if(error instanceof TypeError)return "ارتباط با شبیه‌ساز برقرار نشد یا ساختار اطلاعات درست نیست؛ اجرای برنامه و فایل انتخاب‌شده را بررسی کنید.";return error.message;}
function timeText(sec){return SimUnits.formatClock(sec);}
const stateNames={stabled:"مستقر",moving:"حرکت",held:"منتظر",dwell:"توقف سکو",ready:"آماده",imported_held:"واردشده / متوقف"};
function init(){
 const turnbacks=lineData.turnbacks;
 for(const id of ["low","high","shortLow","shortHigh"])$(id).innerHTML=turnbacks.map(t=>`<option value="${t.station}">ST${t.station} — ${esc(t.name)}</option>`).join("");
 $("low").value=1;$("high").value=21;$("shortLow").value=21;$("shortHigh").value=19;
 $("turnbacks").innerHTML=turnbacks.map(t=>`<div class="candidate"><b>ST${t.station} — ${esc(t.name)}</b><small>${t.path_a_to_b.map(code).join(" ← ")}</small><span class="tag">اتصال تغییر خط در فایل وجود دارد؛ مجوز بهره‌برداری تأیید نشده</span></div>`).join("");
 const limitations=["وضعیت تازه میدان دریافت نشده است","طول ۲۴۰ مدار از ستون Length فایل logic.mhr است؛ طول مدار با طول مفید سکو یکی نیست","سرعت حرکت، محدودیت سرعت محتاطانه از حالت‌های مجاز ATP (حفاظت خودکار قطار) در اتصال انتخاب‌شده است؛ محاسبه کامل ATP میدان نیست","اتصالات حرکت از TrackLink هستند؛ نقشه پس‌زمینه شماتیک قدیمی است","کاندید قدیمی ST18 اتصال محلی A/B در این فایل ندارد و از انتخاب مسیر کوتاه حذف شده است","مجاز بودن مسیر کوتاه، شیب، چسبندگی و عملکرد ترمز واقعی تأیید نشده‌اند","cycleVal تایمر ESB برابر ۱ چرخه است؛ تأخیر تا ریل/قطار بر حسب ثانیه مشخص نیست"];
 $("limitations").innerHTML=limitations.map(x=>`<li>${esc(x)}</li>`).join("");
 $("esbStation").innerHTML=[...lineData.stations,{id:22,name:"پایانه احسان"}].map(s=>`<option value="${s.id}">ST${s.id} — ${esc(s.name)}</option>`).join("");
 $("pointName").innerHTML=Object.keys(lineData.points).map(n=>`<option>${esc(n)}</option>`).join("");
 populateSections();
 populateReserve();
 buildMap();
}
function populateSections(){
 const direction=$("trainLine").value,chain=lineData.chains[direction];
 $("trainSection").innerHTML=(direction==="A"?["T22.2.2",...chain]:chain).map(n=>`<option value="${n}">${n}${n==="T22.2.2"?" — پایانه احسان":""}</option>`).join("");
 $("trainSection").value=direction==="A"?"T21.1":"T1.2";
 if(selected&&lineData.tracks[selected]?.yard&&!lineData.graph?.[selected]?.length)$("trainSection").value='';
}
function svgEl(tag,attrs,text){const n=document.createElementNS("http://www.w3.org/2000/svg",tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,v);if(text)n.textContent=text;return n;}
function buildMap(){
 const svg=$("map"),[w,h]=lineData.layout.size;svg.setAttribute("viewBox",`0 0 ${w} ${h}`);svg.style.width=`${Math.max(1400,Math.floor(w*.3))*zoom}px`;svg.style.height=`${Math.max(1400,Math.floor(w*.3))*zoom*h/w}px`;svg.replaceChildren();
 for(const segment of lineData.layout.tracks){if(!segment.pts.length)continue;svg.append(svgEl("polyline",{points:segment.pts.map(p=>p.join(",")).join(" "),fill:"none",stroke:"#e6ba20","stroke-width":13,"stroke-opacity":0,"pointer-events":"none","vector-effect":"non-scaling-stroke","data-route-track":segment.name}));}
 for(const segment of lineData.layout.tracks){if(!segment.pts.length)continue;const rail=svgEl("polyline",{points:segment.pts.map(p=>p.join(",")).join(" "),fill:"none",stroke:"#7c8aa0","stroke-width":4,"vector-effect":"non-scaling-stroke","data-track":segment.name,tabindex:0,role:"button","aria-label":"نمایش یا بستن اطلاعات تراک "+segment.name});
 rail.append(svgEl("title",{},segment.name));rail.addEventListener("click",()=>selectTrack(segment.name));rail.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();selectTrack(segment.name);}});svg.append(rail);}
 for(const txt of lineData.layout.texts){const match=txt.cap.match(/^ST(\d+)/i);if(match||txt.cap.includes("logic only")){const logicOnly=!match;if(logicOnly&&zoom<2)continue;svg.append(svgEl("text",{x:txt.x+txt.w/2,y:txt.y+(logicOnly?16:30),"text-anchor":"middle","font-size":logicOnly?21:42,"font-weight":logicOnly?400:600,"pointer-events":"none",opacity:logicOnly?.85:1},match?`ST${match[1]}`:txt.cap));}}
 for(const p of lineData.layout.switches){svg.append(svgEl("circle",{cx:p.x+p.w/2,cy:p.y+p.h/2,r:12,fill:"#2376bb","data-point":p.name.replace(/^W/,"P")}));}
 svg.prepend(svgEl("g",{id:"shortRouteOverlay"}));svg.append(svgEl("g",{id:"plannedMarkers"}));svg.append(svgEl("g",{id:"trainMarkers"}));
}
function trackPoints(name){return (lineData.tracks[name]?.polylines||[]).flat();}
function nearestDistance(point,name){let best=Infinity;for(const q of trackPoints(name))best=Math.min(best,Math.hypot(point[0]-q[0],point[1]-q[1]));return best;}
function pathNeighbors(tr){
 let prev=tr.path_prev||(tr.sections?.length>1?tr.sections[tr.sections.length-2]:null),next=tr.path_next||null;
 // At a platform reversal both adjacent legs mention the same switch. Incoming
 // uses the previous segment; outgoing uses the next one, not both at once.
 if(prev&&prev===next){if(tr.kind==='turn'||tr.kind==='dispatch')prev=null;else next=null;}
 return [prev,next];
}
// tr.pos is metres travelled into the head circuit in the direction of travel. The
// schematic polylines are drawn in an arbitrary (mostly left-to-right) order, so the
// polyline is oriented so that it starts at the circuit the train came from and ends
// at the circuit it is heading to. Without this, direction-A trains slid backwards.
function orientedPolyline(tr,poly){
 const first=poly[0],last=poly[poly.length-1];
 const [prev,next]=pathNeighbors(tr);
 let score=0;
 if(prev&&lineData.tracks[prev])score+=nearestDistance(last,prev)-nearestDistance(first,prev);
 if(next&&lineData.tracks[next])score+=nearestDistance(first,next)-nearestDistance(last,next);
 if(!prev&&!next&&tr.line==="A")score=-1; // fallback: direction A runs right-to-left on the schematic
 return score<0?[...poly].reverse():poly;
}
// Switch circuits are drawn as several pieces (straight + crossover). Chain the pieces
// actually used between the previous and the next circuit instead of the longest one,
// so the marker does not jump when entering or leaving a point.
function travelPath(tr,geometry){
 const longest=geometry.reduce((a,b)=>a.length>b.length?a:b);
 const [prev,next]=pathNeighbors(tr);
 // The old schematic splits the Ehsan crossover across three polylines and
 // has small drafting gaps. Its route first moves away from the platform;
 // a greedy nearest-end choice takes the other diagonal and leaves a gap.
 // Use only the matching source pieces, and fall back if geometry changes.
 if(tr.head==='TP21.1'&&prev==='TP21.2'&&next==='T21.1'){
  const find=(x,y)=>geometry.find(p=>p.some(q=>q[0]===x&&q[1]===y));
  const a=find(5088,243),b=find(5124,165),c=find(4872,165);
  if(a&&b&&c){const orient=(p,x,y)=>p[0][0]===x&&p[0][1]===y?p:[...p].reverse();
   return [...orient(a,5088,243),...orient(b,5124,165),...orient(c,4896,165)];}
 }
 const hasPrev=prev&&lineData.tracks[prev],hasNext=next&&lineData.tracks[next];
 if(geometry.length<2||(!hasPrev&&!hasNext))return orientedPolyline(tr,longest);
 const d=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]),pieces=geometry.map(p=>p.slice()),used=new Set();
 let start=null;
 if(hasPrev){let best=Infinity;pieces.forEach((p,i)=>{for(const [pt,rev] of [[p[0],false],[p[p.length-1],true]]){const v=nearestDistance(pt,prev);if(v<best){best=v;start={i,rev};}}});}
 else{let best=-Infinity;pieces.forEach((p,i)=>{for(const [pt,rev] of [[p[0],true],[p[p.length-1],false]]){const v=nearestDistance(pt,next);if(v>best){best=v;start={i,rev};}}});}
 let path=start.rev?[...pieces[start.i]].reverse():[...pieces[start.i]];used.add(start.i);
 for(let guard=0;guard<pieces.length;guard++){
  const end=path[path.length-1];if(hasNext&&nearestDistance(end,next)<=6)break;
  let pick=null,score=Infinity;
  pieces.forEach((p,i)=>{if(used.has(i))return;for(const piece of [p,[...p].reverse()]){if(d(piece[0],end)>45)continue;const far=piece[piece.length-1],sc=hasNext?nearestDistance(far,next):-d(piece[0],far);if(sc<score){score=sc;pick={i,piece};}}});
  if(!pick||(hasNext&&score>=nearestDistance(end,next)))break;
  used.add(pick.i);path=path.concat(d(pick.piece[0],end)<1e-6?pick.piece.slice(1):pick.piece);
 }
 return path.length>1?path:orientedPolyline(tr,longest);
}
function positionOnTrack(tr){
 const geometry=lineData.tracks[tr.head]?.polylines||[];
 if(!geometry.length)return null;
 const poly=travelPath(tr,geometry),ratio=Math.min(1,Math.max(0,tr.pos/lineData.tracks[tr.head].length_m));
 const distances=poly.slice(1).map((p,i)=>Math.hypot(p[0]-poly[i][0],p[1]-poly[i][1])),total=distances.reduce((a,b)=>a+b,0);let wanted=ratio*total;
 if(!distances.length)return poly[0];
 for(let i=0;i<distances.length;i++){if(wanted<=distances[i]||i===distances.length-1){const f=distances[i]?Math.min(1,wanted/distances[i]):0;return [poly[i][0]+(poly[i+1][0]-poly[i][0])*f,poly[i][1]+(poly[i+1][1]-poly[i][1])*f];}wanted-=distances[i];}
 return poly[0];
}
// Display the body centre rather than the leading end. When a driver changes
// ends at a platform, the marker therefore stays at the same physical place.
function positionTrainCenter(tr){
 const parts=tr.sections?.length?tr.sections:[tr.head];let i=parts.length-1;
 let pos=Number(tr.pos)-Number(state?.config?.train_length_m||100)/2;
 while(pos<0&&i>0){i--;pos+=lineData.tracks[parts[i]].length_m;}
 if(pos<0)return positionOnTrack(tr);
 if(i===parts.length-1)return positionOnTrack({...tr,pos});
 const route=tr.body_route||[], headIndex=route.lastIndexOf(tr.head), bodyIndex=headIndex-(parts.length-1-i);
 const prev=bodyIndex>0?route[bodyIndex-1]:(i>0?parts[i-1]:null),next=parts[i+1];
 return positionOnTrack({head:parts[i],pos,line:tr.line,kind:tr.kind,path_prev:prev,path_next:next});
}
function renderMap(){
 const focused=state.trains.find(t=>t.id===mapFocusTrain&&t.short_loop&&t.short_route_paths)||state.trains.find(t=>t.short_loop&&t.short_route_paths);
 const finishedFocus=mapFocusTrain&&state.events.some(e=>e.kind==='SHORT_FINISH'&&e.train===mapFocusTrain);
 const routeTracks=new Set(focused||finishedFocus?[]:(state.active_route?.tracks||[]));
 document.querySelectorAll("[data-route-track]").forEach(el=>el.setAttribute("stroke-opacity",routeTracks.has(el.dataset.routeTrack)?"0.72":"0"));
 const overlay=$("shortRouteOverlay");if(overlay){overlay.replaceChildren();if(focused){
  const paths=focused.short_route_paths;
  paths.forEach((nodes,k)=>nodes.forEach((name,i)=>{const prev=nodes[i-1]||(k?paths[k-1].at(-2):null),next=nodes[i+1]||(k+1<paths.length?paths[k+1][1]:null),geometry=lineData.tracks[name]?.polylines||[];if(!geometry.length)return;
   const points=travelPath({head:name,path_prev:prev,path_next:next,line:k===0?'A':'B'},geometry);
   overlay.append(svgEl("polyline",{points:points.map(p=>p.join(",")).join(" "),fill:"none",stroke:"#e6ba20","stroke-width":13,"stroke-opacity":.72,"pointer-events":"none","vector-effect":"non-scaling-stroke","data-short-piece":name}));
  }));}}

 document.querySelectorAll("[data-track]").forEach(el=>{const n=el.getAttribute("data-track");el.setAttribute("stroke",state.closed.includes(n)?"var(--map-closed)":state.occupied[n]?"var(--red)":(state.reserved[n]||(state.terminal?.owner&&n!=="T21.1"&&[...lineData.yard_inbound,...lineData.yard_outbound].includes(n)))?"#c17a26":n===selected?"#3b8cff":"#7c8aa0");el.setAttribute("stroke-dasharray",state.closed.includes(n)?"8 5":"none");el.setAttribute("aria-pressed",String(n===selected));});
 document.querySelectorAll("[data-point]").forEach(el=>{const p=state.points[el.getAttribute("data-point")];if(p)el.setAttribute("fill",p.fault?"#b54236":p.position!==p.target?"#c17a26":"#2376bb");});
 const group=$("trainMarkers");group.replaceChildren();
 const factor=lineData.layout.size[0]/parseFloat($("map").style.width);
 for(const tr of state.trains){const p=positionTrainCenter(tr);if(!p)continue;const label=String(tr.label||tr.id),wide=Math.max(26,Math.min(220,Array.from(label).length*8+18))*factor;const marker=svgEl("g",{"data-train":tr.id});marker.append(svgEl("rect",{x:p[0]-wide/2,y:p[1]-13*factor,width:wide,height:26*factor,rx:13*factor,fill:state.active_route&&tr.low===state.active_route.low&&tr.high===state.active_route.high?"#a87805":"#2376bb",stroke:"#fff","stroke-width":2*factor}));const text=svgEl("text",{x:p[0],y:p[1]+4*factor,"font-size":12*factor,fill:"white","text-anchor":"middle",direction:"auto","unicode-bidi":"plaintext"},label);if(Array.from(label).length*8+18>220){text.setAttribute("textLength",String(wide-16*factor));text.setAttribute("lengthAdjust","spacingAndGlyphs");}marker.append(text);marker.append(svgEl("title",{},`${tr.label}: ${tr.head} — ${tr.speed_kmh} km/h`));group.append(marker);}
 renderPlannedMarkers();
 if(selected){const r=lineData.tracks[selected],poly=r?.polylines?.[0];if(poly?.length){const p=poly[Math.floor(poly.length/2)];group.append(svgEl("text",{x:p[0],y:p[1]-20*factor,"font-size":14*factor,fill:"#7fb2ff","font-weight":700,"text-anchor":"middle"},selected));}}
}
function selectTrack(n,toggle=true){if(!lineData.tracks[n])return;selected=toggle&&selected===n?null:n;
 $("addSelected").disabled=!selected;
 if(selected){const direction=selected==='T22.2.2'||lineData.chains.A.includes(selected)?"A":lineData.chains.B.includes(selected)?"B":null;if(direction){$("trainLine").value=direction;populateSections();$("trainSection").value=selected;}else{$("trainSection").value='';}}
 renderTrackInfo();if(state)renderMap();}
function renderTrackInfo(){
 if(!selected||!state){setText($("trackInfo"),"روی یک تراک کلیک کنید تا اطلاعات آن نمایش داده شود؛ کلیک دوباره انتخاب را لغو می‌کند.");return;}const r=lineData.tracks[selected],owner=state.occupied[selected],closed=state.closed.includes(selected);
 const yardMissing=r?.yard&&!lineData.graph?.[selected]?.length;
 if(!setHTML($("trackInfo"),`<h3 dir="ltr">${esc(selected)}</h3>${yardMissing?'<p class="service-error">اتصال خروج و سرعت این تراک در داده موجود نیست؛ برای جلوگیری از انتقال اشتباه، تعریف قطار و محاسبه حرکت در آن انجام نمی‌شود.</p>':''}<p>${r.length_configured?"طول مدار از logic.mhr":r.length_verified?"طول اعلام‌شده توسط کاربر":"طول واردشده برای آزمایش"}: ${fmt(r.length_m)} m<br>${r.speed_mode==="user_override"?"سرعت واردشده برای آزمایش":"حدود سرعت بیشتر از صفر در سامانه حفاظت قطار (ATP)"}: ${speedText(r)} km/h<br>وضعیت: ${closed?"مسدود":owner?"زیر بدنه قطار "+owner:state.reserved[selected]?"رزروشده برای قطار "+state.reserved[selected]:"آزاد"}<br>منبع طول: ${esc(sourceText(r.length_source))}<br>تأیید مستقل میدان: ${r.length_verified&&r.speed_verified?"تأییدشده توسط کاربر؛ بدون بررسی مستقل":"انجام نشده"}</p><button class="${closed?"secondary":"danger"}" id="toggleClosure">${closed?"رفع انسداد":"مسدود کردن قطعه"}</button>`)){}
 $("toggleClosure").onclick=async()=>{if(await action({op:"close",section:selected,value:!closed}))toast(closed?"انسداد تراک برداشته شد؛ اگر قطار یا رزرو مسیر وجود داشته باشد، تراک همچنان درگیر می‌ماند.":"تراک برای سناریوی آزمایشی مسدود شد.");};
}
const legNames={run:"حرکت بین دو پایانه",receive:"ورود به مسیر مانور احسان",dispatch:"بازگشت به سکوی خروج احسان",turn:"گردش و تغییر جهت"};
const eventNames={SHORT_TURN:'رسیدن به ایستگاه گردش',PLAN_SEED:"انتقال قطارهای برنامه‌ای",SHORT_STATION:"توقف مسیر کوتاه در مدل",SHORT_MISSED:"اعزام زمان‌دار انجام نشد",SHORT_DEPART:"اعزام گردش کوتاه",SHORT_FINISH:"پایان گردش کوتاه",SHORT_CLOCK:"ساعت مرجع مدل",SHORT_LOOP:"گردش کوتاه قطار اصلی",SHORT_RETURN:"بازگشت به سرویس اصلی",START:"شروع مدل",TRAIN:"تعریف قطار",REMOVE:"حذف قطار",RESET:"بازنشانی خط",IMPORT:"بارگذاری وضعیت",CONFIG:"تغییر تنظیمات",PLAN:"تغییر برنامه",TRACK:"ویرایش تراک",CLOSURE:"انسداد مسیر",ESB:"توقف اضطراری ایستگاه",EMERGENCY:"توقف فوری مدل",POINT:"تغییر سوزن",POINT_FAULT:"خرابی سوزن",SCHEDULE:"اعزام خودکار",SCHEDULE_CONFLICT:"توقف اعزام به دلیل تداخل",TERMINAL_POLICY:"تنظیمات پایانه",TERMINAL_OVERRUN:"تأخیر در گردش پایانه",TERMINAL_LOCK:"رزرو مسیر مانور احسان",TERMINAL_RELEASE:"آزادشدن مسیر مانور احسان",BERTH:"توقف در ایستگاه",DATA:"تغییر داده مسیر",ERROR:"خطای مدل",SAFETY:"توقف حفاظتی مدل",TURN:"تغییر جهت قطار"};
function renderTrains(){
 $("fleetSummary").textContent=`${fmt(state.counts.total)} شناسه، ${fmt(state.counts.occupied_sections)} مدار اشغال`;
 if(!setHTML($("trains"),state.trains.length?state.trains.map(t=>`<tr><td>${esc(t.label)}<br><small>#${t.id}${t.short_loop?` · گردش کوتاه ST${t.low} ↔ ST${t.high}`:""}</small></td><td>${t.line} / ${esc(legNames[t.kind]||t.kind)}</td><td>${code(t.head)}</td><td>${t.sections.map(code).join("، ")}</td><td>${fmt(t.speed_kmh)}<br><small>سقف فعلی مدل: ${fmt(t.limit_kmh)}</small></td><td>${esc(stateNames[t.state]||t.state)}<br><small>${esc(t.reason)}</small></td><td><button class="secondary hold" data-id="${t.id}" data-value="${!t.hold}">${t.hold?"اجازه ادامه حرکت":"توقف دستی"}</button> <button class="secondary remove" data-id="${t.id}">حذف</button></td></tr>`).join(""):`<tr><td colspan="7">مدل خالی است؛ شمار قطار واقعی میدان در این مدل معلوم نیست.</td></tr>`))return;
 document.querySelectorAll(".hold").forEach(b=>b.onclick=()=>action({op:"hold",id:Number(b.dataset.id),value:b.dataset.value==="true"}));
 document.querySelectorAll(".remove").forEach(b=>b.onclick=()=>{if(confirm("این قطار از شبیه‌ساز حذف شود؟ این کار قابل بازگشت نیست."))action({op:"remove",id:Number(b.dataset.id)});});
}
function bottleneckText(value){const v=String(value);if(v.startsWith("ehsan:"))return "چرخه مانور پایانه احسان و زمان آزادسازی مسیر";if(v.startsWith("dispatch:"))return "بازگشت از پایانه احسان به سکوی خروج، تراک "+v.slice(9);return "محدودیت مسیر "+v;}
function sourceText(value){const s=String(value||"");if(s.includes("[Track].Length"))return "طول مدار ثبت‌شده در فایل logic.mhr";if(s.includes("ATPSeq")||s.includes("positive_route_envelope"))return "حدود سرعت مسیر از منطق ATP فایل logic.mhr";if(s.includes("legacy_station_speed_table"))return "جدول قدیمی سرعت؛ نیازمند بررسی";return s.includes("user")?"مقدار واردشده توسط کاربر":s;}
function renderCapacity(){
 const c=state.capacity,t=c.timetable;
 $("capacity").innerHTML=t.scope_matches?`<b>ناوگان بر اساس برنامهٔ زمانی — نه ظرفیت فیزیکی خط</b><br>منبع زمان‌ها: ${t.source==="legacy_reference_unverified"?"مرجع قدیمی؛ تأیید میدان ندارد":"سناریوی واردشده توسط کاربر؛ تأیید میدان ندارد"}<br>جهت A: ${code(timeText(t.run_a_s))}؛ جهت B: ${code(timeText(t.run_b_s))}<br>زمان کامل گردش پایانه دیگر: ${code(timeText(state.config.turn_s))}؛ احسان B تا A: ${code(timeText(state.config.ehsan_turn_s))}<br>زمان گردش برنامه: ${code(timeText(t.cycle_s))} (ساعت:دقیقه:ثانیه)<br>هدوی برنامه: ${SimUnits.formatMinutes(t.headway_s)} دقیقه<br>قطار در سرویس: <strong id="plannedActive">${fmt(t.active_trains)} قطار</strong><br>ذخیره: ${fmt(t.reserve)} قطار<br>جمع با ذخیره: <strong id="plannedTotal">${fmt(t.total_trains)} قطار</strong><br><small>ذخیره در محاسبهٔ هدوی وارد نمی‌شود. زمان برنامه، منحنی حرکت و طول تراک‌ها را با واقعیت تطبیق نمی‌دهد.</small>`:`<b>برای این سرویس زمان رفت‌وبرگشت وارد نشده است</b><br>زمان‌های برنامهٔ قبلی به مسیر کوتاه تعمیم داده نمی‌شوند؛ زمان هر جهتِ همین سرویس را وارد و اعمال کنید.`;
 $("kinematicDiagnostic").innerHTML=`زمان تخمینی رفت‌وبرگشت با گردش دو پایانه، بر اساس طول و محدودیت سرعت فایل: ${code(timeText(c.cycle_s))}<br>کمترین فاصله اعزام مجاز در مدل حرکتی: ${SimUnits.formatMinutes(c.planning_bound_s)} دقیقه؛ ${esc(bottleneckText(c.bottleneck))} <small>(${code(c.bottleneck)})</small><br>${c.feasible_in_planner?"فاصله اعزام از حد اولیه مدل کمتر نیست؛ محدودیت‌های دیگر نیز باید رعایت شوند":"فاصله اعزام واردشده کوتاه است؛ اعزام خودکار اجرا نمی‌شود. تغییر جدول زمانی به‌تنهایی این مشکل را رفع نمی‌کند"}<br><small>${fmt(c.configured_lengths)} از ${fmt(c.service_track_count)} طول سرویس از logic.mhr و ${fmt(c.configured_speeds)} مجموعه حدود سرعت از ATP آمده‌اند؛ این‌ها تأیید مستقل میدان نیستند. حد بالا فقط محدودیت محاسباتی مدل است، نه ظرفیت واقعی میدان. طول مسیر انتخاب‌شده در داده پیکربندی: A برابر ${fmt(c.route_length_m.A/1000)} و B برابر ${fmt(c.route_length_m.B/1000)} کیلومتر؛ برای رسیدن به عدد ۲۴٫۵ طول‌ها دستکاری نشده‌اند.</small>`;
}
const parameterLabels={train_length_m:"طول قطار m",acceleration:"شتاب m/s²",service_brake:"ترمز سرویس m/s²",emergency_brake:"پارامتر مرجع ترمز اضطراری m/s²",reaction_s:"زمان واکنش (ثانیه)",margin_m:"حاشیه توقف m",dwell_s:"توقف میانی (ثانیه)",turn_s:"گردش کامل پایانه دیگر (ثانیه)",ehsan_turn_s:"گردش احسان B تا A، حداقل ۴۲۰ ثانیه",point_throw_s:"زمان سوزن (ثانیه)",headway_s:"فاصله اعزام قطارها / هدوی (دقیقه)",release_s:"آزادسازی مدار (ثانیه)",shunt_kmh:"سرعت شانت km/h"};
function renderParameters(){
 if(renderedData)return;renderedData=true;
 $("parameters").innerHTML=Object.entries(state.config).map(([k,v])=>{const displayed=SimUnits.parameterDisplay(k,v);return `<label>${esc(parameterLabels[k])}<input data-param="${k}" data-raw="${v}" data-display="${displayed}" type="number" step="any" value="${displayed}"></label>`;}).join("");
 $("headway").value=SimUnits.secondsToMinutes(state.config.headway_s);
 const t=state.capacity.timetable;
 $("runA").value=t.scope_matches?t.run_a_s:"";$("runB").value=t.scope_matches?t.run_b_s:"";$("reserveFleet").value=t.reserve;
}
function renderTrackTable(){
 const q=$("searchTrack").value.trim().toUpperCase();const rows=Object.values(lineData.tracks).filter(t=>!q||t.id.includes(q)||String(t.station)===q);
 $("coverage").textContent=`${fmt(rows.length)} قطعه؛ ${fmt(Object.values(lineData.tracks).filter(x=>x.length_configured).length)} طول از logic.mhr، ${fmt(Object.values(lineData.tracks).filter(x=>x.speed_configured).length)} تراک با حد سرعت بیشتر از صفر در فایل ATP. سرعت‌های جدول حالت‌های مثبت پیکربندی‌اند، نه مجوز دائمی حرکت. صفرهای حالت توقف، سقف ثابت تراک نیستند. ابعاد شماتیک و کالیبراسیون ۲۴٫۵ کیلومتری دیگر مبنای طول نیستند. طول مفید سکو و زمان اثر ESB در میدان جداگانه نیازمند سند هستند.`;
 $("trackTable").innerHTML=rows.map(t=>`<tr><td>${code(t.id)}</td><td>${t.station}</td><td>${fmt(t.length_m)}</td><td>${speedText(t)}</td><td>${esc(sourceText(t.length_source))}<br>${esc(sourceText(t.speed_source))}<br><small>${t.length_configured?"استخراج از فایل؛ تأیید مستقل میدان نشده":"مقدار سناریو / کاربر"}</small></td><td><button class="secondary edit" data-track="${t.id}">ویرایش</button></td></tr>`).join("");
 document.querySelectorAll(".edit").forEach(b=>b.onclick=async()=>{const n=b.dataset.track,t=lineData.tracks[n];const len=prompt("طول واقعی یا مقدار سناریو (m):",t.length_m),speed=prompt("سرعت واردشده برای آزمایش (km/h)؛ جایگزین حدود سرعت سامانه حفاظت قطار می‌شود:",t.speed_kmh??10);if(len===null||speed===null)return;const verified=confirm("آیا این دو مقدار با سند مهندسی/داده میدان تطبیق داده شده‌اند؟ این تأیید کاربر است، نه گواهی ایمنی.");if(await action({op:"track",section:n,length_m:Number(len),speed_kmh:Number(speed),verified})){lineData=await(await fetch("/api/line")).json();renderTrackTable();renderTrackInfo();}});
}
function render(){
 $("total").textContent=fmt(state.counts.total);$("onLine").textContent=fmt(state.counts.on_line);$("yard").textContent=fmt(state.counts.yard_only);$("clock").textContent=timeText(state.clock);
 $("connection").textContent=`مدل محلی ${state.running?"در حال اجرا":"متوقف"} · ${state.scale}×`;$("connectionPill").dataset.state=state.running?"running":"paused";if($("scale").value!==String(state.scale)&&document.activeElement!==$("scale"))$("scale").value=String(state.scale);
 $("modelState").textContent=state.origin==="new_empty_model_not_live_field"?"سناریوی تعریف‌شده؛ نه شمار میدان":`وضعیت واردشده: ${state.imported_at?"\u2066"+state.imported_at.replace("T"," ")+"\u2069":"زمان نامشخص"}؛ نه زنده`;
 renderMap();renderTrackInfo();renderTrains();renderCapacity();renderParameters();renderDispatchStatus();renderShortControls();
 const terminal=state.terminal,owner=state.trains.find(t=>t.id===terminal?.owner);
 $("terminalStatus").textContent=terminal?.owner?`مسیر مانور احسان در اختیار: ${owner?.label||terminal.owner}؛ زمان باقی‌مانده از گردش تعیین‌شده: ${timeText(Math.max(0,terminal.ready_at-state.clock))}؛ ${terminal.overrun?"گردش قطار دیر شده است؛ تا بازگشت قطار و خالی‌شدن مسیر، قطار بعدی اجازه ورود ندارد":"قطار بعدی باید تا بازگشت این قطار به سکوی خروج (A) و خالی‌شدن مسیر منتظر بماند"}`:`شانت احسان: ${terminal?.clear_after>state.clock?"در انتظار زمان آزادسازی":"آزاد؛ در اختیار قطاری نیست"}؛ چرخه حداقل ${timeText(state.config.ehsan_turn_s)} از B تا A است. ${state.scheduler.blocked_reason||""}`;
 const p=state.points[$("pointName").value];$("pointStatus").textContent=p?`وضعیت فعلی سوزن: ${p.position==="N"?"عادی (N)":"معکوس (R)"}؛ حالت درخواستی: ${p.target==="N"?"عادی (N)":"معکوس (R)"}؛ ${p.fault?"خراب":p.owner?"قفل قطار "+p.owner:"آزاد"}`:"";
 const v=80/3.6,c=state.config;$("braking").textContent=`مثال مدل در ۸۰ km/h: فاصله واکنش و ترمز سرویس و حاشیه = ${fmt(v*c.reaction_s+v*v/(2*c.service_brake)+c.margin_m)} متر. شیب و چسبندگی در این محاسبه لحاظ نشده‌اند.`;
 const lastStation=[...state.events].reverse().find(e=>e.kind==='SHORT_STATION');$('shortLastStation').textContent=lastStation?lastStation.message:'هنوز توقفی در مسیر کوتاه ثبت نشده است.';
 setHTML($("eventList"),[...state.events].reverse().map(e=>`<div><code>${timeText(e.time)}</code> <span class="tag">${esc(eventNames[e.kind]||e.kind)}</span> ${esc(e.message)}</div>`).join("")||"<p>هنوز رخدادی ثبت نشده است.</p>");
 window.ServiceClockUI?.syncStats();

}
async function poll(){
 if(busy||shortBusy)return;busy=true;
 try{const r=await fetch("/api/state",{signal:AbortSignal.timeout(7000)});if(!r.ok)throw Error("HTTP "+r.status);state=await r.json();render();}
 catch(e){$("connectionPill").dataset.state="error";$("connection").textContent=shortBusy?"در حال بررسی گردش کوتاه؛ وضعیت مدل ثابت نگه داشته شده":"ارتباط وب محلی قطع است؛ تلاش مجدد";}finally{busy=false;}
}
function activateTab(b,focus=false){document.querySelectorAll("[data-tab]").forEach(x=>{const on=x===b;x.classList.toggle("active",on);x.setAttribute("aria-selected",String(on));x.tabIndex=on?0:-1;});document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.id===b.dataset.tab));if(focus)b.focus();try{history.replaceState(null,"","#"+b.dataset.tab);}catch(e){}}
document.querySelectorAll("[data-tab]").forEach(b=>{b.onclick=()=>activateTab(b);b.onkeydown=e=>{const tabs=[...document.querySelectorAll("[data-tab]")],i=tabs.indexOf(b);let n=null;if(e.key==="ArrowLeft")n=tabs[(i+1)%tabs.length];else if(e.key==="ArrowRight")n=tabs[(i-1+tabs.length)%tabs.length];else if(e.key==="Home")n=tabs[0];else if(e.key==="End")n=tabs[tabs.length-1];if(n){e.preventDefault();n.click();n.focus();}};});
{const saved=location.hash.slice(1);const tab=saved==="service"?"planning":saved;const initial=tab&&document.querySelector(`[data-tab="${CSS.escape(tab)}"]`);if(initial)activateTab(initial);}
$("themeToggle").onclick=()=>{const root=document.documentElement,dark=root.dataset.theme?root.dataset.theme==="dark":matchMedia("(prefers-color-scheme: dark)").matches,next=dark?"light":"dark";root.dataset.theme=next;try{localStorage.setItem("shiraz-theme",next);}catch(e){}};
$("resetLine").onclick=async()=>{
 if(!confirm("خط شبیه‌ساز بازنشانی شود؟\nهمه قطارها حذف می‌شوند؛ حرکت و اعزام خودکار متوقف می‌شوند. ساعت و رخدادهای مدل صفر، انسدادها و ESB خاموش، خرابی و قفل سوزن‌ها پاک می‌شوند و سوزن‌ها به حالت N برمی‌گردند.\nطول و سرعت تراک‌ها، تنظیمات و برنامه زمانی حفظ می‌شوند. این کار قابل بازگشت نیست."))return;
 const result=await action({op:"reset_line",confirm:true});
 if(result){mapPlanned=null;$("mapClockVehicles").replaceChildren();$("mapClockReport").textContent="نشان‌های برنامه‌ای پنهان شدند؛ نمایش دوباره از برنامه زمانی، قطار مدل نمی‌سازد.";$("addSelected").disabled=true;$("routeReport").textContent="خط بازنشانی شد؛ برای شروع سرویس، مسیر و هدوی را دوباره بررسی کنید.";selected=null;zoom=1;$("scale").value="1";buildMap();render();toast("خط بازنشانی شد؛ "+fmt(result.removed_trains)+" قطار حذف شد. برای اجرای سناریوی تازه، قطار تعریف کنید.");}
};
$("run").onclick=()=>action({op:"run"});$("pause").onclick=()=>action({op:"pause"});$("scale").onchange=()=>action({op:"scale",value:Number($("scale").value)});
$("emergency").onclick=()=>action({op:"emergency",value:true});$("resetStop").onclick=()=>action({op:"emergency",value:false});
$("zoomIn").onclick=()=>{zoom=Math.min(4,zoom+.25);buildMap();renderMap();};$("zoomOut").onclick=()=>{zoom=Math.max(1,zoom-.25);buildMap();renderMap();};
$("viewEhsan").onclick=()=>{zoom=2;buildMap();renderMap();$("mapwrap").scrollLeft=$("mapwrap").scrollWidth;$("mapwrap").scrollTop=0;selectTrack("T22.2.2",false);};
$("trainLine").onchange=populateSections;
$("addTrain").onclick=async()=>{if(!$("trainSection").value){toast("برای تراک انتخاب‌شده مسیر معتبر تعریف نشده است؛ قطار به سکوی دیگری منتقل نمی‌شود.",true);return;}const result=await action({op:"add",section:$("trainSection").value,line:$("trainLine").value,label:$("trainLabel").value||null,low:state.profile.low,high:state.profile.high});if(result)toast("یک قطار با شناسه "+result.id+" تعریف شد");};
$("definePair").onclick=async()=>{const l=$("trainLine").value,secs=l==="B"?["T21.2.1","T21.2"]:["T21.1","T21.1.1"];if(confirm("یک قطار با بدنه روی هر دو تراک تعریف شود؟ هر دو قطعه باید آزاد باشند."))await action({op:"add",line:l,section:secs[1],sections:secs,label:$("trainLabel").value||null,low:1,high:21});};
$("applyPlan").onclick=async()=>{try{const timing={run_a_s:SimUnits.parameterValue("run_a_s",$("runA").value,"",0),run_b_s:SimUnits.parameterValue("run_b_s",$("runB").value,"",0),reserve:SimUnits.parameterValue("reserve",$("reserveFleet").value,"",0)};if(await action({op:"plan",headway_s:SimUnits.minutesToSeconds($("headway").value),low:Number($("low").value),high:Number($("high").value),timetable:timing})){renderedData=false;await poll();}}catch(e){toast(userError(e),true);}};
function routeInput(op){return {op,low:Number($("low").value),high:Number($("high").value),headway_s:SimUnits.minutesToSeconds($("headway").value),limit:Number($("fleetLimit").value)};}
let routeRequest=0;
function showRouteReport(r){
 $("routeReport").innerHTML=`<b>${r.valid?"بررسی اولیه مدل پذیرفته شد — نه تأیید ایمنی میدان":"شروع سرویس ممکن نیست"}</b>`+(r.cycle_s?`<br>طول جهت A: ${fmt(r.route_length_m.A)} متر؛ B: ${fmt(r.route_length_m.B)} متر<br>زمان تخمینی A: ${code(timeText(r.run_a_s))}؛ B: ${code(timeText(r.run_b_s))}<br>چرخه با گردش پایانه‌ها: ${code(timeText(r.cycle_s))}<br>حداقل هدوی برآورد مدل: ${SimUnits.formatMinutes(r.minimum_headway_s)} دقیقه؛ ناوگان موردنیاز: ${fmt(r.required_fleet)} قطار`:"")+(r.errors?.length?`<ul>${r.errors.map(e=>`<li>${esc(e)}</li>`).join("")}</ul>`:"")+(r.started?`<br>سرویس آغاز شد؛ قطار ${fmt(r.train_id)} روی نقشه است. ساعت مدل در حال اجراست.`:"");
}
async function routeCheck(start=false){
 const request=++routeRequest;$("autoStart").disabled=true;
 try{
  const input=routeInput(start?"route_start":"route_preview");
  const response=await fetch("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(input)});
  const result=await response.json();if(!result.ok)throw Error(result.error);
  if(request!==routeRequest)return;
  const r=result.route;showRouteReport(r);
  if(start&&r.started){state=await(await fetch("/api/state")).json();render();document.querySelector('[data-tab="operations"]').click();focusRoute(r.train_id);toast("حرکت سرویس شروع شد؛ مسیر زرد است و محل قطار روی نقشه نمایش داده می‌شود.");}
  else if(start)toast(r.errors.join("؛ "),true);
 }catch(e){if(request===routeRequest)$("routeReport").textContent=userError(e);}
 finally{if(request===routeRequest)$("autoStart").disabled=false;}
}
for(const id of ["low","high","headway","fleetLimit"])$(id).onchange=()=>routeCheck();
$("routePreview").onclick=()=>routeCheck();
$("autoStart").onclick=()=>routeCheck(true);
$("autoStop").onclick=async()=>{if(await action({op:"schedule",value:false}))toast("اعزام قطار جدید متوقف شد؛ قطارهای موجود به حرکت ادامه می‌دهند.");};
function renderDispatchStatus(){
 const r=state.active_route,s=state.scheduler;
 const shortCount=state.trains.filter(t=>t.short_loop).length;
 let text="اعزام خودکار سرویس مستقل فعال نیست.";
 if(r){const count=state.trains.filter(t=>(t.dispatch_profile||t).low===r.low&&(t.dispatch_profile||t).high===r.high).length;
 text=`سرویس ST${r.high} ↔ ST${r.low}؛ ${state.running?"زمان مدل در حال اجرا":"زمان مدل متوقف"}؛ ${s.enabled?"اعزام خودکار روشن":"اعزام جدید خاموش"}؛ قطارهای فعلی این سرویس: ${fmt(count)} از ${fmt(s.limit)}؛ قطارهای ساخته‌شده این نوبت: ${fmt(s.issued)}. `;
 text+=s.blocked_reason?"علت توقف: "+s.blocked_reason:s.enabled&&count<s.limit?"موعد اعزام بعدی در ساعت مدل: "+timeText(s.next):"قطارهای همین سرویس با حفظ شناسه رفت‌وبرگشت می‌کنند.";
 text+=" گردش کوتاه فعال: "+fmt(state.trains.filter(t=>t.short_loop).length)+" قطار. زرد فقط مسیر سرویس انتخاب‌شده است؛ قرمز اشغال واقعی مدل و نارنجی رزرو مسیر را نشان می‌دهد.";}
 else if(s.enabled)text="اعزام خودکار قدیمی روشن است؛ برای شروع قابل مشاهده، از دکمه بررسی و شروع حرکت استفاده کنید.";
 if(!r&&shortCount)text=`گردش کوتاه روی ${fmt(shortCount)} قطار موجود فعال است؛ ${state.running?'زمان مدل در حال اجرا':'زمان مدل متوقف'}. زرد مسیر گردش کوتاه است؛ قرمز اشغال بدنه و نارنجی رزرو را نشان می‌دهد. برای حرکت از «شروع / ادامه» استفاده کنید.`;
 for(const id of ["dispatchStatusMap","dispatchStatusPlan"])$(id).textContent=text;
}
function focusRoute(id){
 if(id){mapFocusTrain=id;renderMap();}
 const r=state.active_route,tr=state.trains.find(t=>t.id===id)||state.trains.find(t=>r&&t.low===r.low&&t.high===r.high);
 if(!tr){toast("قطاری از سرویس انتخاب‌شده روی نقشه وجود ندارد.",true);return;}
 const p=positionTrainCenter(tr);if(!p){toast("هندسه این تراک در نقشه شماتیک موجود نیست؛ محل قطار در فهرست قطارها نمایش داده می‌شود.",true);return;}
 const map=$("map"),wrap=$("mapwrap"),[w,h]=lineData.layout.size;
 wrap.scrollLeft=p[0]/w*parseFloat(map.style.width)-wrap.clientWidth/2;
 wrap.scrollTop=p[1]/h*parseFloat(map.style.height)-wrap.clientHeight/2;
 wrap.scrollIntoView({block:"center"});
}
$("focusRoute").onclick=()=>focusRoute();
$("saveParameters").onclick=async()=>{try{const values={};document.querySelectorAll("[data-param]").forEach(x=>values[x.dataset.param]=SimUnits.parameterValue(x.dataset.param,x.value,x.dataset.display,x.dataset.raw));if(await action({op:"config",values})){renderedData=false;await poll();}}catch(e){toast(userError(e),true);}};
$("setEsb").onclick=()=>action({op:"esb",station:Number($("esbStation").value),value:true});$("clearEsb").onclick=()=>action({op:"esb",station:Number($("esbStation").value),value:false});
$("pointName").onchange=()=>render();$("pointN").onclick=()=>action({op:"point",point:$("pointName").value,position:"N"});$("pointR").onclick=()=>action({op:"point",point:$("pointName").value,position:"R"});$("pointFail").onclick=()=>action({op:"point_fault",point:$("pointName").value,value:true});$("pointRestore").onclick=()=>action({op:"point_fault",point:$("pointName").value,value:false});
$("searchTrack").oninput=renderTrackTable;
$("export").onclick=async()=>{try{const r=await fetch("/api/export",{signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error("خروجی وضعیت از برنامه دریافت نشد (HTTP "+r.status+").");const obj=await r.json(),url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:"application/json"})),a=document.createElement("a");a.href=url;a.download="shiraz-scenario.json";document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);toast("فایل وضعیت ذخیره شد.");}catch(e){toast(userError(e),true);}};
$("import").onchange=async()=>{const f=$("import").files[0];if(!f)return;try{if(f.size>1048576)throw Error("حجم فایل نباید بیشتر از ۱ مگابایت باشد.");if(await action({op:"import",scenario:JSON.parse(await f.text())})){lineData=await(await fetch("/api/line")).json();renderedData=false;$("low").value=state.profile.low;$("high").value=state.profile.high;renderTrackTable();buildMap();renderMap();toast("وضعیت با موفقیت بارگذاری شد؛ همهٔ قطارها متوقف نگه داشته شده‌اند.");}}catch(e){toast(userError(e),true);}finally{$("import").value="";}};

$("addSelected").onclick=async()=>{
 if(!selected)return;const n=selected;
 const result=await action({op:"map_add",section:n,line:$("trainLine").value,label:$("trainLabel").value||null,low:state.profile.low,high:state.profile.high});
 if(result){state=await(await fetch("/api/state")).json();render();toast("قطار "+fmt(result.id)+" روی تراک "+n+" تعریف شد؛ بدنه فقط در قطعات آزاد قرار گرفت.");focusRoute(result.id);}
};
let shortReady=false,shortCheckedKey=null;const notifiedMissed=new Set();
function shortKey(){return [$('shortTrain').value,$('shortLow').value,$('shortHigh').value,$('shortOrigin').value,$('shortDeparture').value,$('shortReserveLine').value,$('shortReserveSection').value,$('shortModelOnly').checked,JSON.stringify(shortPlan()),state?.config.headway_s,state?.clock_reference?.datetime,state?.clock_reference?.clock].join(':');}
function modelCivil(){const ref=state?.clock_reference;if(!ref)return null;const ms=Date.parse(ref.datetime+'Z')+(state.clock-ref.clock)*1000;return Number.isFinite(ms)?new Date(ms).toISOString().slice(0,19):null;}
function shortPlan(){try{return window.ServiceClockUI?.getPlan()||null;}catch(e){return null;}}
async function autoShortClock(){if(state.clock_reference)return true;const ref=window.ServiceClockUI?.tehran();if(!ref)throw Error('ساعت رایانه قابل خواندن نیست.');const result=await action({op:'short_clock_set',datetime:ref});if(!result)throw Error('تنظیم خودکار ساعت مدل انجام نشد.');state=await(await fetch('/api/state')).json();return true;}
function populateReserve(){const line=$('shortReserveLine').value,el=$('shortReserveSection'),old=el.value;el.innerHTML=(line==='A'?['T22.2.2',...lineData.chains[line]]:lineData.chains[line]).map(n=>`<option value="${esc(n)}">${esc(n)}${n==='T22.2.2'?' — پایانه احسان':''}</option>`).join('');if([...el.options].some(o=>o.value===old))el.value=old;else el.value=line==='A'?'T22.2.2':'T1.2';}
function renderShortControls(){
 const input=$('shortTrain'),old=input.value,hadTrains=[...input.options].some(o=>o.value!=='reserve'),options=state.trains.map(t=>`<option value="${t.id}">${esc(t.label)} ${t.short_loop?'(گردش کوتاه)':'(سرویس اصلی)'}</option>`).join('')+'<option value="reserve">قطار جدید از ذخیره</option>';
 if(input.innerHTML!==options){input.innerHTML=options;if([...input.options].some(o=>o.value===old)&&!(old==='reserve'&&!hadTrains&&state.trains.length))input.value=old;}
 const reserve=input.value==='reserve',current=state.trains.find(t=>String(t.id)===input.value);$('shortReserveFields').hidden=!reserve;$('shortMainHeadway').textContent=SimUnits.formatMinutes(state.config.headway_s)+' دقیقه';
 const first=$('shortLow').selectedOptions[0]?.textContent||'—',second=$('shortHigh').selectedOptions[0]?.textContent||'—';$('shortOrigin').options[0].textContent=first;
 $('shortRouteText').textContent=$('shortLow').value===$('shortHigh').value?'دو ایستگاه متفاوت انتخاب کنید.':first+' ← '+second+' ← بازگشت به '+first;
 const currentClock=modelCivil();$('shortModelClock').textContent=currentClock?currentClock.replace('T',' '):'در نخستین بررسی تنظیم می‌شود';
 const scheduled=current?.short_loop?.timed;
 $('shortTrainContext').textContent=reserve?'قطار ذخیره؛ تراک و جهت استقرار را انتخاب کنید':current?`قطار ${current.label} · تراک ${current.head} · ${scheduled?`اعزام ${scheduled.datetime.replace('T',' ')} از ST${scheduled.origin} · ${scheduled.status==='missed'?'اعزام انجام نشد':scheduled.status==='departed'?(scheduled.turn_reached?'در مسیر بازگشت':'در مسیر رفت'):scheduled.status==='cancelled'?'در حال لغو':'در انتظار اعزام'}`:current.short_loop?'در گردش کوتاه':'مسیر فعلی مدل'}`:'قطار مدل یا قطار ذخیره را انتخاب کنید.';
 for(const t of state.trains){const tm=t.short_loop?.timed,key=tm&&`${t.id}:${tm.due}`;if(tm?.status==='missed'&&!notifiedMissed.has(key)){notifiedMissed.add(key);toast(`اعزام ${t.label} انجام نشد: ${tm.error||'مسیر یا قطار در ساعت مقرر آماده نبود.'}`,true);}}
 if(scheduled?.status==='missed'&&!shortBusy)$('shortReport').textContent=`اعزام ${current.label} انجام نشد: ${scheduled.error||'قطار یا مسیر در موعد آماده نبود.'} وضعیت را بررسی و گردش را لغو کنید.`;
 $('shortEmpty').hidden=!!state.trains.length;
 const entered=Number($('svcHeadway').value),match=Number.isFinite(entered)&&Math.abs(entered*60-state.config.headway_s)<.001;
 $('shortHeadwayInfo').textContent=`هدوی سرویس اصلی: ${SimUnits.formatMinutes(state.config.headway_s)} دقیقه؛ در گردش کوتاه، ساعت اعزام و تداخل تراک و سوزن بررسی می‌شود، نه شرط حداقل هدوی سرویس اصلی.`;
 if(shortReady&&shortCheckedKey!==shortKey()){shortReady=false;$('shortReport').textContent='انتخاب تغییر کرد؛ دوباره بررسی کنید.';}
 for(const id of ['shortTrain','shortLow','shortHigh','shortOrigin','shortDeparture','shortReserveLine','shortReserveSection','shortModelOnly'])$(id).disabled=shortBusy;
 const same=$('shortLow').value===$('shortHigh').value;$('shortFind').disabled=shortBusy||same||!$('shortDeparture').value;$('shortPreview').disabled=shortBusy||same||(!current&&!reserve)||!$('shortDeparture').value;$('shortApply').disabled=shortBusy||!shortReady;
 $('shortShowMap').disabled=!current;$('shortReturn').disabled=!current||!current.short_loop;
}
function invalidateShort(){shortReady=false;shortCheckedKey=null;$('shortReport').textContent='انتخاب تغییر کرد؛ برای دیدن نتیجه دوباره بررسی کنید.';if(state)renderShortControls();}
for(const id of ['shortTrain','shortLow','shortHigh','shortOrigin','shortDeparture','shortReserveSection','shortModelOnly'])$(id).addEventListener('change',invalidateShort);
$('shortReserveLine').addEventListener('change',()=>{populateReserve();invalidateShort();});$('shortDeparture').addEventListener('input',invalidateShort);$('svcHeadway').addEventListener('input',()=>{if(state)renderShortControls();});
$('shortAddTrain').onclick=()=>{document.querySelector('[data-tab="operations"]').click();$('trainLabel').scrollIntoView({block:'center'});$('trainLabel').focus();};
function shortArgs(){const first=Number($('shortLow').value),second=Number($('shortHigh').value);return {low:Math.min(first,second),high:Math.max(first,second),origin:first,departure:$('shortDeparture').value,plan:shortPlan(),model_only_confirmed:$('shortModelOnly').checked,line:$('shortReserveLine').value,section:$('shortReserveSection').value};}
async function shortRequest(obj){const response=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});const data=await response.json();if(!data.ok)throw Error(data.error);return data;}
let scanGeneration=0,scanRunning=false;
function stopShortScan(message){scanGeneration++;scanRunning=false;$('shortScan').disabled=false;$('shortScanStop').hidden=true;if(message)$('shortScanStatus').textContent=message;}
$('shortScanStop').onclick=()=>stopShortScan('جست‌وجو متوقف شد. نتیجه‌ای که قبلاً نمایش داده شده باید پیش از ثبت دوباره بررسی شود.');
for(const id of ['shortLow','shortHigh','shortModelOnly'])$(id).addEventListener('change',()=>{if(scanRunning)stopShortScan('انتخاب تغییر کرد؛ دوباره دکمه پیدا کردن ساعت‌ها را بزنید.');$('shortScanResults').replaceChildren();});
$('shortScan').onclick=async()=>{
 if(scanRunning||shortBusy||!state)return;
 const first=Number($('shortLow').value),second=Number($('shortHigh').value);
 if(first===second){$('shortScanStatus').textContent='دو ایستگاه متفاوت انتخاب کنید.';return;}
 scanRunning=true;const token=++scanGeneration;$('shortScan').disabled=true;$('shortScanStop').hidden=false;$('shortScanResults').replaceChildren();
 try{
  await autoShortClock();if(token!==scanGeneration)return;
  const trainList=state.trains.filter(t=>!t.short_loop).map(t=>({id:t.id,label:t.label}));
  if(!trainList.length)throw Error('قطار آزاد و قابل انتخابی در مدل وجود ندارد. ابتدا قطارها را به مدل منتقل یا تعریف کنید.');
  const baseArgs=shortArgs();let found=0,limited=0;
  for(let n=0;n<trainList.length;n++){
   if(token!==scanGeneration)return;
   const train=trainList[n];$('shortScanStatus').textContent=`پیش‌بینی آمادگی قطار ${train.label} در مبدأ (${n+1} از ${trainList.length})؛ ساعت مدل در زمان هر محاسبه موقتاً متوقف است.`;
   const ready=await shortRequest({op:'smart_short_predicted_ready',...baseArgs,id:train.id});if(token!==scanGeneration)return;
   const row=document.createElement('div');row.className='readout';let reasons=[],accepted=null;
   if(ready.ready?.valid){
    // Derive candidate instants from THIS train's modeled arrival, not a user
    // grid. Preview each full round trip; retries are bounded, not exhaustive.
    const firstMinute=Math.ceil((Date.parse(ready.ready.datetime+'Z')+30000)/60000)*60000;
    for(const extra of [0,60,180,600]){
     if(token!==scanGeneration)return;
     const departure=new Date(firstMinute+extra*1000).toISOString().slice(0,19);
     $('shortScanStatus').textContent=`در حال بررسی رفت‌وبرگشت قطار ${train.label} برای ${departure.replace('T',' ')} (${n+1} از ${trainList.length}).`;
     const result=await shortRequest({op:'smart_short_existing_preview',...baseArgs,id:train.id,departure});if(token!==scanGeneration)return;
     if(result.short_loop?.valid){accepted=departure;break;}reasons.push(`${departure.replace('T',' ')}: ${(result.short_loop?.errors||[]).join('؛ ')}`);
    }
   }else{reasons=ready.ready?.errors||['زمان آماده‌شدن در مدل پیدا نشد.'];}
   if(accepted){found++;row.dataset.departure=accepted;const text=document.createElement('span');text.textContent=`${accepted.replace('T',' ')} — قطار ${train.label} `;row.append(text);
    const choose=document.createElement('button');choose.type='button';choose.className='secondary';choose.textContent='انتخاب و بررسی دوباره';
    choose.onclick=async()=>{stopShortScan('پیشنهاد انتخاب شد؛ پیش از ثبت دوباره بررسی می‌شود.');$('shortDeparture').value=accepted.slice(0,16);$('shortTrain').value=String(train.id);invalidateShort();await checkShort(false);$('shortReport').scrollIntoView({block:'nearest'});};row.append(choose);
    const results=$('shortScanResults'),before=[...results.children].find(el=>el.dataset.departure&&el.dataset.departure>accepted);results.insertBefore(row,before||null);
   }else{limited++;const text=document.createElement('span');text.textContent=`قطار ${train.label}: در تلاش‌های محدود، ساعت تأییدشده پیدا نشد.`;row.append(text);
    if(reasons.length){const details=document.createElement('details'),summary=document.createElement('summary');summary.textContent='علت‌های بررسی';details.append(summary);const list=document.createElement('ul');for(const reason of reasons){const li=document.createElement('li');li.textContent=reason;list.append(li);}details.append(list);row.append(details);}$('shortScanResults').append(row);}
  }
  if(token===scanGeneration)$('shortScanStatus').textContent=`${found} پیشنهاد برای قطارهای مدل پیدا شد${limited?`؛ برای ${limited} قطار در تلاش‌های محدود پیشنهادی تأیید نشد`:''}. این فهرست همه ساعت‌های ممکن را پوشش نمی‌دهد؛ هر انتخاب پیش از ثبت دوباره بررسی می‌شود.`;
 }catch(e){if(token===scanGeneration)$('shortScanStatus').textContent=userError(e);}
 finally{if(token===scanGeneration){scanRunning=false;$('shortScan').disabled=false;$('shortScanStop').hidden=true;}}
};
$('shortFind').onclick=async()=>{if(shortBusy)return;shortBusy=true;renderShortControls();$('shortCandidates').textContent='در حال بررسی تک‌تک قطارهای مدل؛ لطفاً صبر کنید…';try{await autoShortClock();const data=await shortRequest({op:'smart_short_candidates',...shortArgs()});const yes=data.candidates.filter(x=>x.valid),no=data.candidates.filter(x=>!x.valid);$('shortCandidates').innerHTML=(yes.length?'<b>قطارهای مناسب بر اساس فقط مدل:</b> '+yes.map(x=>esc(x.label)+' ('+esc(x.track)+')').join('، '):'<b>قطار مناسب در مدل پیدا نشد.</b>')+(no.length?'<ul>'+no.map(x=>`<li>${esc(x.label)}: ${esc(x.errors.join('؛ '))}</li>`).join('')+'</ul>':'')+(data.unmapped.length?'<p>قطارهای زیر فقط در برنامه زمانی‌اند و هنوز در مدل حرکتی تعریف نشده‌اند؛ برای بررسی واقعی مدل باید در مدل تعریف شوند: '+data.unmapped.map(x=>esc(x.label)).join('، ')+'</p>':'')+(!data.plan_valid?'<p>برنامه ناوگان معتبر در دسترس نیست یا هنوز محاسبه نشده است.</p>':'');if(yes.length){$('shortTrain').value=String(yes[0].id);invalidateShort();}}catch(e){$('shortCandidates').textContent=userError(e);}finally{shortBusy=false;if(state)renderShortControls();}};
async function checkShort(apply){
 if(shortBusy||!state)return;shortBusy=true;shortReady=false;renderShortControls();$('shortReport').textContent='در حال بررسی ساعت اعزام و تداخل رفت‌وبرگشت؛ لطفاً صبر کنید…';
 try{await autoShortClock();const reserve=$('shortTrain').value==='reserve',key=shortKey(),op=reserve?(apply?'smart_short_reserve_apply':'smart_short_reserve_preview'):(apply?'smart_short_existing_apply':'smart_short_existing_preview');const obj=await shortRequest({op,...shortArgs(),id:reserve?undefined:Number($('shortTrain').value)});const r=obj.short_loop,chosen=state.trains.find(t=>t.id===r.id),name=r.label||chosen?.label||String(r.id);
 $('shortReport').innerHTML=r.valid?`<b>${r.applied?'گردش رفت‌وبرگشت ثبت شد':'بررسی رفت‌وبرگشت پذیرفته شد'}</b><br>قطار ${esc(name)}؛ اعزام ST${r.origin} → ST${r.destination} در <bdi>${esc(r.departure.replace('T',' '))}</bdi><br><b>ایستگاه‌های مسیر رفتِ بررسی‌شده:</b> ${(r.stations||[]).map((s,i)=>esc(`ST${s.id} — ${s.name}${i===0?" (مبدأ اعزام)":" (توقف در مدل)"}`)).join(" ← ")}<br><b>ایستگاه‌های برگشت:</b> ${(r.return_stations||[]).map(s=>esc(`ST${s.id} — ${s.name}`)).join(' ← ')}<br>بازه پیش‌بینی: ${code(timeText(r.horizon_s))}. ${reserve?`ذخیره باقی‌مانده بعد از اعمال: ${fmt(r.remaining_reserve)}.`:''} ساعت اعزام، اشغال تراک و سوزن و انتظار ناشی از سایر قطارهای مدل در رفت و برگشت بررسی می‌شود؛ معیار رد، صرفاً فاصله هدوی نیست. پیش از اعمال بررسی تکرار می‌شود. نتیجه مجوز ایمنی میدان نیست.`:`<b>گردش کوتاه قابل اعمال نیست</b><ul>${r.errors.map(e=>`<li>${esc(e)}</li>`).join('')}</ul>`;
 state=await(await fetch('/api/state')).json();if(r.valid&&!r.applied&&key===shortKey()){shortReady=true;shortCheckedKey=key;}render();if(r.applied){mapFocusTrain=r.id;toast('رفت و برگشت ثبت شد؛ پس از بازگشت به مبدأ پایان می‌یابد.');}
 }catch(e){$('shortReport').textContent=userError(e);}finally{shortBusy=false;if(state)renderShortControls();}}
$('shortPreview').onclick=()=>checkShort(false);$('shortApply').onclick=()=>checkShort(true);
$('shortReturn').onclick=async()=>{const r=await action({op:'short_return',id:Number($('shortTrain').value)});if(r)$('shortReport').textContent=r.message;};
$('shortShowMap').onclick=()=>{document.querySelector('[data-tab="operations"]').click();focusRoute(Number($('shortTrain').value));};


function plannedTrain(v){const chain=lineData.chains?.[v.direction]||[],k=chain.indexOf(v.track),parts=[v.track];let covered=Number(v.head_m),i=k;while(covered<(state?.config?.train_length_m||100)/2&&i>0){i--;parts.unshift(chain[i]);covered+=lineData.tracks[chain[i]].length_m;}return {head:v.track,pos:v.head_m,line:v.direction,kind:'run',sections:parts,body_route:k>=0?chain.slice(0,k+1):[],path_prev:k>0?chain[k-1]:null,path_next:k>=0&&k+1<chain.length?chain[k+1]:null};}
function renderPlannedMarkers(){
 const group=$("plannedMarkers");if(!group)return;group.replaceChildren();
 if(!mapPlanned?.valid)return;const factor=lineData.layout.size[0]/parseFloat($("map").style.width);
 for(const v of mapPlanned.vehicles){if(!v.track||v.head_m===null)continue;const p=positionTrainCenter(plannedTrain(v));if(!p)continue;
 const label=String(v.label||v.id),width=Math.max(32,Math.min(220,Array.from(label).length*8+18))*factor,y=p[1]-40*factor;
 const mark=svgEl("g",{"data-planned-train":v.id,"pointer-events":"none"});mark.append(svgEl("rect",{x:p[0]-width/2,y,width,height:25*factor,rx:12*factor,fill:"#251330",stroke:"#bd7add","stroke-width":2*factor}));
 const text=svgEl("text",{x:p[0],y:y+16.5*factor,"font-size":12*factor,fill:"#f3e3ff","text-anchor":"middle",direction:"auto","unicode-bidi":"plaintext"},label);
 if(Array.from(label).length*8+18>220){text.setAttribute("textLength",String(width-16*factor));text.setAttribute("lengthAdjust","spacingAndGlyphs");}
 mark.append(text);mark.append(svgEl("title",{},`قطار برنامه‌ای ${label} — ${v.track}؛ موقعیت تخمینی و بدون اشغال در مدل`));group.append(mark);}
}
function wallNow(){const value=window.ServiceClockUI?.tehran();if(value)$("mapWallClock").textContent=value.replace("T"," ");return value;}
async function showClockPositions(){
 if(mapClockBusy)return;mapClockBusy=true;
 try{const now=wallNow();if(!window.ServiceClockUI?.getPlan)throw Error("فرم برنامه زمانی هنوز آماده نیست.");const plan=ServiceClockUI.getPlan();plan.headway_min=Number($("mapClockHeadway").value);
 const response=await fetch("/api/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({op:"service_positions",plan,now})});const obj=await response.json();if(!obj.ok)throw Error(obj.error);mapPlanned=obj.service;
 $("mapClockReport").innerHTML=mapPlanned.valid?`<b>موقعیت برنامه‌ای در ${esc(mapPlanned.now.replace("T"," "))}</b>؛ هدوی ${fmt(mapPlanned.headway_min)} دقیقه. نشان بنفش با نام قطار، موقعیت برنامه‌ای تخمینی است و در مدل اشغال ایجاد نمی‌کند.`:`<b>برنامه زمانی معتبر نیست؛ موقعیت رسم نشد.</b><ul>${mapPlanned.errors.map(e=>`<li>${esc(e)}</li>`).join("")}</ul>`;
 if(mapPlanned.valid&&state&&Math.abs(plan.headway_min*60-state.config.headway_s)>0.01)$('mapClockReport').append(document.createTextNode(' توجه: هدوی این نمایش با هدوی مدل حرکتی فرق دارد؛ تنظیمات حرکت قطارها تغییر نکرده است.'));
 const names={moving:"بین ایستگاه‌ها",station:"توقف در ایستگاه",turnaround:"گردش پایانه؛ تراک دقیق از جدول معلوم نیست",waiting:"منتظر اعزام",finished:"پایان سفر؛ محل پارک معلوم نیست",not_started:"پیش از اولین سفر",reserve:"ذخیره؛ محل پارک معلوم نیست",conflict:"برنامه ناسازگار"};
 $("mapClockVehicles").innerHTML=mapPlanned.vehicles.map(v=>`<tr><td>${esc(v.label||v.id)}</td><td>${esc(names[v.status]||v.status)}</td><td>${esc(v.station_name||[v.from_name,v.to_name].filter(Boolean).join(" ↔ ")||"مکان مشخص نیست")}</td><td>${esc(v.track||"—")}</td></tr>`).join("");renderMap();
 }catch(e){mapPlanned=null;$("mapClockReport").textContent=userError(e);renderMap();}finally{mapClockBusy=false;}
}
$("mapNow").onclick=showClockPositions;$("mapHidePlan").onclick=()=>{mapPlanned=null;$("mapFollowNow").checked=false;$("mapClockVehicles").replaceChildren();$("mapClockReport").textContent="نشان‌های برنامه‌ای پنهان شدند؛ قطارهای مدل حرکتی تغییری نکردند.";renderMap();};
$("mapFollowNow").onchange=()=>{if($("mapFollowNow").checked)showClockPositions();};
$("planNow").onclick=async()=>{if(state)$("mapClockHeadway").value=state.config.headway_s/60;document.querySelector('[data-tab="operations"]').click();await showClockPositions();$("mapWallClock").scrollIntoView({block:"center"});};
setInterval(wallNow,1000);setInterval(()=>{if($("mapFollowNow").checked&&!shortBusy)showClockPositions();},5000);
(async()=>{try{lineData=await(await fetch("/api/line")).json();init();await poll();renderTrackTable();setInterval(poll,700);}catch(e){toast("راه‌اندازی رابط ناموفق: "+e.message,true);}})();