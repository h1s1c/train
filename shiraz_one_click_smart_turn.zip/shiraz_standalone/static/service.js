/* Timetable predictions and explicit, conservative movement-model seeding. */
(()=>{"use strict";
 const el=id=>document.getElementById(id), safe=s=>String(s??"").replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const fmt=n=>new Intl.NumberFormat('fa-IR',{maximumFractionDigits:2}).format(n);
 const fields={first_a:'svcFirstA',last_a:'svcLastA',first_b:'svcFirstB',last_b:'svcLastB',headway_min:'svcHeadway',fleet_count:'svcFleet',run_a_s:'svcRunA',run_b_s:'svcRunB',turn_a_s:'svcTurnA',turn_b_s:'svcTurnB',dwell_s:'svcDwell'};
 const numeric=new Set(['headway_min','fleet_count','run_a_s','run_b_s','turn_a_s','turn_b_s','dwell_s']);
 let result=null, profiles=null, serial=0, lastPlan=null, profileKey=null, followBusy=false;
 const statuses={moving:'در حرکت',station:'توقف در ایستگاه',turnaround:'گردش پایانه',waiting:'منتظر اعزام بعد',finished:'سرویس پایان یافته',not_started:'هنوز اعزام نشده',reserve:'ذخیره؛ محل نامشخص',conflict:'برنامه ناسازگار'};
 const clock=s=>{s=Math.round(Number(s));return [Math.floor(s/3600),Math.floor(s%3600/60),s%60].map(x=>String(x).padStart(2,'0')).join(':');};
 const readClock=s=>{if(!/^\d{2}:\d{2}:\d{2}$/.test(s)||Number(s.slice(3,5))>59||Number(s.slice(6))>59)throw Error('زمان را با قالب ساعت:دقیقه:ثانیه وارد کنید؛ برای نمونه: 00:03:20.');const a=s.split(':').map(Number);return a[0]*3600+a[1]*60+a[2];};
 const dateText=s=>s?s.replace('T',' '):'—';
 function tehran(){const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date());const p=Object.fromEntries(parts.map(x=>[x.type,x.value]));return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`;}
 const active=()=>el('planning').classList.contains('active');
 function message(text,error=false){el('svcMessage').className=error?'service-error':'';el('svcMessage').textContent=text;}
 function invalidate(text='اطلاعات تغییر کرده است. برای به‌روزرسانی موقعیت‌ها، دوباره محاسبه کنید.'){serial++;result=null;el('svcOutput').hidden=true;message(text);syncStats();}
 function planFromForm(ignoreProfile=false){
  const p={};for(const [key,id]of Object.entries(fields)){const value=el(id).value;if(!value.trim())throw Error('لطفاً همهٔ زمان‌ها و فیلدهای ضروری را تکمیل کنید.');p[key]=numeric.has(key)?Number(value):value;}
  p.labels=el('svcLabels').value.trim()?el('svcLabels').value.split(/[,،\n]/).map(s=>s.trim()):[];
  p.profile_mode=el('svcMode').value;
  if(p.profile_mode==='custom'&&!ignoreProfile){
   if(!profiles)throw Error('ابتدا جدول ایستگاه‌ها را ایجاد کنید؛ سپس می‌توانید زمان‌های آن را ویرایش کنید.');
   p.profiles=structuredClone(profiles);
   for(const input of document.querySelectorAll('#svcProfiles input')){p.profiles[input.dataset.dir][Number(input.dataset.row)][input.dataset.key]=readClock(input.value.trim());}
  }
  return p;
 }
 const timingKey=p=>JSON.stringify([p.run_a_s,p.run_b_s,p.dwell_s]);
 async function request(op,plan,now){const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({op,plan,now}),signal:AbortSignal.timeout(15000)});const data=await r.json();if(!r.ok||!data.ok)throw Error(data.error||'پاسخ برنامه قابل پردازش نیست. لطفاً دوباره تلاش کنید.');return data.service;}
 function renderProfiles(rows){
  profiles=structuredClone(rows);const custom=el('svcMode').value==='custom';
  el('svcProfiles').innerHTML=['A','B'].map(d=>`<div><h3 class="service-profile-title">${d==='A'?'A · احسان به دستغیب':'B · دستغیب به احسان'}</h3><div class="tablewrap"><table><thead><tr><th>ایستگاه</th><th>زمان سپری‌شده تا ورود</th><th>زمان سپری‌شده تا خروج</th></tr></thead><tbody>${rows[d].map((row,i)=>`<tr><td>${safe(row.name)}<small>ST${row.station}</small></td>${['arrival_s','departure_s'].map(k=>`<td><input aria-label="${d} ST${row.station} ${k==='arrival_s'?'ورود':'خروج'}" data-dir="${d}" data-row="${i}" data-key="${k}" value="${clock(row[k])}" ${custom?'':'readonly'} maxlength="8"></td>`).join('')}</tr>`).join('')}</tbody></table></div></div>`).join('');
  el('svcProfiles').querySelectorAll('input').forEach(x=>x.addEventListener('input',()=>{el('svcFollow').checked=false;invalidate('جدول ایستگاهی تغییر کرده؛ برای اعمال دوباره محاسبه کنید.');}));
 }
 async function template(){
  try{if(profiles&&el('svcMode').value==='custom'&&!confirm('جدول ویرایش‌شده با جدول پیشنهادی جایگزین شود؟'))return;
   const p=planFromForm(true);p.profile_mode='estimated';delete p.profiles;const token=++serial;const data=await request('service_template',p);if(token!==serial)return;
   renderProfiles(data.profiles);profileKey=timingKey(p);invalidate('جدول پیشنهادی ساخته شد. زمان‌های آن تخمینی‌اند؛ برای استفاده، محاسبه را بزنید.');
  }catch(e){message(typeof userError==="function"?userError(e):e.message,true);}
 }
 async function calculate(){
  const token=++serial;
  try{
   const p=planFromForm(), now=el('svcNow').value;if(!now)throw Error('لطفاً تاریخ و ساعت مرجع را وارد کنید.');
   if(p.profile_mode==='custom'&&profileKey!==timingKey(p))throw Error('زمان کل مسیر یا زمان توقف تغییر کرده است. جدول ایستگاه‌ها را دوباره ایجاد کنید و سپس ویرایش را انجام دهید.');
   message('در حال تخصیص قطارها و محاسبهٔ موقعیت…');const data=await request('service_positions',p,now);if(token!==serial)return;
   result=data;lastPlan=structuredClone(p);
   if(p.profile_mode==='estimated'||!profiles){renderProfiles(data.profiles);profileKey=timingKey(p);}
   renderOutput();syncStats();message(data.valid?'موقعیت برنامه‌ای همهٔ قطارها برای ساعت انتخاب‌شده محاسبه شد؛ این اطلاعات، موقعیت زندهٔ قطارها نیست.':'برنامه با محدودیت‌های تعداد قطار، فاصلهٔ اعزام یا مسیر پایانه سازگار نیست و قابل اعمال یا اجرا نیست. جزئیات خطا را بررسی کنید.',!data.valid);
  }catch(e){if(token===serial){result=null;el('svcOutput').hidden=true;message(typeof userError==="function"?userError(e):e.message,true);syncStats();el('svcFollow').checked=false;}}
 }
 function syncStats(){
  const matches=result?.valid&&typeof state!=='undefined'&&state&&Math.abs(state.config.ehsan_turn_s-result.turn_a_s)<.001&&Math.abs(state.config.turn_s-result.turn_b_s)<.001&&Math.abs(state.config.headway_s-result.headway_min*60)<.001&&state.profile.low===1&&state.profile.high===21&&state.capacity.timetable.run_a_s===result.run_a_s&&state.capacity.timetable.run_b_s===result.run_b_s;
  el('svcApply').disabled=!result?.valid;el('svcSeed').disabled=!result?.valid;
  el('svcApplied').textContent=matches?'پارامترهای زمانی و هدوی با مدل یکسان‌اند. برای انتقال قطارها، مدل باید متوقف و خالی باشد.':'پس از محاسبه، «انتقال قطارهای برنامه به مدل» را بزنید؛ مدل باید متوقف و خالی باشد. محل نامعلوم پایانه یا ذخیره حدس زده نمی‌شود.';
 }

 function location(v){if(v.status==='moving')return `بین ${v.from_name} و ${v.to_name}`;if(v.station_name)return v.station_name;return v.status==='reserve'?'محل پارک مشخص نشده':'موقعیت معتبر در دسترس نیست';}
 function renderOutput(){
  const r=result;el('svcOutput').hidden=false;el('svcReference').textContent=dateText(r.now);
  const wins=['A','B'].map(d=>`${d}: آخرین اعزام <bdi>${dateText(r.windows[d].last_departure)}</bdi>؛ آخرین رسیدن <bdi>${dateText(r.windows[d].last_arrival)}</bdi>`).join('<br>');
  el('svcSummary').innerHTML=`<b>${r.valid?'تعداد قطارها، فاصله اعزام‌ها و زمان استفاده از پایانه با این مدل سازگار است':'برنامه قابل اجرا نیست؛ تعداد قطارها، فاصله اعزام‌ها یا زمان استفاده از پایانه را اصلاح کنید'}</b><p>حداقل قطار لازم در بازه زمانی انتخاب‌شده: ${fmt(r.required_fleet)} قطار · واردشده: ${fmt(r.fleet_count)} · ذخیره: ${fmt(r.reserve)}<br>زمان یک چرخه کامل رفت‌وبرگشت با گردش دو پایانه: <bdi>${clock(r.cycle_s)}</bdi> · هدوی ${fmt(r.headway_min)} دقیقه<br>کمترین فاصله اعزام بر اساس محدودیت‌های اولیه مدل: ${fmt(r.minimum_headway_s/60)} دقیقه؛ زمان دقیق اعزام‌ها و آزادبودن سکوی خروج احسان (A) هم جداگانه بررسی می‌شود.<br>گردش احسان: ${clock(r.turn_a_s)}؛ گردش دستغیب: ${clock(r.turn_b_s)}${r.terminal_current?'<br>طبق برنامه، مسیر مانور احسان در اختیار قطار '+r.terminal_current.vehicle+'؛ باقی‌مانده تا آزادسازی '+clock(r.terminal_current.remaining_s):''}</p><p>${wins}</p><small>چیدمان اولیه در دو پایانه از برنامه استنباط شده، مشاهده نشده است. ${r.position_basis==='estimated_station_timetable'?'جدول ایستگاهی و موقعیت بین ایستگاه‌ها تخمینی است.':'ایستگاه از جدول کاربر محاسبه می‌شود؛ تراک بین ایستگاه‌ها همچنان تخمینی است.'} این محاسبه امکان‌سنجی سیگنالینگ یا تضمین حرکت واقعی نیست.</small>`;
  el('svcWarnings').innerHTML=r.warnings.map(w=>`<p>${safe(w)}</p>`).join('');
  el('svcVehicles').innerHTML=r.vehicles.map(v=>`<section class="service-vehicle" id="svcVehicle${v.id}"><h3><bdi>${safe(v.label)}</bdi><span class="service-badge">${safe(statuses[v.status])}</span></h3><p><b>${safe(location(v))}</b></p><p>${v.direction?'جهت '+(v.direction==='A'?'احسان به دستغیب (A)':'دستغیب به احسان (B)'):v.next_direction?'اعزام بعد در جهت '+v.next_direction:'—'}</p>${v.departure?`<small>اعزام سفر: <bdi>${dateText(v.departure)}</bdi></small>`:''}${v.next_arrival?`<small>رسیدن به ${safe(v.to_name)}: <bdi>${dateText(v.next_arrival)}</bdi></small>`:''}${v.station_departure?`<small>خروج از ایستگاه: <bdi>${dateText(v.station_departure)}</bdi></small>`:''}${v.next_departure?`<small>اعزام بعد: <bdi>${dateText(v.next_departure)}</bdi></small>`:''}${v.ready?`<small>آماده پس از گردش: <bdi>${dateText(v.ready)}</bdi></small>`:''}${v.track?`<small>محل تخمینی جلوی قطار روی تراک: <bdi>${safe(v.track)}</bdi>، ${fmt(v.head_m)} متر از ابتدای مسیر مدار</small>`:v.station_name?'<small>تراک توقف / مانور در پایانه از این جدول معلوم نیست.</small>':''}<small>${safe(v.message||'موقعیت برنامه‌ای؛ بدون دریافت وضعیت واقعی قطار')}</small></section>`).join('');
  el('svcTrips').innerHTML=r.valid?r.trips.map(t=>`<tr><td><bdi>${safe(r.vehicles[t.vehicle-1].label)}</bdi></td><td>${t.direction}</td><td dir="ltr">${dateText(t.departure)}</td><td dir="ltr">${dateText(t.arrival)}</td><td dir="ltr">${dateText(t.ready)}</td></tr>`).join(''):'<tr><td colspan="5">به‌دلیل ناسازگاری تعداد قطارها، فاصلهٔ اعزام یا محدودیت‌های پایانه، برنامهٔ سفرها قابل اجرا نیست.</td></tr>';
  drawMap(r);
 }
 function drawMap(r){
  const svg=el('svcMap');svg.replaceChildren();
  const add=(tag,attrs,text,parent=svg)=>{const n=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const[k,v]of Object.entries(attrs||{}))n.setAttribute(k,v);if(text!==undefined)n.textContent=text;parent.appendChild(n);return n;};
  const markers=[], lanes={A:[],B:[],terminal:[]};
  const labels=lastPlan?.labels||[];
  if(r.valid)for(const v of r.vehicles){let x,lane,color='#a07025';
   if(v.status==='moving'||v.status==='station'){
    const q=(v.map_index+(v.status==='moving'?v.progress:0))/(r.profiles[v.direction].length-1);x=v.direction==='A'?1290-q*1180:110+q*1180;lane=v.direction;color=v.status==='moving'?'#1d77b7':'#26845d';
   }else if(v.station){x=v.station===21?1290:110;lane='terminal';color=v.status==='finished'||v.status==='not_started'?'#77838b':'#a07025';}
   else continue;
   const label=(labels[v.id-1]||'').trim()||String(v.id);
   const custom=!!(labels[v.id-1]||'').trim();
   // Measure actual SVG text when visible; a conservative fallback covers hidden tabs.
   const probe=add('text',{'font-size':13,visibility:'hidden'},label);
   let measured=0;try{measured=probe.getComputedTextLength();}catch(_){}probe.remove();
   const width=custom?Math.max(26,Math.ceil(Math.max(measured,Array.from(label).length*13)+20)):26;
   const marker={v,x,lane,color,label,width,row:0};
   const occupied=lanes[lane];while(occupied[marker.row]?.some(([left,right])=>x+width/2+5>left && x-width/2-5<right))marker.row++;
   (occupied[marker.row]||= []).push([x-width/2,x+width/2]);markers.push(marker);
  }
  const rowCount=lane=>Math.max(1,lanes[lane].length);
  const yA=110+(rowCount('A')-1)*32, yB=yA+130+(rowCount('B')-1)*32;
  const yTerminal=yB+100+(rowCount('terminal')-1)*32;
  const minX=Math.min(0,...markers.map(m=>m.x-m.width/2-8)),maxX=Math.max(1400,...markers.map(m=>m.x+m.width/2+8));
  svg.setAttribute('viewBox',`${minX} 0 ${maxX-minX} ${yTerminal+70}`);
  add('text',{x:700,y:28,'text-anchor':'middle',fill:'#67717a','font-size':15},'موقعیت از برنامهٔ زمانی — فاصله‌های روی نقشه مقیاس متری ندارند');
  for(const d of ['A','B']){
   const y=d==='A'?yA:yB;const rows=r.profiles[d];add('line',{x1:110,x2:1290,y1:y,y2:y,stroke:'#929aa2','stroke-width':4});
   add('text',{x:700,y:y-32*rowCount(d),'text-anchor':'middle',fill:'#566977','font-size':17},d==='A'?'A · احسان به دستغیب ←':'B · دستغیب به احسان →');
   rows.forEach((row,i)=>{const q=i/(rows.length-1),x=d==='A'?1290-q*1180:110+q*1180;const n=add('circle',{cx:x,cy:y,r:5,fill:'#929aa2'});const title=document.createElementNS(svg.namespaceURI,'title');title.textContent=row.name;n.appendChild(title);add('text',{x,y:y+27,'text-anchor':'middle',fill:'#65727d','font-size':12},'ST'+row.station);});
  }
  add('text',{x:110,y:yB+70,'text-anchor':'middle',fill:'#65727d','font-size':17},'دستغیب');add('text',{x:1290,y:yB+70,'text-anchor':'middle',fill:'#65727d','font-size':17},'احسان');
  if(!r.valid){add('text',{x:700,y:yB+105,'text-anchor':'middle',fill:'#b12f26','font-size':19},'تعداد قطارها، فاصلهٔ اعزام یا محدودیت پایانه با هم سازگار نیست؛ برنامه قابل اعمال نیست.');return;}
  for(const m of markers){const {v,x,lane,color,label,width,row}=m;const y=(lane==='A'?yA:lane==='B'?yB:yTerminal)-row*32;
   const group=add('g',{class:'svc-marker',tabindex:0,role:'button','data-vehicle-id':v.id,'aria-label':label+' · '+statuses[v.status]+' · '+location(v)});
   if(row && lane!=='terminal')add('line',{x1:x,x2:x,y1:y+13,y2:lane==='A'?yA:yB,stroke:color,'stroke-width':1,'pointer-events':'none'},undefined,group);
   add('rect',{x:x-width/2,y:y-13,width,height:26,rx:13,fill:color,stroke:'#fff','stroke-width':2},undefined,group);
   add('text',{x,y:y+4,'text-anchor':'middle',fill:'#fff','font-size':13,'pointer-events':'none','unicode-bidi':'plaintext'},label,group);
   add('title',{},label+' · '+statuses[v.status]+' · '+location(v),group);
   const select=()=>{document.querySelectorAll('.svc-selected').forEach(n=>n.classList.remove('svc-selected'));const card=el('svcVehicle'+v.id);card.classList.add('svc-selected');card.scrollIntoView({behavior:'smooth',block:'center'});};group.addEventListener('click',select);group.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();select();}});
  }
 }

 for(const id of [...Object.values(fields),'svcLabels'])el(id).addEventListener('input',()=>{el('svcFollow').checked=false;invalidate();});
 el('svcNow').addEventListener('input',()=>{el('svcFollow').checked=false;invalidate('ساعت مرجع تغییر کرده؛ محاسبه را بزنید.');});
 el('svcMode').addEventListener('change',()=>{if(profiles){/* Preserve edited values while toggling. */for(const input of document.querySelectorAll('#svcProfiles input')){if(!input.readOnly){try{profiles[input.dataset.dir][Number(input.dataset.row)][input.dataset.key]=readClock(input.value);}catch(e){message(typeof userError==="function"?userError(e):e.message,true);}}}renderProfiles(profiles);}el('svcFollow').checked=false;invalidate();});
 async function seedRequest(op,plan,now,expected){const response=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({op,plan,now,expected}),signal:AbortSignal.timeout(30000)});const data=await response.json();if(!response.ok||!data.ok)throw Error(data.error||'انتقال برنامه انجام نشد.');return data;}
 el('svcSeed').onclick=async()=>{try{
  const plan=planFromForm(),now=el('svcNow').value,token=++serial;el('svcFollow').checked=false;message('در حال بررسی محل و بدنه قطارها…');
  const preview=await seedRequest('service_seed_preview',plan,now);if(token!==serial)return;
  const s=preview.seed,missing=s.unresolved.map(v=>v.label+' — '+v.reason).join('\n'),reserve=s.reserves.map(v=>v.label).join('، ');
  if(!s.placed.length)throw Error('هیچ قطار قابل انتقالی پیدا نشد. '+(missing||'محل قطارهای برنامه مشخص نیست.'));
  const warning=s.unresolved.length?'\n\nقطارهای زیر وارد نمی‌شوند و تا تعیین محل در بررسی تداخل لحاظ نمی‌شوند:\n'+missing:'\n\nهمه قطارهای فعال قابل تعیین وارد می‌شوند.';
  if(!confirm(`${s.placed.length} قطار از موقعیت تخمینی برنامه به مدل خالی منتقل می‌شود.${warning}${reserve?'\nذخیره با محل نامعلوم: '+reserve:''}\n\nمدل متوقف می‌ماند و قطارها از سکون شروع می‌کنند. اعزام‌های آینده یا تطابق کامل با جدول زمانی تضمین نمی‌شود. ادامه می‌دهید؟`)){message('انتقال لغو شد؛ مدل تغییر نکرد.');return;}
  const done=await seedRequest('service_seed_apply',plan,now,preview.seed);if(token!==serial)return;if(typeof mapPlanned!=='undefined')mapPlanned=null;el('mapFollowNow').checked=false;el('mapClockVehicles').replaceChildren();el('mapClockReport').textContent='نشان‌های برنامه‌ای مخفی شدند؛ قطارهای انتقال‌یافته، جداگانه در مدل دیده می‌شوند.';result=done.service;lastPlan=structuredClone(plan);renderOutput();if(typeof renderedData!=='undefined')renderedData=false;if(typeof poll==='function')await poll();syncStats();
  const r=done.seed;message(`${r.placed.length} قطار با موقعیت تخمینی و از حالت سکون در مدل ساخته شد. ${r.unresolved.length?`${r.unresolved.length} قطار وارد نشد: `+r.unresolved.map(v=>v.label+' ('+v.reason+')').join('؛ ')+'. تا تعیین مکان آنها بررسی کامل نیست.':'همه قطارهای فعال با مکان قابل تعیین منتقل شدند.'} ${r.reserves.length?'ذخیره بدون محل مشخص وارد خط نشد.':''} اعزام‌های آینده مطابق جدول به‌طور خودکار اجرا نمی‌شوند.`);
 }catch(e){message(typeof userError==='function'?userError(e):e.message,true);}};
 el('svcApply').onclick=async()=>{try{const p=planFromForm(),token=++serial;const data=await request('service_apply',p,el('svcNow').value);if(token!==serial)return;result=data;lastPlan=structuredClone(p);renderOutput();if(typeof renderedData!=='undefined')renderedData=false;if(typeof poll==='function')await poll();syncStats();message('تنظیمات مشترک با موفقیت اعمال شد. اجرای قطارها بر اساس ساعت واقعی آغاز نشده است.');}catch(e){message(typeof userError==="function"?userError(e):e.message,true);}};
 el('svcCalculate').onclick=calculate;el('svcTemplate').onclick=template;
 el('svcSystemNow').onclick=()=>{el('svcNow').value=tehran();calculate();};
 el('svcFollow').onchange=()=>{if(el('svcFollow').checked){el('svcNow').value=tehran();calculate();}};
 el('svcSave').onclick=()=>{try{const plan=planFromForm(),obj={schema:'shiraz-service-clock-v1',version:'1.0.12',plan,now:el('svcNow').value,data_revision:result?.data_revision||null};const url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='shiraz-service-plan.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);message('فایل برنامهٔ زمانی ذخیره شد. این فایل شامل موقعیت زنده یا وضعیت مدل حرکتی نیست.');}catch(e){message(typeof userError==="function"?userError(e):e.message,true);}};
 el('svcLoad').onchange=async()=>{const f=el('svcLoad').files[0];if(!f)return;try{if(f.size>1048576)throw Error('حجم فایل نباید بیشتر از ۱ مگابایت باشد.');const obj=JSON.parse(await f.text());if(obj.schema!=='shiraz-service-clock-v1')throw Error('این فایل، برنامهٔ زمانی معتبر نیست. لطفاً فایل ذخیره‌شده از بخش «برنامهٔ زمانی» را انتخاب کنید.');const token=++serial;const data=await request('service_positions',obj.plan,obj.now);if(token!==serial)return;if(obj.data_revision&&obj.data_revision!==data.data_revision)throw Error('داده‌های فایل با نسخهٔ فعلی برنامه سازگار نیستند. لطفاً برنامه را با نسخهٔ فعلی دوباره ذخیره کنید.');for(const[key,id]of Object.entries(fields))el(id).value=obj.plan[key];el('svcLabels').value=(obj.plan.labels||[]).join(', ');el('svcMode').value=obj.plan.profile_mode;el('svcNow').value=obj.now;el('svcFollow').checked=false;renderProfiles(data.profiles);profileKey=timingKey(obj.plan);result=data;lastPlan=obj.plan;renderOutput();syncStats();message('برنامه باز شد و موقعیت‌ها دوباره محاسبه شدند.',!data.valid);}catch(e){message(typeof userError==="function"?userError(e):e.message,true);}finally{el('svcLoad').value='';}};
 document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{if(typeof render==='function'&&typeof state!=='undefined'&&state)render();syncStats();}));
 const now=tehran(),date=now.slice(0,10);if(!el('shortDeparture').value)el('shortDeparture').value=new Date(Date.parse(now+'Z')+900000).toISOString().slice(0,16);for(const d of ['A','B']){el('svcFirst'+d).value=date+'T05:30:00';el('svcLast'+d).value=date+'T23:00:00';}el('svcNow').value=now;
 window.ServiceClockUI={syncStats,calculate,tehran,getPlan:()=>structuredClone(planFromForm()),getResultInfo:()=>result?{valid:result.valid,headway_min:result.headway_min}:null};syncStats();calculate();
 setInterval(async()=>{if(!el('svcFollow').checked||!active()||followBusy)return;followBusy=true;try{el('svcNow').value=tehran();await calculate();}finally{followBusy=false;}},5000);
})();
