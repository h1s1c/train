# Vazirmatn (unmodified upstream font)

Version: v33.003
Project: https://github.com/rastikerdar/vazirmatn
Font: https://raw.githubusercontent.com/rastikerdar/vazirmatn/v33.003/fonts/webfonts/Vazirmatn%5Bwght%5D.woff2
License: https://raw.githubusercontent.com/rastikerdar/vazirmatn/v33.003/OFL.txt
License text included as OFL.txt. Font bytes are unmodified; filename only changed to Vazirmatn-Variable.woff2.
Weight axis: 100–900. Served from local application; no runtime CDN requests.
