"use strict";
(() => {
  const minuteKeys = new Set(["headway_s"]);
  const minuteFormatter = new Intl.NumberFormat("fa-IR", {minimumFractionDigits:2, maximumFractionDigits:3});
  function numeric(value) {
    if ((typeof value === "string" && value.trim() === "") || !Number.isFinite(Number(value))) {
      throw Error("لطفاً یک عدد معتبر وارد کنید.");
    }
    return Number(value);
  }
  const secondsToMinutes = value => numeric(value) / 60;
  const minutesToSeconds = value => numeric(value) * 60;
  const formatMinutes = seconds => minuteFormatter.format(secondsToMinutes(seconds));
  function formatClock(seconds) {
    const whole = Math.floor(numeric(seconds));
    return [Math.floor(whole / 3600), Math.floor(whole / 60) % 60, whole % 60]
      .map(value => String(value).padStart(2, "0")).join(":");
  }
  const isMinuteParameter = key => minuteKeys.has(key);
  function parameterDisplay(key, rawValue) {
    return isMinuteParameter(key) ? String(Number(secondsToMinutes(rawValue).toFixed(9))) : String(rawValue);
  }
  function parameterValue(key, inputValue, initialDisplay, originalRaw) {
    if (!isMinuteParameter(key)) return numeric(inputValue);
    // Preserve an unchanged headway without rounding through its minute display.
    return inputValue === initialDisplay ? numeric(originalRaw) : minutesToSeconds(inputValue);
  }
  const api = {secondsToMinutes, minutesToSeconds, formatMinutes, formatClock, isMinuteParameter, parameterDisplay, parameterValue};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else globalThis.SimUnits = Object.freeze(api);
})();