"""Scheduled short round trip in the simulator, not a signalling authority."""
import copy
import math
from datetime import timedelta
from service_clock import civil
from short_loop import clone, prepare, install, forecast


def set_clock(model, obj):
    if any(t.get('short_loop',{}).get('timed') for t in model.trains.values()):
        raise ValueError('تا پایان یا لغو گردش‌های زمان‌دار، تغییر مرجع ساعت مجاز نیست.')
    value=civil(obj.get('datetime')).isoformat(timespec='seconds')
    model.clock_reference={'datetime':value,'clock':model.clock}
    model.log('SHORT_CLOCK','مرجع ساعت سناریو تنظیم شد؛ این ساعت، موقعیت زنده میدان نیست.')
    return {'clock_reference':copy.deepcopy(model.clock_reference)}


def restore_timed(raw,low,high):
    if not isinstance(raw,dict):raise ValueError('اطلاعات اعزام زمان‌دار معتبر نیست.')
    due=float(raw['due']); origin=int(raw['origin']); dest=int(raw['destination']); direction=raw['direction']; status=raw['status']
    if not math.isfinite(due) or due<0 or (origin,dest) not in ((low,high),(high,low)) or direction!=('A' if origin==high else 'B') or status not in ('pending','departed','missed','cancelled'):
        raise ValueError('اطلاعات اعزام زمان‌دار ذخیره‌شده معتبر نیست.')
    date=civil(raw['datetime']).isoformat(timespec='seconds')
    round_trip=raw.get('round_trip',False);turned=raw.get('turn_reached',False)
    if not isinstance(round_trip,bool) or not isinstance(turned,bool) or (turned and (not round_trip or status not in ('departed','cancelled'))):raise ValueError('مرحله گردش ذخیره‌شده معتبر نیست.')
    timed=dict(due=due,origin=origin,destination=dest,direction=direction,status=status,datetime=date,round_trip=round_trip,turn_reached=turned)
    if status=='departed':
        actual=float(raw['actual_departure'])
        if not math.isfinite(actual) or abs(actual-due)>.11:raise ValueError('زمان اعزام ثبت‌شده معتبر نیست.')
        timed['actual_departure']=actual
    if status=='missed':timed['error']='اعزام زمان‌دار انجام نشده است؛ بررسی مجدد لازم است.'
    return timed


def fail(model,tr,message):
    timed=tr['short_loop']['timed']
    if timed['status']=='missed':return
    timed['status']='missed';timed['error']=message
    model.log('SHORT_MISSED',f"اعزام زمان‌دار {tr['label']} انجام نشد: {message}",tr['id'])


def check_deadline(model,tr):
    timed=tr.get('short_loop',{}).get('timed')
    if timed and timed['status']=='pending' and model.clock>timed['due']+.11:
        fail(model,tr,'قطار در ساعت تعیین‌شده آمادهٔ اعزام نبود یا مسیر آزاد نبود؛ اعزام خودکار انجام نمی‌شود.')


def before_departure(model,tr,previous,next_index):
    sl=tr.get('short_loop'); timed=sl.get('timed') if sl else None
    if not timed or previous['kind'] not in ('turn','dispatch'):return True
    following=tr['legs'][next_index]
    if following['kind']!='run' or following['line']!=timed['direction'] or model.tracks[tr['head']]['station']!=timed['origin']:return True
    if timed['status']=='missed':
        tr['speed']=0;tr['hold']=True;tr['state']='held';tr['reason']=timed.get('error','اعزام زمان‌دار انجام نشد؛ بررسی مجدد لازم است.')
        return False
    if timed['status']!='pending':return True
    if model.clock+1e-7<timed['due']:
        tr['speed']=0;tr['state']='dwell';tr['reason']='منتظر ساعت اعزام تعیین‌شده';return False
    if model.clock>timed['due']+.11:
        fail(model,tr,'زمان اعزام گذشته است؛ اعزام دیرهنگام خودکار انجام نمی‌شود.');tr['hold']=True;return False
    # Check and reserve at least the first circuit before actual release; no timer
    # can override a closure, point fault, occupancy, or required point-setting.
    probe=dict(tr,leg=next_index,index=tr['index'] if next_index==tr['leg'] else 0)
    remaining=model.length(tr['head'])-tr['pos']
    selected,ready=model._reserve(probe,remaining+model.config['margin_m']+5)
    if not selected or not ready:
        why=probe.get('reason') or 'مسیر یا سوزن در ساعت اعزام آماده نیست'
        fail(model,tr,why+'؛ اعزام انجام نشد.');model.reserved={n:o for n,o in model.reserved.items() if o!=tr['id'] or n in tr['sections']};tr['speed']=0;tr['hold']=True;tr['state']='held';tr['reason']=timed['error'];return False
    timed['status']='departed';timed['actual_departure']=model.clock
    model.log('SHORT_DEPART',f"اعزام {tr['label']} از ST{timed['origin']} به ST{timed['destination']} در {timed['datetime']} (زمان مدل)",tr['id'])
    return True


def finish_at_destination(model,tr):
    sl=tr.get('short_loop');timed=sl.get('timed') if sl else None
    if not timed or timed['status']!='departed':return False
    station=model.tracks[tr['head']]['station'];current=tr['legs'][tr['leg']]
    if timed.get('round_trip'):
        if current['line']==timed['direction'] and station==timed['destination']:
            if not timed.get('turn_reached'):
                timed['turn_reached']=True
                model.log('SHORT_TURN',f"{tr['label']} به ST{station} رسید؛ گردش و بازگشت به ST{timed['origin']} در مدل آغاز می‌شود.",tr['id'])
            return False
        if not timed.get('turn_reached') or current['line']==timed['direction'] or station!=timed['origin']:return False
    elif station!=timed['destination'] or current['line']!=timed['direction']:
        return False
    # Completion restores original service in the same direction and physical berth.
    legs=model.legs(sl['main_low'],sl['main_high'])
    idx=next(i for i,l in enumerate(legs) if l['kind']=='run' and l['line']==tr['line'])
    if tr['head'] not in legs[idx]['nodes']:raise ValueError('مقصد در مسیر اصلی قطار پیدا نشد.')
    i=legs[idx]['nodes'].index(tr['head'])
    result=dict(status='completed',origin=timed['origin'],destination=timed['destination'],datetime=timed['datetime'],actual_departure=timed['actual_departure'],arrival=model.clock)
    if getattr(model,'_forecast',False):tr['timed_result']=result
    else:tr.pop('timed_result',None)
    tr.update(legs=legs,leg=idx,index=i,served=[i],low=sl['main_low'],high=sl['main_high'],
              dwell_until=model.clock+model.config['dwell_s'],speed=0,doors=True,state='dwell',reason='گردش کوتاه پایان یافت؛ مسیر اصلی ادامه می‌یابد')
    tr.pop('short_loop',None)
    model.reserved={n:o for n,o in model.reserved.items() if o!=tr['id'] or n in tr['sections']}
    model.log('SHORT_FINISH',f"گردش کوتاه {tr['label']} در ST{station} پایان یافت و مسیر کوتاه لغو شد.",tr['id'])
    return True


def evaluate(model,obj,apply=False):
    try:
        if not model.clock_reference:raise ValueError('ابتدا مرجع تاریخ و ساعت مدل را تنظیم کنید.')
        origin=int(obj['origin']); p=prepare(model,obj,require_headway=False,direct_turn=(origin==int(obj['high'])))
        if origin not in (p['low'],p['high']):raise ValueError('ایستگاه اعزام باید یکی از دو ایستگاه گردش باشد.')
        direction='A' if origin==p['high'] else 'B';dest=p['low'] if direction=='A' else p['high']
        departure=civil(obj['departure']);anchor=civil(model.clock_reference['datetime'])
        due=float(model.clock_reference['clock'])+(departure-anchor).total_seconds()
        delta=due-model.clock
        if delta<=0.2:raise ValueError('ساعت اعزام باید پس از ساعت فعلی مدل باشد.')
        seconds=max(3600,math.ceil(delta+p['cycle_s']*2+600),math.ceil(model.capacity()['cycle_s']+2*model.config['headway_s']))
        if seconds>10800:raise ValueError('زمان اعزام یا مسیر به بیش از سه ساعت پیش‌بینی نیاز دارد؛ بررسی در این نسخه امکان‌پذیر نیست.')
        timed=dict(due=due,origin=origin,destination=dest,direction=direction,status='pending',datetime=departure.isoformat(timespec='seconds'),round_trip=True,turn_reached=False)
        baseline=clone(model);candidate=clone(model);install(candidate,p);candidate.trains[p['id']]['short_loop']['timed']=copy.deepcopy(timed)
        b=forecast(baseline,seconds,p['id'],(p['low'],p['high']))
        if b['error']:raise ValueError('سرویس فعلی در پیش‌بینی متوقف می‌شود: '+b['error'])
        c=forecast(candidate,seconds,p['id'],(p['low'],p['high']))
        if c['error']:raise ValueError('پیش‌بینی گردش کوتاه متوقف شد: '+c['error'])
        vehicle=candidate.trains[p['id']];pending=vehicle.get('short_loop',{}).get('timed',{});finished=vehicle.get('timed_result',{})
        if pending.get('status')=='missed':raise ValueError(pending.get('error','اعزام در ساعت تعیین‌شده امکان‌پذیر نیست.'))
        for key,samples in c['waits'].items():
            extra=len(samples-b['waits'].get(key,set()))
            if extra>0:raise ValueError(f'تداخل پیش‌بینی‌شده: قطار {key[0]} به‌خاطر قطار {key[1]} در {key[2]} حدود {extra} ثانیه بیشتر منتظر می‌ماند.')
        if finished.get('status')!='completed' or finished.get('datetime')!=timed['datetime']:
            raise ValueError('قطار نتوانست در ساعت تعیین‌شده اعزام و پس از گردش در بازه پیش‌بینی به مبدأ بازگردد.')
        # Never accept a new trip that causes an earlier registered trip to miss
        # its deadline or delays completion that the baseline could achieve.
        def trip_status(vehicle, scheduled):
            active=vehicle.get('short_loop',{}).get('timed',{})
            if active.get('datetime')==scheduled:return active.get('status')
            result=vehicle.get('timed_result',{})
            return result.get('status') if result.get('datetime')==scheduled else None
        for tid,original in model.trains.items():
            prior=original.get('short_loop',{}).get('timed',{})
            if prior.get('status') not in ('pending','departed'):continue
            baseline_status=trip_status(baseline.trains[tid],prior['datetime'])
            candidate_status=trip_status(candidate.trains[tid],prior['datetime'])
            if baseline_status=='missed':
                raise ValueError(f'اعزام ثبت‌شده قطار {tid} در پیش‌بینی به ساعت خود نمی‌رسد؛ ابتدا آن را بررسی کنید.')
            if candidate_status=='missed' or (baseline_status in ('departed','completed') and candidate_status=='pending') or (baseline_status=='completed' and candidate_status!='completed'):
                raise ValueError(f'گردش جدید با اعزام یا رسیدن برنامه‌ریزی‌شده قطار {tid} تداخل دارد.')
        # Both legs are simulated; report stations in actual route order.
        suffix='1' if direction=='A' else '2'
        nodes=model.chain_slice(direction,f'T{origin}.{suffix}',f'T{dest}.{suffix}')
        station_names={x['id']:x['name'] for x in model.data['stations']}
        stations=[dict(id=model.tracks[n]['station'],name=station_names[model.tracks[n]['station']])
                  for n in nodes if model.tracks[n]['platform']]
        return_dir='B' if direction=='A' else 'A';return_suffix='2' if return_dir=='B' else '1'
        back_nodes=model.chain_slice(return_dir,f'T{dest}.{return_suffix}',f'T{origin}.{return_suffix}')
        return_stations=[dict(id=model.tracks[n]['station'],name=station_names[model.tracks[n]['station']]) for n in back_nodes if model.tracks[n]['platform']]
        report=dict(valid=True,applied=False,errors=[],id=p['id'],low=p['low'],high=p['high'],origin=origin,destination=dest,departure=timed['datetime'],headway_s=p['headway_s'],horizon_s=math.ceil(seconds),certified=False,stations=stations,return_stations=return_stations,round_trip=True)
        if apply:
            install(model,p);model.trains[p['id']]['short_loop']['timed']=copy.deepcopy(timed)
            model.log('SHORT_LOOP',f"گردش زمان‌دار {model.trains[p['id']]['label']} از ST{origin} به ST{dest} و بازگشت به ST{origin} ثبت شد؛ پس از بازگشت لغو می‌شود.",p['id']);report['applied']=True
        return {'short_loop':report}
    except (ValueError,KeyError,TypeError,IndexError,OverflowError) as exc:
        return {'short_loop':dict(valid=False,applied=False,errors=[str(exc)],certified=False)}
